// ════════════════════════════════ EXPORT ════════════════════════════════
// ════════════ MINIMAL ZIP BUILDER (no external deps) ════════════
// Implements ZIP "stored" (no compression) — spec §4.3, universally compatible.
function buildZip(files){
  // files: { "path/file.txt": Uint8Array, ... }
  const enc = s => new TextEncoder().encode(s);
  const u32le = n => new Uint8Array([n&0xff,(n>>8)&0xff,(n>>16)&0xff,(n>>24)&0xff]);
  const u16le = n => new Uint8Array([n&0xff,(n>>8)&0xff]);

  function crc32(buf){
    let c = 0xFFFFFFFF;
    const t = new Uint32Array(256);
    for(let i=0;i<256;i++){let n=i;for(let j=0;j<8;j++)n=n&1?0xEDB88320^(n>>>1):n>>>1;t[i]=n;}
    for(let i=0;i<buf.length;i++) c=t[(c^buf[i])&0xff]^(c>>>8);
    return (c^0xFFFFFFFF)>>>0;
  }

  function concat(...arrays){
    const total = arrays.reduce((s,a)=>s+a.length,0);
    const out = new Uint8Array(total); let off=0;
    arrays.forEach(a=>{out.set(a,off);off+=a.length;}); return out;
  }

  // Encode current date/time in MS-DOS packed format for ZIP timestamps
  const _now = new Date();
  const _dosTime = ((_now.getHours() << 11) | (_now.getMinutes() << 5) | Math.floor(_now.getSeconds() / 2));
  const _dosDate = (((_now.getFullYear() - 1980) << 9) | ((_now.getMonth() + 1) << 5) | _now.getDate());

  const parts = [], centralDir = [];
  let offset = 0;

  for(const [path, data] of Object.entries(files)){
    const name = enc(path);
    const crc  = crc32(data);
    const size = data.length;

    // Set UTF-8 flag (bit 11 = 0x0800) when the path contains non-ASCII characters
    // so that extractors (7-Zip, Android, iOS) decode the filename correctly.
    const needsUtf8 = /[^\x00-\x7F]/.test(path);
    const flags = needsUtf8 ? 0x0800 : 0;

    // Local file header
    const isDir = path.endsWith('/');
    const extAttr = isDir ? u32le(0x10) : u32le(0x20); // MS-DOS: dir bit or archive bit
    const local = concat(
      new Uint8Array([0x50,0x4B,0x03,0x04]), // signature
      u16le(20),           // version needed
      u16le(flags),        // flags: 0x0800 if non-ASCII, else 0
      u16le(0),            // compression: stored
      u16le(_dosTime), u16le(_dosDate),  // mod time/date: current date/time
      u32le(crc),
      u32le(size), u32le(size),
      u16le(name.length), u16le(0), // filename len, extra len
      name, data
    );
    parts.push(local);

    // Central directory entry
    centralDir.push(concat(
      new Uint8Array([0x50,0x4B,0x01,0x02]), // signature
      u16le(20), u16le(20),  // version made by, version needed
      u16le(flags), u16le(0), // flags: UTF-8 if needed, compression: stored
      u16le(_dosTime), u16le(_dosDate),  // mod time/date: current date/time
      u32le(crc),
      u32le(size), u32le(size),
      u16le(name.length),
      u16le(0), u16le(0), u16le(0), // extra, comment, disk start
      u16le(0),   // internal attr
      extAttr,    // external attr: proper dir/file MS-DOS attribute
      u32le(offset),        // local header offset
      name
    ));
    offset += local.length;
  }

  const cd     = concat(...centralDir);
  const cdSize = cd.length;
  const eocd   = concat(
    new Uint8Array([0x50,0x4B,0x05,0x06]), // signature
    u16le(0), u16le(0),                    // disk numbers
    u16le(centralDir.length), u16le(centralDir.length),
    u32le(cdSize), u32le(offset),
    u16le(0)                               // comment length
  );
  return concat(...parts, cd, eocd);
}

function exportSystem(){
  const bodyEntries = Object.entries(bodies);
  if(bodyEntries.length === 0){ alert('No bodies to export!'); return; }

  // ── Space Centre validation ──
  // Any body in the system is an acceptable launch site — the only failure
  // case is the configured address not existing in this system at all
  // (e.g. still defaulted to "Earth" in a system that has no Earth).
  const scAddr = systemSettings.spaceCenterData?.address;
  const scBodyExists = scAddr && bodies[scAddr];
  if(!scBodyExists){
    scPickerOpen(scAddr, () => exportSystem());
    return;
  }

  _exportSystemProceed();
}

function _exportSystemProceed(){
  const bodyEntries = Object.entries(bodies);
  const centerName = Object.keys(bodies).find(n => bodies[n].isCenter) || 'System';
  const customFolder = (document.getElementById('sys-foldername')?.value || '').trim().replace(/[\\/:*?"<>|]/g,'');
  const sysName = customFolder || centerName;
  const enc = str => new TextEncoder().encode(str);

  function dataUrlToBytes(dataUrl){
    const b64 = dataUrl.split(',')[1];
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for(let i=0;i<bin.length;i++) out[i]=bin.charCodeAt(i);
    return out;
  }

  const zipFiles = {};

  // Always include all three folders even if empty (ZIP spec: zero-byte entry ending in /)
  zipFiles[`${sysName}/Planet Data/`]   = new Uint8Array(0);
  zipFiles[`${sysName}/Heightmap Data/`]= new Uint8Array(0);
  zipFiles[`${sysName}/Texture Data/`]  = new Uint8Array(0);

  // Planet Data/
  bodyEntries.forEach(([name, b]) => {
    const _ed = JSON.parse(JSON.stringify(b.data));
    const { version: _ev, editor: _etags, ..._er } = _ed;
    // editor goes last so it sits cleanly at the bottom of the file
    const out = { version: _ev || '1.5', ..._er, ...(_etags !== undefined ? { editor: _etags } : {}) };
    zipFiles[`${sysName}/Planet Data/${name}.txt`] = enc(JSON.stringify(out, null, 2));
  });

  // ── Collect only textures / heightmaps actually referenced by the exported bodies ──
  const usedTexNames = new Set();
  const usedHmNames  = new Set();

  bodyEntries.forEach(([, b]) => {
    const d = b.data;

    // Atmosphere gradient + cloud strip
    const grdTex = d.ATMOSPHERE_VISUALS_DATA?.GRADIENT?.texture;
    if(grdTex && grdTex !== 'None') usedTexNames.add(grdTex);
    const cldTex = d.ATMOSPHERE_VISUALS_DATA?.CLOUDS?.texture;
    if(cldTex && cldTex !== 'None') usedTexNames.add(cldTex);

    // Front clouds
    const fcTex = d.FRONT_CLOUDS_DATA?.cloudsTexture;
    if(fcTex && fcTex !== 'None') usedTexNames.add(fcTex);

    // Terrain textures
    const TTD = d.TERRAIN_DATA?.TERRAIN_TEXTURE_DATA || {};
    ['planetTexture','surfaceTexture_A','surfaceTexture_B','terrainTexture_C'].forEach(k => {
      if(TTD[k] && TTD[k] !== 'None') usedTexNames.add(TTD[k]);
    });

    // Rings
    const rngTex = d.RINGS_DATA?.ringsTexture;
    if(rngTex && rngTex !== 'None') usedTexNames.add(rngTex);

    // Ocean mask
    const maskTex = d.WATER_DATA?.oceanMaskTexture;
    if(maskTex && maskTex !== 'None') usedTexNames.add(maskTex);

    // Heightmaps referenced in any terrain formula field
    // Collect all formula lines from every relevant field
    const TD = d.TERRAIN_DATA || {};
    const formulaLines = [
      ...(TD.terrainFormula        || []),
      ...(TD.textureFormula        || []),
      ...Object.values(TD.terrainFormulaDifficulties || {}).flat(),
      ...Object.values(TD.textureDifficulties        || {}).flat(),
    ];
    formulaLines.forEach(line => {
      if(typeof line !== 'string') return;
      // Extract every bare identifier and every quoted string —
      // heightmap names appear as bare words (e.g. Earth) or quoted (e.g. "Earth")
      // anywhere in the formula line, not just as first args.
      // Quoted strings:
      const qMatches = line.matchAll(/"([^"]+)"|'([^']+)'/g);
      for(const m of qMatches) usedHmNames.add(m[1] || m[2]);
      // Bare identifiers that look like names (letters, digits, underscores, dots, hyphens)
      // but are NOT keywords or operators
      const KEYWORDS = new Set(['SAMPLE','OUTPUT','sin','cos','abs','min','max','pow','sqrt',
        'floor','ceil','round','log','PI','if','else','return','true','false','null',
        'FLAT_ZONE','OCEAN_MASK','WATER','NOISE']);
      const bareMatches = line.matchAll(/\b([A-Za-z][A-Za-z0-9_.\-]*)\b/g);
      for(const m of bareMatches){
        if(!KEYWORDS.has(m[1]) && !/^\d/.test(m[1])) usedHmNames.add(m[1]);
      }
    });
  });

  // Heightmap Data/ — only used heightmaps, skipping vanilla (game provides them)
  // Match by full name OR stem (formula lines use bare names without extension)
  assets.heightmaps.forEach(e => {
    if(e.vanilla) return;
    const stem = e.name.replace(/\.[^.]+$/, '');
    const matched = usedHmNames.has(e.name) || usedHmNames.has(stem);
    if(!matched) return;
    // PNG heightmaps store bytes in e.url (data URL); txt heightmaps store text in e.content
    if(e.url){
      zipFiles[`${sysName}/Heightmap Data/${e.name}`] = dataUrlToBytes(e.url);
    } else if(e.bytes){
      zipFiles[`${sysName}/Heightmap Data/${e.name}`] = e.bytes;
    } else if(e.content != null){
      zipFiles[`${sysName}/Heightmap Data/${e.name}`] = enc(e.content);
    }
  });

  // Texture Data/ — only used textures, skipping vanilla (game provides them)
  // VANILLA_EXPORT_SKIP: exhaustive list of every texture name the base game ships internally.
  // These are referenced by vanilla presets but the game already has them — never bundle them.
  const VANILLA_TEX_SKIP = new Set([
    'Ariel','Asteroid','Atmo_Earth','Atmo_Enceladus','Atmo_Europa','Atmo_Jupiter',
    'Atmo_Mars','Atmo_Neptune','Atmo_Pluto','Atmo_Saturn','Atmo_Sun','Atmo_Titan',
    'Atmo_Triton','Atmo_Uranus','Blured02','Callisto','Ceres','Charon','Circles02',
    'DarkDust02','Dark_Dust','Deimos','Dione','Dots02','DryGround',
    'Earth_Clouds','Earth_Clouds_Front','Earth_OceanMask_V2','Earth_WithOceans',
    'Enceladus','Europa','Ganymede','HardRocks02','Hydra','Iapetus','Ice02',
    'Io','Jupiter','Mars','Mercury','Mimas','Miranda','Moon','Naiad','Neptune',
    'Neutral','Nix','Oberon','Pan','Phobos','Pluto','Proteus','Puck','Rhea',
    'Sand','Saturn','Saturn_Rings','Snow','Tethys','Thebe','Titan','Titan_LakeMask',
    'Titania','Triton','Umbriel','Uranus',
  ]);
  assets.textures.forEach(e => {
    if(e.vanilla) return; // flagged vanilla at load time
    const stem = e.name.replace(/\.[^.]+$/, '');
    if(VANILLA_TEX_SKIP.has(stem) || VANILLA_TEX_SKIP.has(e.name)) return; // game-bundled texture
    if(usedTexNames.has(stem) || usedTexNames.has(e.name)){
      zipFiles[`${sysName}/Texture Data/${e.name}`] = dataUrlToBytes(e.url);
    }
  });

  const exportedHmNames = Object.keys(zipFiles).filter(k => k.includes('/Heightmap Data/') && !k.endsWith('/'));
  console.log(`[SFS|EXPORT] formula referenced names (${usedHmNames.size}): [${[...usedHmNames].join(',')}]`);
  console.log(`[SFS|EXPORT] heightmaps exported (${exportedHmNames.length}): [${exportedHmNames.map(k=>k.split('/').pop()).join(',')}]`);

  // Other uploaded files
  assets.other.forEach(e => {
    zipFiles[`${sysName}/${e.name}`] = enc(e.content);
  });

  // System meta — append editor credit to description if not already present
  const CREDIT_TAG = 'Edited with SFS System Editor Site';
  const importSettingsOut = JSON.parse(JSON.stringify(systemSettings.importSettings));
  const rawDesc = (importSettingsOut.description || '').trim();
  if(rawDesc === '' || rawDesc === 'n/a'){
    importSettingsOut.description = CREDIT_TAG;
  } else if(!rawDesc.includes(CREDIT_TAG)){
    importSettingsOut.description = rawDesc + ' | ' + CREDIT_TAG;
  }
  zipFiles[`${sysName}/Import_Settings.txt`]   = enc(JSON.stringify(importSettingsOut, null, 2));
  zipFiles[`${sysName}/Space_Center_Data.txt`] = enc(JSON.stringify(systemSettings.spaceCenterData, null, 2));
  zipFiles[`${sysName}/Version.txt`]           = enc('1.6.00.14');

  // Build and download
  try{
    const zipped = buildZip(zipFiles);
    const blob = new Blob([zipped], {type:'application/zip'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = sysName + '.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
  } catch(err){
    console.error('Export error:', err);
    alert('Export failed: ' + err.message);
  }
}



