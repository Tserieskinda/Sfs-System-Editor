// ════════════════════════════════ CANVAS / KEPLERIAN RENDERER ════════════════════════════════
const vp = document.getElementById('viewport');
const ctx2 = vp.getContext('2d');
let vpOffX = 0, vpOffY = 0, vpZ = 1;
let iconScale = parseFloat(localStorage.getItem('sfs_icon_scale') || '0.75');

function setIconScale(v){
  iconScale = Math.max(0.3, Math.min(1.5, v));
  localStorage.setItem('sfs_icon_scale', iconScale);
  const sl = document.getElementById('icon-scale-slider');
  if(sl) sl.value = iconScale;
  const lbl = document.getElementById('icon-scale-val');
  if(lbl) lbl.textContent = Math.round(iconScale * 100) + '%';
  drawViewport();
}
let bodyWorldPos = {};  // populated each drawViewport(); read by zoomToBody()
let viewDifficulty = 'normal'; // 'normal' | 'hard' | 'realistic'
// Data files use Title Case keys ('Normal','Hard','Realistic') — compute once on change
let viewDiffKey = 'Normal'; // Title-case version used for smaDifficultyScale / radiusDifficultyScale lookups
let dragging = false, dragSX, dragSY;
let _imgConsumedDown = false; // true when imgMouseDown consumed the last mousedown — suppresses the click handler
const BODY_PX = { star:28, planet:16, gasgiant:22, ringedgiant:22, marslike:14, mercurylike:12, moon:11, asteroid:7, blackhole:18, barycentre:5 };

// Draw a high-sided polygon approximating a circle — avoids the per-frame bezier
// tessellation cost of ctx.arc() when the radius is large on screen.
function polygonCircle(ctx, cx, cy, r, sides){
  const step = (Math.PI * 2) / sides;
  ctx.moveTo(cx + r, cy);
  for(let i = 1; i <= sides; i++) ctx.lineTo(cx + r * Math.cos(step * i), cy + r * Math.sin(step * i));
}

// SMA scale: map the largest SMA to ~38% of the viewport half-width in pixels
const SMA_SCALE_TARGET = 0.38;
let _cachedSMAScale = null; // invalidated at start of _drawViewportNow each frame
function getSMAScale(){
  if(_cachedSMAScale !== null) return _cachedSMAScale;
  const names = Object.keys(bodies);
  let maxSMA = 0;
  names.forEach(n=>{
    const od = bodies[n].data.ORBIT_DATA;
    if(od && effectiveSMA(od) > maxSMA) maxSMA = effectiveSMA(od);
  });
  const halfW = (vp.width || window.innerWidth) / 2;
  let result;
  if(maxSMA === 0){
    const centerName = names.find(n => bodies[n].isCenter);
    const centerR = centerName ? ((bodies[centerName].data.BASE_DATA||{}).radius || 1) : 1;
    result = 20 / centerR;
  } else {
    result = (halfW * SMA_SCALE_TARGET) / maxSMA;
  }
  _cachedSMAScale = result;
  return result;
}

// Convert SMA (metres) → pixels given current scale
function smaToPixels(sma){ return sma * getSMAScale(); }

// Returns SMA scaled for the current viewDifficulty, matching game's SmaScale(planet).
// Files store the Normal-mode SMA. Default multipliers: Normal=1, Hard=2, Realistic=20.
// Per-body smaDifficultyScale overrides the default entirely (same as game behaviour).
function effectiveSMA(od){
  if(!od) return 0;
  const scale = od.smaDifficultyScale;
  const mult = (scale && scale[viewDiffKey] != null) ? scale[viewDiffKey] : (_DEF_SMA_SCALE[viewDiffKey] ?? 1);
  return od.semiMajorAxis * mult;
}

// Default SMA difficulty multipliers — matches game's defaultDistanceScales: Normal=1, Hard=2, Realistic=20.
// Planet files store the Normal-mode SMA. The game multiplies it by this scale for harder difficulties.
const _DEF_SMA_SCALE = { Normal: 1, Hard: 2, Realistic: 20 };

// Mirrors Difficulty.RadiusScale() — defaultPlanetScales: Normal=1, Hard=2, Realistic=20
const _DEF_RADIUS_SCALE = { normal: 1.0, hard: 2.0, realistic: 20.0 };
function getRadiusDifficultyMult(bd){
  if(!bd) return 1;
  const s = bd.radiusDifficultyScale;
  if(s && s[viewDiffKey] != null) return s[viewDiffKey];
  return _DEF_RADIUS_SCALE[viewDifficulty] ?? 1;
}

// Mirrors Difficulty.AtmosphereScale():
//   1. Try atmospherePhysics.heightDifficultyScale[difficulty]
//   2. Try atmosphereVisuals.GRADIENT.heightDifficultyScale[difficulty]
//   3. DefaultAtmoHeightScale: Normal=1.0, Hard=1.6667, Realistic=3.3333
const _DEF_ATMO_SCALE = { normal: 1.0, hard: 1.6666667, realistic: 3.3333333 };
function getAtmoDifficultyMult(bd){
  if(!bd) return 1;
  const physScale = bd.ATMOSPHERE_PHYSICS_DATA?.heightDifficultyScale;
  if(physScale && physScale[viewDiffKey] != null) return physScale[viewDiffKey];
  const gradScale = bd.ATMOSPHERE_VISUALS_DATA?.GRADIENT?.heightDifficultyScale;
  if(gradScale && gradScale[viewDiffKey] != null) return gradScale[viewDiffKey];
  return _DEF_ATMO_SCALE[viewDifficulty] ?? 1;
}

function cycleDifficulty(){
  const order = ['normal','hard','realistic'];
  viewDifficulty = order[(order.indexOf(viewDifficulty) + 1) % order.length];
  viewDiffKey = viewDifficulty.charAt(0).toUpperCase() + viewDifficulty.slice(1); // 'Normal'|'Hard'|'Realistic'
  const labels = {
    normal:     '<svg class="icon"><use href="#icon-scale"></use></svg> NORMAL',
    hard:       '<svg class="icon"><use href="#icon-swords"></use></svg> HARD',
    realistic:  '<svg class="icon"><use href="#icon-globe"></use></svg> REALISTIC'
  };
  const btn = document.getElementById('btn-difficulty');
  if(btn) btn.innerHTML = labels[viewDifficulty];
  // Invalidate all cached gradient stops — they depend on difficulty (atmo, ring fades)
  if(drawViewport._atmoStopCache) drawViewport._atmoStopCache = {};
  if(drawViewport._ringStopCache) drawViewport._ringStopCache = {};
  // Refresh orbital period — effective SMA and parent GM both change with difficulty
  if(typeof updatePeriodFromSMA === 'function') updatePeriodFromSMA();
  // Refresh SOI display — depends on effectiveSMA and soiDifficultyScale
  if(typeof updateSOIDisplay === 'function') updateSOIDisplay();
  // Re-populate sidebar so SMA and radius fields reflect the new difficulty multiplier
  if(typeof fillSidebar === 'function' && typeof selectedBody !== 'undefined' && selectedBody)
    fillSidebar(selectedBody);
  drawViewport();
}

function toggleDistRings(){
  const on = localStorage.getItem('sfs_dist_rings') !== '0';
  localStorage.setItem('sfs_dist_rings', on ? '0' : '1');
  _syncDistRingsBtn();
  drawViewport();
}

function _syncDistRingsBtn(){
  const btn = document.getElementById('btn-dist-rings');
  if(!btn) return;
  const on = localStorage.getItem('sfs_dist_rings') !== '0';
  btn.style.opacity    = on ? '1' : '0.4';
  btn.style.background = on ? 'rgba(120,200,255,.1)' : '';
}

// ── Habitable-zone viewport overlay ─────────────────────────────────────────
// Toggled independently of the HZ Visualizer modal — the modal is the control
// panel (pick star / spectral type / luminosity override), this is the
// always-on-canvas gradient rendering of whatever the modal last computed.
// Reading from localStorage (rather than requiring the modal to be open)
// means the band persists across sessions and doesn't depend on the modal's
// DOM existing, since drawViewport can run before the user ever opens Utils.
function toggleHZBand(){
  const on = localStorage.getItem('sfs_hz_band') === '1';
  localStorage.setItem('sfs_hz_band', on ? '0' : '1');
  _syncHZBandBtn();
  drawViewport();
}

function _syncHZBandBtn(){
  const btn = document.getElementById('btn-hz-band');
  if(!btn) return;
  const on = localStorage.getItem('sfs_hz_band') === '1';
  btn.style.opacity    = on ? '1' : '0.4';
  btn.style.background = on ? 'rgba(255,140,90,.1)' : '';
}
document.addEventListener('DOMContentLoaded', _syncHZBandBtn);

// ── Distance ring scale presets ────────────────────────────────────────────────
// Each preset defines a named scale and its ring values in AU.
// LY values are stored as AU (1 LY = 63241 AU) so the renderer is unchanged.
const _LY = 63241; // AU per light-year
const _DIST_RING_PRESETS = [
  { id: 'inner',   label: 'Inner system', sub: '0.1 – 2 AU',            rings: [0.1, 0.25, 0.5, 1, 2] },
  { id: 'solar',   label: 'Solar system', sub: '1 – 50 AU',             rings: [1, 5, 10, 20, 30, 50] },
  { id: '100au',   label: '100 AU scale', sub: '10 – 100 AU',           rings: [10, 25, 50, 75, 100] },
  { id: '1kau',    label: '1 000 AU',     sub: '100 – 1 000 AU',        rings: [100, 250, 500, 1000] },
  { id: '0.1ly',   label: '0.1 LY',       sub: '0.01 – 0.1 LY',        rings: [0.01*_LY, 0.025*_LY, 0.05*_LY, 0.1*_LY] },
  { id: '1ly',     label: '1 LY',         sub: '0.1 – 1 LY',           rings: [0.1*_LY, 0.25*_LY, 0.5*_LY, _LY] },
  { id: '10ly',    label: '10 LY',        sub: '1 – 10 LY',            rings: [_LY, 2*_LY, 5*_LY, 10*_LY] },
  { id: '100ly',   label: '100 LY',       sub: '10 – 100 LY',          rings: [10*_LY, 25*_LY, 50*_LY, 100*_LY] },
];

// Returns the ring AU array for the active preset.
function _getDistRingsCfg(){
  const id = localStorage.getItem('sfs_dist_rings_preset') || 'solar';
  const p  = _DIST_RING_PRESETS.find(p => p.id === id) || _DIST_RING_PRESETS[1];
  return p.rings.slice();
}

// Build a nice label for a ring value — auto-selects AU vs LY.
function _ringLabel(au){
  if(au >= _LY * 0.09){
    const ly = au / _LY;
    const s  = ly >= 10 ? Math.round(ly) : (ly >= 1 ? +ly.toFixed(1) : +ly.toFixed(2));
    return s + ' LY';
  }
  const s = au >= 10 ? Math.round(au) : (au >= 1 ? +au.toFixed(1) : +au.toFixed(2));
  return s + ' AU';
}

function openDistRingsMenu(){
  const modal = document.getElementById('dist-rings-modal');
  if(!modal) return;
  _distRingsRenderPresets();
  modal.style.display = 'flex';
}

function closeDistRingsMenu(){
  const modal = document.getElementById('dist-rings-modal');
  if(modal) modal.style.display = 'none';
}

function _distRingsRenderPresets(){
  const list = document.getElementById('dist-rings-list');
  if(!list) return;
  const active = localStorage.getItem('sfs_dist_rings_preset') || 'solar';
  list.innerHTML = _DIST_RING_PRESETS.map(p => {
    const on = p.id === active;
    const ringStr = p.rings.map(_ringLabel).join(', ');
    return `<div onclick="_distRingsSelectPreset('${p.id}')" style="
        display:flex;align-items:center;gap:10px;padding:7px 10px;margin-bottom:5px;
        border-radius:7px;cursor:pointer;border:1px solid ${on ? 'rgba(120,200,255,.45)' : 'rgba(120,200,255,.1)'};
        background:${on ? 'rgba(120,200,255,.1)' : 'rgba(120,200,255,.03)'};
        transition:background .12s,border-color .12s;">
      <div style="width:14px;height:14px;border-radius:50%;flex-shrink:0;
        border:2px solid ${on ? 'rgba(120,200,255,.9)' : 'rgba(120,200,255,.3)'};
        background:${on ? 'rgba(120,200,255,.7)' : 'transparent'};
        box-shadow:${on ? '0 0 6px rgba(120,200,255,.5)' : 'none'};"></div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:.72rem;color:${on ? 'rgba(180,220,255,.95)' : 'rgba(150,185,230,.7)'};
          letter-spacing:.04em;">${p.label}</div>
        <div style="font-size:.58rem;color:rgba(110,150,200,.5);margin-top:1px;
          white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${ringStr}</div>
      </div>
    </div>`;
  }).join('');
}

function _distRingsSelectPreset(id){
  localStorage.setItem('sfs_dist_rings_preset', id);
  _distRingsRenderPresets();
  drawViewport();
}

function _distRingsReset(){
  localStorage.removeItem('sfs_dist_rings_preset');
  _distRingsRenderPresets();
  drawViewport();
}

// Sync dist-rings button state on load
(function _initDistRingsBtn(){
  const _go = () => _syncDistRingsBtn();
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _go);
  else _go();
})();

// Keplerian: given SMA(px), ecc, argPeriapsis, return {cx,cy,rx,ry,angle, bodyX, bodyY}
// In SFS, argument of periapsis rotates the ellipse. Body is placed at periapsis (true anomaly=0).
function orbitGeometry(smaPx, ecc, aopDeg, parentCX, parentCY){
  const aop = aopDeg * Math.PI / 180;
  const rx = smaPx;                   // semi-major
  const ry = smaPx * Math.sqrt(1 - ecc*ecc);  // semi-minor
  const c  = smaPx * ecc;             // focus offset along major axis
  // SFS is Y-up; canvas is Y-down — negate all sin/Y terms so AOP matches in-game
  const ellCX = parentCX - c *  Math.cos(aop);
  const ellCY = parentCY + c *  Math.sin(aop); // +sin = flip Y
  const bodyX = parentCX + (smaPx - c) *  Math.cos(aop);
  const bodyY = parentCY - (smaPx - c) *  Math.sin(aop); // -sin = flip Y
  return { ellCX, ellCY, rx, ry, angle: -aop, bodyX, bodyY }; // -aop flips ellipse rotation too
}

function resizeViewport(){
  const isMobile = window.innerWidth <= 640;
  const topH  = isMobile ? 52 : 48;
  const botH  = isMobile ? 44 : 28;
  const w = window.innerWidth;
  const h = window.innerHeight - topH - botH;
  if(w > 0 && h > 0){ vp.width = w; vp.height = h; }
  drawViewport();
}

function worldToScreen(wx, wy){
  return {
    x: (wx + vpOffX) * vpZ + vp.width/2,
    y: (wy + vpOffY) * vpZ + vp.height/2
  };
}

function screenToWorld(sx, sy){
  return {
    x: (sx - vp.width/2) / vpZ - vpOffX,
    y: (sy - vp.height/2) / vpZ - vpOffY
  };
}

// Module-level visibility map — updated each drawViewport call, used by click handler
let bodyVisible = {};

// Store computed screen positions and visibility for hit-testing
let bodyScreenPos = {};
let bodyVisibleMap = {};
// Max terrain radius in pixels for each body (updated each draw frame).
// Keyed by body name. 0 means no terrain / not yet computed.
let bodyTerrainPeakPx = {};
let showFrontClouds = true; // legacy alias — kept for draw code gate
let dbgFogOpacity = 1.0;   // kept for any legacy references (unused by new system)

// ── Front-cloud edge debug ──
// Toggle from the console with toggleFcDebug(). When on, each front-cloud
// layer logs its geometry (once per unique parameter set) and draws overlay
// rings on top of the planet showing: the intended outer disc edge (fcR_px),
// where the fade math reaches full erase, and where the fade starts — plus
// small unscaled thumbnails of the raw scratch-canvas mask (pre-blit-scaling)
// stacked in the top-left corner, one per visible front-cloud layer.
let FC_DEBUG = false;
function toggleFcDebug(){
  FC_DEBUG = !FC_DEBUG;
  console.log('[FC_DEBUG]', FC_DEBUG ? 'ON' : 'OFF');
  if(typeof drawViewport === 'function') drawViewport();
}
if(typeof window !== 'undefined') window.toggleFcDebug = toggleFcDebug;

// ── Environment render flags ──
const envFlags = {
  soi:       true,
  atmo:      true,
  clouds:    true,
  fclouds:   true,
  fog:       true,
  water:     true,
  surface:   true,
  physAtmo:  false,
  postProc:  false,
  heightmaps: false,
};

function toggleEnvFlag(key){
  envFlags[key] = !envFlags[key];
  // Keep legacy alias in sync
  if(key === 'fclouds') showFrontClouds = envFlags.fclouds;
  // Remove GPU tint filter from canvas when post-proc is turned off
  if(key === 'postProc' && !envFlags.postProc) _clearPostProcessingFilter();
  // Invalidate clip path cache when heightmaps toggled so the smooth/terrain
  // disc is redrawn correctly on the next frame
  if(key === 'heightmaps') invalidateTerrainCache('*');
  _syncEnvButtons();
  drawViewport();
}

function _syncEnvButtons(){
  for(const key of Object.keys(envFlags)){
    const btn = document.getElementById('env-btn-' + key);
    if(!btn) continue;
    if(btn.classList.contains('tog')){
      btn.classList.toggle('on', !!envFlags[key]);
    } else {
      const flag = key === 'postProc' ? !envFlags[key] : envFlags[key];
      btn.classList.toggle('env-off', !flag);
    }
  }
}

let _envDropOpen = false;
function toggleEnvDropdown(){
  _envDropOpen = !_envDropOpen;
  const dd = document.getElementById('env-dropdown');
  if(_envDropOpen){
    dd.style.display = 'block';
    const btn = document.getElementById('btn-env');
    positionToolbarDropdown(dd, btn);
  } else {
    dd.style.display = 'none';
  }
}

// Legacy stubs — referenced by any surviving onclick attrs
function toggleFrontClouds(){ toggleEnvFlag('fclouds'); }
function toggleSOI(){ toggleEnvFlag('soi'); }

// ── SOI calculation (mirrors SFS game logic exactly) ──
// Source: Kepler.GetSphereOfInfluence, Difficulty.ScalePlanetData, Planet.SetupInteractions
//
// Pipeline (all difficulty scaling happens BEFORE the formula):
//   1. radius      *= radiusDifficultyScale[diff]  (default Normal=1, Hard=2, Realistic=20)
//   2. gravity     *= gravityDifficultyScale[diff]  (default 1.0 — rarely overridden)
//   3. mass         = gravity × radius²             (Kepler.GetMass)
//   4. sma         *= smaDifficultyScale[diff]      (default Normal=1, Hard=2, Realistic=20)
//   5. multiplierSOI *= soiDifficultyScale[diff]    (default 1.0 — rarely overridden)
//   6. SOI          = sma × (mass_body/mass_parent)^0.4 × multiplierSOI
//
// Bodies with no ORBIT_DATA parent get SOI = Infinity (system center).
// Mirrors Difficulty.GravityScale() — default is 1.0, only overridden if gravityDifficultyScale is set.
function _getGravityDiffMult(bd){
  const s = bd?.gravityDifficultyScale;
  if(s && s[viewDiffKey] != null) return s[viewDiffKey];
  return 1.0;
}

// Derives difficulty-scaled mass for a body, mirroring SFS:
//   mass = (gravity × gravityScale) × (radius × radiusScale)²
// Barycenters have gravity=0 — fall back to surrogate 5.0 so Hill sphere remains computable.
function _effectiveMass(bd){
  if(!bd) return 5;
  const r = (bd.radius  || 0) * getRadiusDifficultyMult(bd);
  const g = ((bd.gravity || 0) || 5) * _getGravityDiffMult(bd);
  return g * r * r;
}

function computeSOI_m(name){
  const b = bodies[name];
  const od = b?.data?.ORBIT_DATA;
  if(!od || !od.parent) return null;
  const parent = bodies[od.parent];
  if(!parent) return null;

  const bd  = b.data.BASE_DATA      || {};
  const pbd = parent.data.BASE_DATA || {};

  // Difficulty-scaled masses (mirrors Planet.cs: mass = Kepler.GetMass(gravity, radius))
  const mass_b = _effectiveMass(bd);
  const mass_p = _effectiveMass(pbd);
  if(mass_b <= 0 || mass_p <= 0) return null;

  // Difficulty-scaled SMA (mirrors Difficulty.SmaScale applied before SOI computation)
  const sma_eff = effectiveSMA(od);
  if(sma_eff <= 0) return null;

  // multiplierSOI is scaled by soiDifficultyScale[difficulty] then applied to the formula
  // (mirrors Difficulty.ScalePlanetData: planet.orbit.multiplierSOI *= SoiScale(planet))
  const sds      = od.soiDifficultyScale || {};
  const soiDiff  = (sds[viewDiffKey] != null) ? sds[viewDiffKey] : 1.0;
  const soiMult  = (od.multiplierSOI ?? 1.0) * soiDiff;

  // Core formula: SOI = sma × (mass_body / mass_parent)^0.4 × multiplierSOI
  return sma_eff * Math.pow(mass_b / mass_p, 0.4) * soiMult;
}

function _fmtSOI_m(m){
  if(m === null || m === undefined || !isFinite(m)) return null;
  if(m >= 1e9)  return (m/1e9).toFixed(2) + ' Gm';
  if(m >= 1e6)  return (m/1e6).toFixed(2) + ' Mm';
  if(m >= 1e3)  return (m/1e3).toFixed(1) + ' km';
  return m.toFixed(0) + ' m';
}

function updateSOIDisplay(){
  const el = document.getElementById('or-soi-radius');
  if(!el) return;
  if(!selectedBody || !bodies[selectedBody]){el.textContent=''; return;}
  // System centre has no ORBIT_DATA → infinite SOI, skip display
  const od = bodies[selectedBody]?.data?.ORBIT_DATA;
  if(!od || !od.parent){el.textContent=''; return;}
  // Temporarily patch the live multiplier value into the data so computeSOI_m sees it
  const inputVal = parseFloat(document.getElementById('or-soi')?.value);
  const prev = od.multiplierSOI;
  if(!isNaN(inputVal)) od.multiplierSOI = inputVal;
  const soi_m = computeSOI_m(selectedBody);
  od.multiplierSOI = prev; // restore
  const fmt = _fmtSOI_m(soi_m);
  el.textContent = fmt ? '= ' + fmt : '';
}

// ── Debug: survey CLOUDS radial-tiling behavior across every loaded body ──
// Run window.debugCloudsSummary() in the browser console. For each body with
// a CLOUDS texture, prints R/gradH/cloudH (metres) and the derived
// cloudSizeY — the single number that determines whether the texture renders
// as one clean, non-repeating pass (cloudSizeY < 1, e.g. Somber's ring trick)
// or wraps into multiple stacked layers (cloudSizeY >= 1, a normal multi-band
// cloud planet). Use this to check whether an issue is specific to
// single-pass "trick" textures (rings/halos) or shows up on ordinary
// multi-layer cloud planets too — same computation the renderer itself uses,
// just surfaced for every body at once instead of one console log per body
// per render.
window.debugCloudsSummary = function(){
  const rows = [];
  for(const name of Object.keys(bodies)){
    const b = bodies[name];
    const CLD = b.data.ATMOSPHERE_VISUALS_DATA?.CLOUDS;
    if(!CLD || !CLD.texture || CLD.texture === 'None') continue;
    const atmoMult    = getAtmoDifficultyMult(b.data);
    const radiusMult  = getRadiusDifficultyMult(b.data.BASE_DATA);
    const R_m         = ((b.data.BASE_DATA || {}).radius || 1) * radiusMult;
    const atmoPhysH_m = (b.data.ATMOSPHERE_PHYSICS_DATA?.height || 0) * atmoMult;
    const gradH_m     = (b.data.ATMOSPHERE_VISUALS_DATA?.GRADIENT?.height || atmoPhysH_m) * atmoMult;
    const cloudH_m    = Math.max(1, (CLD.height || 1)) * atmoMult;
    const startH_m    = (CLD.startHeight || 0) * atmoMult;
    const widthM      = Math.max(1, (CLD.width || 1)) * atmoMult;
    const cloudSizeY  = (R_m + gradH_m) / cloudH_m;
    const numTiles    = Math.max(1, Math.ceil((R_m + startH_m) * 6.283185307 / widthM - 1e-6));
    rows.push({
      name,
      texture: CLD.texture,
      R_m: Math.round(R_m),
      gradH_m: Math.round(gradH_m),
      cloudH_m: Math.round(cloudH_m),
      startH_m: Math.round(startH_m),
      cloudSizeY: +cloudSizeY.toFixed(4),
      angularTiles: numTiles,
      mode: cloudSizeY < 1 ? 'single-pass (no wrap)' : `multi-pass (~${cloudSizeY.toFixed(2)}x)`
    });
  }
  console.table(rows);
  return rows;
};

// Forces the one-time-per-body [CLD] console log (which includes actual
// rendered physR_px / atmoDisk_px pixel values at the CURRENT zoom level) to
// fire again on the next frame — useful for comparing computed pixel values
// directly against pixels measured off a screenshot. Call with no argument
// to re-log every body with clouds, or window.debugCloudPixelsRefresh('Somber')
// for just one.
window.debugCloudPixelsRefresh = function(name){
  if(!drawViewport._cldDbg) return;
  if(name){ delete drawViewport._cldDbg[name]; }
  else { drawViewport._cldDbg = {}; }
  drawViewport();
};

// ── Live CLOUDS debug panel ───────────────────────────────────────────────
// Defaults match the currently-confirmed-correct rendering exactly (no
// offset, wrap mode, scale=1, angular flip on) — opening the panel changes
// nothing until you actually move a control.
// formulaMode defaults to 'real': v1.y*(_CloudStartY+1) - _CloudStartY, then
// *_CloudSizeY — decoded directly from a RenderDoc capture of the compiled
// SFS/Atmosphere pixel shader (ps_4_0 disassembly), not inferred from
// screenshots. 'legacy' (the old offsetY + v_disc*cloudSizeY*scaleY shape)
// is kept selectable in the panel for comparison / in case v1.y turns out to
// need a different orientation or scale than assumed here.
window._cldDebug = {
  radialFlip: false,
  vInputFlip: false,
  angularFlip: true,
  scaleY: 1,
  offsetY: 0,
  wrapMode: 'wrap', // 'wrap' | 'clamp'
  formulaMode: 'exact' // 'legacy' | 'real' | 'exact' — see formula comment at the render site
};

// window.showCloudDebugPanel() opens a small floating control panel for
// window._cldDebug. Every control forces an immediate re-render (bypassing
// the disc cache, since cacheKey includes all these params) so the effect
// of a change is visible right away. Close with the × or by calling
// window.hideCloudDebugPanel().
window.showCloudDebugPanel = function(){
  if(document.getElementById('cldDebugPanel')) return;
  const panel = document.createElement('div');
  panel.id = 'cldDebugPanel';
  panel.style.cssText = `
    position:fixed; top:70px; right:16px; z-index:99999;
    background:#151515; color:#eee; font:12px/1.4 'Segoe UI', sans-serif;
    border:1px solid #333; border-radius:10px; padding:14px 16px;
    width:280px; box-shadow:0 4px 24px rgba(0,0,0,0.6);
  `;
  const row = (label, control) => `<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin:7px 0;">
    <label style="color:#aaa;">${label}</label>${control}</div>`;
  panel.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
      <b style="font-size:13px;">Cloud/Ring Debug</b>
      <span id="cldDebugClose" style="cursor:pointer;color:#888;padding:0 4px;">✕</span>
    </div>
    ${row('Radial flip (output)', '<input type="checkbox" id="cldFlipR">')}
    ${row('Input flip (v1.y dir)', '<input type="checkbox" id="cldFlipIn">')}
    ${row('Angular flip', '<input type="checkbox" id="cldFlipA">')}
    ${row('Formula', `<select id="cldFormula" style="background:#222;color:#eee;border:1px solid #444;border-radius:4px;">
      <option value="legacy">legacy (offset + v·scale)</option>
      <option value="real">real shader (scale·(v·(start+1)−start))</option>
      <option value="exact">exact (derived, no v1.y guess)</option></select>`)}
    ${row('Wrap mode', `<select id="cldWrapMode" style="background:#222;color:#eee;border:1px solid #444;border-radius:4px;">
      <option value="wrap">wrap (frac)</option><option value="clamp">clamp</option></select>`)}
    ${row('cloudSizeY ×', `<span style="display:flex;align-items:center;gap:6px;">
      <input type="range" id="cldScaleY" min="0.05" max="3" step="0.01" value="1" style="width:80px;">
      <input type="number" id="cldScaleYNum" value="1" step="0.01" style="width:56px;background:#222;color:#eee;border:1px solid #444;border-radius:4px;padding:2px 4px;">
    </span>`)}
    ${row('offset', `<span style="display:flex;align-items:center;gap:6px;">
      <input type="range" id="cldOffsetY" min="-2" max="2" step="0.01" value="0" style="width:80px;">
      <input type="number" id="cldOffsetYNum" value="0" step="0.01" style="width:56px;background:#222;color:#eee;border:1px solid #444;border-radius:4px;padding:2px 4px;">
    </span>`)}
    <div style="display:flex;gap:8px;margin-top:10px;">
      <button id="cldDebugReset" style="flex:1;padding:6px;border:none;border-radius:6px;background:#333;color:#eee;cursor:pointer;">Reset</button>
      <button id="cldDebugLog" style="flex:1;padding:6px;border:none;border-radius:6px;background:#00a8ff;color:#fff;cursor:pointer;">Log values</button>
    </div>
    <div style="color:#666;font-size:10.5px;margin-top:8px;">Changes apply live. Cache is keyed on these values, so nothing is left stale.</div>
  `;
  document.body.appendChild(panel);

  const d = window._cldDebug;
  const $ = id => document.getElementById(id);
  $('cldFlipR').checked = d.radialFlip;
  $('cldFlipIn').checked = d.vInputFlip;
  $('cldFlipA').checked = d.angularFlip;
  $('cldFormula').value = d.formulaMode;
  $('cldWrapMode').value = d.wrapMode;
  $('cldScaleY').value = d.scaleY;
  $('cldScaleYNum').value = d.scaleY;
  $('cldOffsetY').value = d.offsetY;
  $('cldOffsetYNum').value = d.offsetY;

  const refresh = () => { if(drawViewport._cldDbg) drawViewport._cldDbg = {}; drawViewport(); };
  $('cldFlipR').onchange = e => { d.radialFlip = e.target.checked; refresh(); };
  $('cldFlipIn').onchange = e => { d.vInputFlip = e.target.checked; refresh(); };
  $('cldFlipA').onchange = e => { d.angularFlip = e.target.checked; refresh(); };
  $('cldFormula').onchange = e => { d.formulaMode = e.target.value; refresh(); };
  $('cldWrapMode').onchange = e => { d.wrapMode = e.target.value; refresh(); };
  $('cldScaleY').oninput = e => {
    d.scaleY = +e.target.value; $('cldScaleYNum').value = d.scaleY; refresh();
  };
  $('cldScaleYNum').addEventListener('input', e => {
    const v = parseFloat(e.target.value);
    if(isNaN(v)) return;
    d.scaleY = v; $('cldScaleY').value = v; refresh();
  });
  $('cldOffsetY').oninput = e => {
    d.offsetY = +e.target.value; $('cldOffsetYNum').value = d.offsetY; refresh();
  };
  $('cldOffsetYNum').addEventListener('input', e => {
    const v = parseFloat(e.target.value);
    if(isNaN(v)) return;
    d.offsetY = v; $('cldOffsetY').value = v; refresh();
  });
  $('cldDebugReset').onclick = () => {
    d.radialFlip = false; d.vInputFlip = false; d.angularFlip = true; d.scaleY = 1; d.offsetY = 0; d.wrapMode = 'wrap'; d.formulaMode = 'exact';
    $('cldFlipR').checked = false; $('cldFlipIn').checked = false; $('cldFlipA').checked = true; $('cldWrapMode').value = 'wrap'; $('cldFormula').value = 'exact';
    $('cldScaleY').value = 1; $('cldScaleYNum').value = 1;
    $('cldOffsetY').value = 0; $('cldOffsetYNum').value = 0;
    refresh();
  };
  $('cldDebugLog').onclick = () => console.log('[CLD DEBUG]', JSON.parse(JSON.stringify(d)));
  $('cldDebugClose').onclick = () => window.hideCloudDebugPanel();
};

window.hideCloudDebugPanel = function(){
  const p = document.getElementById('cldDebugPanel');
  if(p) p.remove();
};

// ── Reference screenshot overlay ──────────────────────────────────────────
// Same trick that got the Somber/Uzume rings to 0.005 precision (matching
// front-clouds against rings against a real screenshot), generalized: load
// an actual in-game screenshot, lay it semi-transparent (or difference-
// blended, which makes even 1px misalignment glow) directly on top of the
// live editor render, and manually align the PLANET BODY (the reliable,
// debug-panel-independent anchor) between the two with drag/scroll/arrow
// keys. Once the planet bodies coincide exactly, any remaining mismatch in
// the cloud bands is purely down to the cloud debug panel's offset/scale —
// so you can nudge those sliders and watch the bands converge live, instead
// of eyeballing two separate screenshots and typing in a guessed number.
window.showCloudOverlayTool = function(){
  if(document.getElementById('cldOverlayPanel')) return;

  const img = document.createElement('img');
  img.id = 'cldOverlayImg';
  img.style.cssText = `
    position:fixed; left:50%; top:50%; pointer-events:none;
    opacity:0.5; mix-blend-mode:normal; transform-origin:0 0;
    transform:translate(-50%,-50%) scale(1); z-index:99998; user-select:none;
    display:none;
  `;
  document.body.appendChild(img);

  const ov = { x: 0, y: 0, scale: 1, opacity: 0.5, blend: 'normal', dragging: false, dx0: 0, dy0: 0 };
  const applyTransform = () => {
    img.style.left = `calc(50% + ${ov.x}px)`;
    img.style.top  = `calc(50% + ${ov.y}px)`;
    img.style.transform = `translate(-50%,-50%) scale(${ov.scale})`;
    img.style.opacity = ov.opacity;
    img.style.mixBlendMode = ov.blend;
  };

  const panel = document.createElement('div');
  panel.id = 'cldOverlayPanel';
  panel.style.cssText = `
    position:fixed; top:70px; right:310px; z-index:99999;
    background:#151515; color:#eee; font:12px/1.4 'Segoe UI', sans-serif;
    border:1px solid #333; border-radius:10px; padding:14px 16px;
    width:250px; box-shadow:0 4px 24px rgba(0,0,0,0.6);
  `;
  const row = (label, control) => `<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin:7px 0;">
    <label style="color:#aaa;">${label}</label>${control}</div>`;
  panel.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
      <b style="font-size:13px;">Reference Overlay</b>
      <span id="cldOvClose" style="cursor:pointer;color:#888;padding:0 4px;">✕</span>
    </div>
    <input type="file" id="cldOvFile" accept="image/*" style="width:100%;font-size:11px;margin-bottom:8px;">
    ${row('Opacity', '<input type="range" id="cldOvOpacity" min="0" max="1" step="0.01" value="0.5" style="width:120px;">')}
    ${row('Blend', `<select id="cldOvBlend" style="background:#222;color:#eee;border:1px solid #444;border-radius:4px;">
      <option value="normal">normal</option><option value="difference">difference</option>
      <option value="exclusion">exclusion</option></select>`)}
    ${row('Scale', `<span style="display:flex;gap:6px;">
      <input type="range" id="cldOvScale" min="0.1" max="4" step="0.001" value="1" style="width:80px;">
      <input type="number" id="cldOvScaleNum" value="1" step="0.001" style="width:56px;background:#222;color:#eee;border:1px solid #444;border-radius:4px;padding:2px 4px;">
    </span>`)}
    ${row('X / Y', `<span style="display:flex;gap:4px;">
      <input type="number" id="cldOvX" value="0" step="1" style="width:48px;background:#222;color:#eee;border:1px solid #444;border-radius:4px;padding:2px 4px;">
      <input type="number" id="cldOvY" value="0" step="1" style="width:48px;background:#222;color:#eee;border:1px solid #444;border-radius:4px;padding:2px 4px;">
    </span>`)}
    <div style="color:#666;font-size:10.5px;margin-top:8px;line-height:1.5;">
      Drag the image to move, scroll to scale. Arrow keys nudge 1px (hold Shift for 10px) while an X/Y box is focused.
      Align the <b>planet body</b> first — that's the reliable anchor — then compare cloud bands.
    </div>
  `;
  document.body.appendChild(panel);

  const $ = id => document.getElementById(id);
  $('cldOvFile').onchange = e => {
    const f = e.target.files[0];
    if(!f) return;
    const reader = new FileReader();
    reader.onload = ev => { img.src = ev.target.result; img.style.display = 'block'; };
    reader.readAsDataURL(f);
  };
  $('cldOvOpacity').oninput = e => { ov.opacity = +e.target.value; applyTransform(); };
  $('cldOvBlend').onchange = e => { ov.blend = e.target.value; applyTransform(); };
  $('cldOvScale').oninput = e => { ov.scale = +e.target.value; $('cldOvScaleNum').value = ov.scale; applyTransform(); };
  $('cldOvScaleNum').addEventListener('input', e => {
    const v = parseFloat(e.target.value); if(isNaN(v)) return;
    ov.scale = v; $('cldOvScale').value = v; applyTransform();
  });
  $('cldOvX').addEventListener('input', e => { ov.x = +e.target.value || 0; applyTransform(); });
  $('cldOvY').addEventListener('input', e => { ov.y = +e.target.value || 0; applyTransform(); });
  [$('cldOvX'), $('cldOvY')].forEach(inp => {
    inp.addEventListener('keydown', e => {
      if(e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
      e.preventDefault();
      const step = e.shiftKey ? 10 : 1;
      const delta = (e.key === 'ArrowUp' ? 1 : -1) * step * (inp.id === 'cldOvY' ? -1 : 1);
      inp.value = (parseFloat(inp.value) || 0) + delta;
      inp.dispatchEvent(new Event('input'));
    });
  });
  $('cldOvClose').onclick = () => {
    panel.remove(); img.remove();
  };

  // Drag to reposition
  img.style.pointerEvents = 'auto';
  img.style.cursor = 'move';
  img.addEventListener('mousedown', e => {
    ov.dragging = true; ov.dx0 = e.clientX - ov.x; ov.dy0 = e.clientY - ov.y;
    e.preventDefault();
  });
  window.addEventListener('mousemove', e => {
    if(!ov.dragging) return;
    ov.x = e.clientX - ov.dx0; ov.y = e.clientY - ov.dy0;
    $('cldOvX').value = Math.round(ov.x); $('cldOvY').value = Math.round(ov.y);
    applyTransform();
  });
  window.addEventListener('mouseup', () => { ov.dragging = false; });
  img.addEventListener('wheel', e => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.02 : 0.98;
    ov.scale = Math.max(0.05, Math.min(10, ov.scale * factor));
    $('cldOvScale').value = ov.scale; $('cldOvScaleNum').value = ov.scale.toFixed(3);
    applyTransform();
  }, { passive: false });

  applyTransform();
};

window.hideCloudOverlayTool = function(){
  const p = document.getElementById('cldOverlayPanel');
  const i = document.getElementById('cldOverlayImg');
  if(p) p.remove();
  if(i) i.remove();
};

// Throttle drawViewport to one RAF per call — prevents stacking on rapid scroll/zoom
let _drawPending = false;
function drawViewport(){
  if(_drawPending) return;
  _drawPending = true;
  requestAnimationFrame(() => { _drawPending = false; _drawViewportNow(); });
}

// Terrain quality setting — 'detailed' (default, arc culling off, full
// correctness) or 'optimized' (arc culling on, faster but currently has a
// known close-zoom silhouette bug — see notes at the _canArcCull gate).
// Call this to change and persist the setting; window.terrainQuality is read
// directly elsewhere for the per-frame gate, this just keeps localStorage in
// sync and triggers a redraw so the change is visible immediately.
//
// Also drives the N% vertex-density slider (window.terrainDetail, see
// js/tools.js setTerrainDetail): Optimized defaults it to 30%, Detailed to
// 100%, matching how the two settings were already related before this was
// a named toggle. The person can still fine-tune the % afterward — this
// just sets a sensible starting point for whichever quality mode they pick.
function setTerrainQuality(mode){
  if (mode !== 'detailed' && mode !== 'optimized') return;
  window.terrainQuality = mode;
  try { localStorage.setItem('sfs_terrain_quality', mode); } catch(e) {}
  if (typeof setTerrainDetail === 'function') {
    setTerrainDetail(mode === 'detailed' ? 100 : 30);
  }
  const lbl = document.getElementById('terrain-quality-label');
  if (lbl) lbl.textContent = mode === 'detailed' ? 'DETAILED' : 'OPTIMIZED';
  if (typeof _syncGraphicsSettingsUI === 'function') _syncGraphicsSettingsUI();
  drawViewport();
}

// Dev-only diagnostics (Settings > Graphics > Developer section). All off
// by default and persisted so a visitor who never opens that section never
// sees the overlay or has culling/LOD behavior changed on them.
function setDbgTerrainOverlay(on){
  window.dbgTerrainOverlay = !!on;
  try { localStorage.setItem('sfs_dbg_terrain_overlay', on ? '1' : '0'); } catch(e) {}
  if (!on && drawViewport._dbgEl) drawViewport._dbgEl.style.display = 'none';
  if (typeof _syncGraphicsSettingsUI === 'function') _syncGraphicsSettingsUI();
  drawViewport();
}
function setDbgArcCull(on){
  window.dbgArcCull = !!on;
  try { localStorage.setItem('sfs_dbg_arc_cull', on ? '1' : '0'); } catch(e) {}
  if (typeof _syncGraphicsSettingsUI === 'function') _syncGraphicsSettingsUI();
  drawViewport();
}
function setDbgLOD(on){
  window.dbgLOD = !!on;
  try { localStorage.setItem('sfs_dbg_lod', on ? '1' : '0'); } catch(e) {}
  if (typeof _syncGraphicsSettingsUI === 'function') _syncGraphicsSettingsUI();
  drawViewport();
}
// Which visible-arc algorithm arc culling uses — 'edge' (original
// edge-intersection method, default) or 'binary' (new binary-search method,
// see _computeVisibleArcBinarySearch — numerically robust at extreme zoom,
// being A/B tested against the close-zoom silhouette bug).
function setDbgArcCullMethod(method){
  if (method !== 'edge' && method !== 'binary') return;
  window.dbgArcCullMethod = method;
  try { localStorage.setItem('sfs_dbg_arc_cull_method', method); } catch(e) {}
  if (typeof _syncGraphicsSettingsUI === 'function') _syncGraphicsSettingsUI();
  drawViewport();
}
// Load persisted values once at startup. Unset/missing keys keep the
// existing defaults ('detailed' quality, dbgArcCull/dbgLOD both true i.e.
// "on" meaning not forced off, dbgTerrainOverlay false/undefined i.e. hidden,
// dbgArcCullMethod 'edge' i.e. the original method).
(function _loadTerrainDevSettings(){
  try {
    const q = localStorage.getItem('sfs_terrain_quality');
    if (q === 'detailed' || q === 'optimized') window.terrainQuality = q;
    const ov = localStorage.getItem('sfs_dbg_terrain_overlay');
    if (ov != null) window.dbgTerrainOverlay = ov === '1';
    const ac = localStorage.getItem('sfs_dbg_arc_cull');
    if (ac != null) window.dbgArcCull = ac === '1';
    const lod = localStorage.getItem('sfs_dbg_lod');
    if (lod != null) window.dbgLOD = lod === '1';
    const acm = localStorage.getItem('sfs_dbg_arc_cull_method');
    if (acm === 'edge' || acm === 'binary') window.dbgArcCullMethod = acm;
  } catch(e) {}
  const lbl = document.getElementById('terrain-quality-label');
  if (lbl) lbl.textContent = (window.terrainQuality === 'optimized') ? 'OPTIMIZED' : 'DETAILED';
})();

// ── Post-processing helpers (mirrors SFS PostProcessingModule.Evaluate + SetAmbient) ──
function _lerpPPKey(a, b, t){
  const L = (x,y) => x + (y-x)*t;
  return { height:L(a.height,b.height), shadowIntensity:L(a.shadowIntensity,b.shadowIntensity),
    starIntensity:L(a.starIntensity,b.starIntensity), hueShift:L(a.hueShift,b.hueShift),
    saturation:L(a.saturation,b.saturation), contrast:L(a.contrast,b.contrast),
    red:L(a.red,b.red), green:L(a.green,b.green), blue:L(a.blue,b.blue) };
}
function getPostProcessKey(bodyData, altM){
  const keys = bodyData?.POST_PROCESSING?.keys;
  if(!keys || keys.length === 0) return null;
  if(altM <= keys[0].height) return keys[0];
  if(altM >= keys[keys.length-1].height) return keys[keys.length-1];
  for(let i=0;i<keys.length-1;i++){
    if(altM < keys[i+1].height){
      const t = (altM - keys[i].height) / (keys[i+1].height - keys[i].height);
      return _lerpPPKey(keys[i], keys[i+1], t);
    }
  }
  return keys[keys.length-1];
}
// ── Post-processing — exact reproduction of the decompiled pixel shader ──
// (hash fa05cde4-eae677f2-8903d1e7-1a8bef02). Constant mapping confirmed via RenderDoc +
// disassembly: cb0[2].x=Hue(deg), cb0[2].y=Saturation, cb0[2].z=Contrast, cb0[3].xyz=Multiplier
// (matches PostProcessing.cs SetAmbient's SetFloat(Hue/Saturation/Contrast) + SetVector(Multiplier)
// property names exactly). Real order, from the disassembly: CONTRAST -> HUE ROTATE -> SATURATION -> TINT.
// This previously ran as CSS `hue-rotate() saturate() contrast()` (wrong order — hue first, contrast
// last) using three formulas that don't match the game's:
//   - CONTRAST (steps 1-4): the shader is ASYMMETRIC — `movc r0.xyz, (0.5<original), (c-0.5)*contrast+0.5, original`
//     means channels <=0.5 pass through completely UNCHANGED; only channels >0.5 get scaled. CSS
//     contrast() scales the whole range symmetrically — a different function, not just a different order.
//   - HUE ROTATION (steps 6-15): the 0.577350 constant is 1/sqrt(3) — this is Rodrigues' rotation
//     formula rotating the RGB vector about the UNIFORM gray axis (1,1,1)/sqrt(3):
//       result = color*cosT + axis*(axis.color)*(1-cosT) + (axis x color)*sinT
//     CSS hue-rotate() also rotates about the gray diagonal but per the W3C spec uses a perceptually-
//     weighted (~Rec.709) construction instead of this uniform axis — different matrix, different
//     result at the same angle. Not an HSL/HSV shift either.
//   - SATURATION (steps 16-18): lerp(luma, color, saturation) with luma = 0.22R+0.707G+0.071B — a
//     DIFFERENT luma weighting than the 0.3/0.59/0.11 SetAmbient uses to build the tint Multiplier
//     (two distinct luma constants really are used in two different places; confirmed by the raw
//     0.220000/0.707000/0.071000 immediates in the disassembly vs. the C# SetAmbient formula).
//   - TINT (step 19): a plain multiply by Multiplier, NO clamp. The previous code additionally
//     divided the tint by max(mr,mg,mb,1) to prevent >1 brightness — that clamp has no basis in the
//     shader; the game lets channels legitimately blow out past 1.0 here.
// Hue-rotate + saturation + tint are all linear (matrix) ops, so they're composed into ONE
// feColorMatrix. Contrast is non-linear but has exactly one breakpoint (0.5), so it's reproduced
// with ZERO approximation error via a 3-point feComponentTransfer table: identity on [0,0.5],
// (x-0.5)*contrast+0.5 on [0.5,1] — a piecewise-linear function is exactly what SVG's "table" type
// interpolates between control points, and putting a point exactly at x=0.5 needs only 3 samples.
const PP_BRIGHTNESS_BOOST = 1.0; // editor-only extra multiplier on top of the exact game math; 1.0 = no-op

function _buildPostProcessMatrix(hueDeg, sat, r, g, b){
  const rad = hueDeg * Math.PI / 180;
  const c = Math.cos(rad), s = Math.sin(rad);
  const a = 1 / Math.sqrt(3);
  const k = (1 - c) / 3;
  // Hue-rotation matrix (Rodrigues, uniform axis (1,1,1)/sqrt(3)) — v1 = H * v0
  const H = [
    [c + k,       k - s*a,     k + s*a],
    [k + s*a,     c + k,       k - s*a],
    [k - s*a,     k + s*a,     c + k]
  ];
  // Saturation matrix (luma weights 0.22/0.707/0.071 — matches this shader's saturation step
  // specifically, NOT the 0.3/0.59/0.11 used below for the tint) — v2 = S * v1
  const lr = 0.22, lg = 0.707, lb = 0.071;
  const S = [
    [sat + (1-sat)*lr,  (1-sat)*lg,        (1-sat)*lb      ],
    [(1-sat)*lr,        sat + (1-sat)*lg,  (1-sat)*lb      ],
    [(1-sat)*lr,        (1-sat)*lg,        sat + (1-sat)*lb]
  ];
  // Compose hue then saturation: M = S * H
  const M = [[0,0,0],[0,0,0],[0,0,0]];
  for(let i=0;i<3;i++) for(let j=0;j<3;j++)
    M[i][j] = S[i][0]*H[0][j] + S[i][1]*H[1][j] + S[i][2]*H[2][j];
  // Tint (Multiplier from SetAmbient: red/luma, green/luma, blue/luma, luma via 0.3/0.59/0.11), no
  // clamp — applied last, as a left-multiply by diag(mr,mg,mb), i.e. scale each output row.
  const lumaT = 0.3*r + 0.59*g + 0.11*b || 1;
  const mr = (r/lumaT) * PP_BRIGHTNESS_BOOST, mg = (g/lumaT) * PP_BRIGHTNESS_BOOST, mb = (b/lumaT) * PP_BRIGHTNESS_BOOST;
  M[0] = M[0].map(v => v*mr);
  M[1] = M[1].map(v => v*mg);
  M[2] = M[2].map(v => v*mb);
  return M;
}

// SVG filter injected into <defs>: feComponentTransfer (exact asymmetric contrast) into
// feColorMatrix (composed hue x saturation x tint). Re-created only when values change.
let _ppSvgFilter = null;
let _ppSvgFilterKey = '';
function _ensureSvgFilter(filterId, contrast, M){
  const key = contrast.toFixed(4) + '|' + M.map(row => row.map(v => v.toFixed(5)).join(',')).join('|');
  if(key === _ppSvgFilterKey && _ppSvgFilter) return;
  _ppSvgFilterKey = key;
  if(_ppSvgFilter) _ppSvgFilter.remove();
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('style','position:absolute;width:0;height:0;overflow:hidden');
  svg.setAttribute('aria-hidden','true');
  const defs = document.createElementNS(ns, 'defs');
  const filter = document.createElementNS(ns, 'filter');
  filter.setAttribute('id', filterId);
  filter.setAttribute('color-interpolation-filters','sRGB');

  // Stage 1: asymmetric contrast (shader steps 1-4) — exact via a 3-point piecewise-linear table
  const top = Math.max(0, 0.5 + 0.5*contrast);
  const feCT = document.createElementNS(ns, 'feComponentTransfer');
  ['feFuncR','feFuncG','feFuncB'].forEach(tag => {
    const f = document.createElementNS(ns, tag);
    f.setAttribute('type','table');
    f.setAttribute('tableValues', `0 0.5 ${top}`);
    feCT.appendChild(f);
  });
  filter.appendChild(feCT);

  // Stage 2: composed hue-rotation x saturation x tint (shader steps 6-19)
  const [[m00,m01,m02],[m10,m11,m12],[m20,m21,m22]] = M;
  const fe = document.createElementNS(ns, 'feColorMatrix');
  fe.setAttribute('type','matrix');
  fe.setAttribute('values',
    `${m00} ${m01} ${m02} 0 0  ` +
    `${m10} ${m11} ${m12} 0 0  ` +
    `${m20} ${m21} ${m22} 0 0  ` +
    `0 0 0 1 0`);
  filter.appendChild(fe);

  defs.appendChild(filter);
  svg.appendChild(defs);
  document.body.appendChild(svg);
  _ppSvgFilter = svg;
}

function _applyPostProcessingOverlay(ctx, w, h, key){
  if(!key) return;
  const hueDeg = key.hueShift || 0;
  const sat    = key.saturation ?? 1;
  const con    = key.contrast   ?? 1;
  const r = key.red ?? 1, g = key.green ?? 1, b = key.blue ?? 1;
  const M = _buildPostProcessMatrix(hueDeg, sat, r, g, b);
  const FILTER_ID = '_sfs_pp_full';
  _ensureSvgFilter(FILTER_ID, con, M);
  ctx.canvas.style.filter = `url(#${FILTER_ID})`;
}

// Called when post-proc is disabled to remove the canvas filter
function _clearPostProcessingFilter(){
  if(vp) vp.style.filter = '';
}
function _drawViewportNow(){
  // NOTE: _terrainClipCache is intentionally NOT cleared here. Its cache key
  // (bodyName|N|radius_m|arcKey — see _getUnitTerrainPath) already excludes
  // screen position and zoom level by design: paths are built in unit-radius
  // space and placed via translate+scale at draw time, so a cached Path2D
  // stays valid across camera movement and only needs rebuilding when N or
  // the visible arc genuinely changes. Wiping the whole cache every frame
  // defeated that entirely — every visible terrain body's Path2D (often
  // thousands of lineTo calls for a large planet) was being rebuilt from
  // scratch on every single frame, which was the dominant cost of the
  // zoom/pan stutter. The cache is still bounded (300-entry eviction) and
  // still explicitly invalidated on real changes via invalidateTerrainCache().
  // Self-heal: if canvas has no size, set it now
  if(!vp.width || !vp.height){
    vp.width  = window.innerWidth;
    vp.height = Math.max(100, window.innerHeight - 76);
  }
  // Always clear the PP CSS filter at frame start — it is re-applied below only if active.
  // This prevents stale filters persisting across frames when PP is toggled or no body found.
  vp.style.filter = '';
  const _prevSMAScale = _cachedSMAScale;
  _cachedSMAScale = null; // invalidate per-frame cache
  const _newSMAScale = getSMAScale();
  // When getSMAScale changes (body added/removed changing maxSMA), all bodyWorldPos values
  // rescale proportionally. Compensate vpOffX/Y and unlocked overlay worldX/Y by the same
  // ratio so nothing visually jumps.
  if (_prevSMAScale !== null && _prevSMAScale !== _newSMAScale && _newSMAScale > 0) {
    const ratio = _newSMAScale / _prevSMAScale;
    vpOffX *= ratio;
    vpOffY *= ratio;
    if (typeof _imgOverlays !== 'undefined') {
      _imgOverlays.forEach(ov => {
        if (!ov.lockToBody || ov.lockToBody === 'None') {
          ov.worldX *= ratio;
          ov.worldY *= ratio;
        }
        // worldW/H drive screen size (worldW * vpZ) — rescale for all overlays
        ov.worldW *= ratio;
        ov.worldH *= ratio;
      });
    }
  }
  ctx2.clearRect(0, 0, vp.width, vp.height);

  const names = Object.keys(bodies);
  if(names.length === 0) return;

  // ── STEP 1: compute all world positions (centre = origin) ──
  // Multi-pass so moons (children of planets) resolve correctly
  // Reset the module-level position map for this frame
  Object.keys(bodyWorldPos).forEach(k => delete bodyWorldPos[k]);
  // Seed center at origin; bodies with no orbit data also sit at origin
  names.forEach(n => { if(bodies[n].isCenter || !bodies[n].data.ORBIT_DATA) bodyWorldPos[n] = {x:0, y:0}; });
  // Also seed any parent name that's referenced but not in bodies (e.g. 'Sun' fallback)
  names.forEach(n => {
    const par = bodies[n].data.ORBIT_DATA?.parent;
    if(par && !bodies[par]) bodyWorldPos[par] = {x:0, y:0};
  });

  // Up to 5 passes to resolve nested parents
  for(let pass=0; pass<5; pass++){
    names.forEach(name => {
      if(bodyWorldPos[name]) return;
      const od = bodies[name].data.ORBIT_DATA;
      if(!od) return;
      const parentPos = bodyWorldPos[od.parent];
      if(!parentPos) return; // parent not yet resolved
      const smaPx = smaToPixels(effectiveSMA(od));
      const ecc = Math.min(od.eccentricity||0, 0.999);
      const aop = od.argumentOfPeriapsis||0;
      const g = orbitGeometry(smaPx, ecc, aop, parentPos.x, parentPos.y);
      bodyWorldPos[name] = {x: g.bodyX, y: g.bodyY};
    });
  }

  // ── STEP 3: compute LOD visibility/fade, then draw bodies ──
  // Every orbiting body fades based on its OWN screen-orbit size.
  // Tiny orbit on screen = too crowded to show = fade out.
  // Center body is always fully visible.
  // Selected body is always fully visible.
  //
  // Thresholds (screen pixels of the body's own SMA):
  //   < BODY_FADE_MIN  → invisible
  //   > BODY_FADE_MAX  → fully visible
  //   label fades in even later (at 2× BODY_FADE_MAX)

  const BODY_FADE_MIN = 20;   // own orbit px: below this body is hidden
  const BODY_FADE_MAX = 60;   // own orbit px: above this body is fully visible

  const bodyVisible  = {};
  const bodyFadeVal  = {};
  const labelFadeVal = {};

  names.forEach(name => {
    const b = bodies[name];
    const od = b.data.ORBIT_DATA;

    // Center: always fully visible
    if(b.isCenter || !od){
      bodyVisible[name]=true; bodyFadeVal[name]=1; labelFadeVal[name]=1; return;
    }

    // Own orbit in screen pixels
    const ownSMApx = smaToPixels(effectiveSMA(od)) * vpZ;

    const f  = Math.max(0, Math.min(1, (ownSMApx - BODY_FADE_MIN) / (BODY_FADE_MAX - BODY_FADE_MIN)));
    const lf = Math.max(0, Math.min(1, (ownSMApx - BODY_FADE_MAX) / BODY_FADE_MAX));

    bodyVisible[name]  = f > 0;
    bodyFadeVal[name]  = f;
    labelFadeVal[name] = lf;

    // Front-cloud decorator exemption: bodies whose only job is to paint a
    // FRONT_CLOUDS_DATA disc over their parent (day/night terminators, city
    // lights, bioluminescence) are deliberately placed at a very small or
    // near-zero SMA — that's the whole trick, not an accident. The own-SMA
    // fade above exists to hide clutter from real, distant satellites; it
    // has no business culling a body with no independent presence of its
    // own. Without this, any decorator body orbiting inside BODY_FADE_MIN
    // (~20px on screen) is thrown out before it ever reaches the draw loop,
    // silently deleting the whole effect (e.g. Earth's city lights, or a
    // close-orbit shadow disc) instead of just fading its OWN disc/label,
    // which is all the original fade was ever meant to do.
    const fcd = b.data.FRONT_CLOUDS_DATA;
    if(fcd && fcd.cloudsTexture && fcd.cloudsTexture !== 'None'){
      bodyVisible[name] = true;
      bodyFadeVal[name] = 1;
      // Label fade stays as computed — we still don't want a label floating
      // over the parent for a body that's invisible by design.
    }

    // Selected body always fully shown
    if(selectedBody === name){ bodyVisible[name]=true; bodyFadeVal[name]=1; labelFadeVal[name]=1; }
  });

  bodyVisibleMap = bodyVisible;

  // ── STEP 2: draw orbit ellipses ──
  const W = vp.width, H = vp.height;
  const diagPx = Math.hypot(W, H);
  // Pre-parse body colours once (cached per body color string, not per frame)
  if(!drawViewport._orbitRGBCache) drawViewport._orbitRGBCache = {};
  const orbitRGB = {};
  {
    // Only create the temp canvas when there's a cache miss
    let tmp = null, tc = null;
    names.forEach(name => {
      const colorStr = bodies[name].color.split(',')[0].trim();
      if(!drawViewport._orbitRGBCache[colorStr]){
        if(!tmp){ tmp = document.createElement('canvas'); tmp.width=1; tmp.height=1; tc = tmp.getContext('2d'); }
        tc.clearRect(0,0,1,1); tc.fillStyle = colorStr; tc.fillRect(0,0,1,1);
        const d = tc.getImageData(0,0,1,1).data;
        drawViewport._orbitRGBCache[colorStr] = [d[0], d[1], d[2]];
      }
      orbitRGB[name] = drawViewport._orbitRGBCache[colorStr];
    });
  }

  // Additive compositing — overlapping orbits brighten naturally
  ctx2.save();
  ctx2.globalCompositeOperation = 'lighter';

  names.forEach(name => {
    const b = bodies[name];
    const od = b.data.ORBIT_DATA;
    if(!od || b.isCenter) return;
    if((od.direction ?? 1) === 0) return; // stationary — no orbit ellipse
    const fade = bodyFadeVal[name] ?? 1;
    if(fade === 0 && selectedBody !== name) return;

    const smaPx = smaToPixels(effectiveSMA(od));
    const rxS = smaPx * vpZ;
    if(rxS < 0.5) return; // sub-pixel — skip

    const ecc = Math.min(od.eccentricity||0, 0.999);
    const aop = od.argumentOfPeriapsis||0;
    const parentPos = bodyWorldPos[od.parent] || {x:0,y:0};
    const g = orbitGeometry(smaPx, ecc, aop, parentPos.x, parentPos.y);
    const sc = worldToScreen(g.ellCX, g.ellCY);
    const ryS = g.ry * vpZ;

    // Off-screen cull: ellipse bounding box vs viewport (with margin)
    const margin = 4;
    if(sc.x + rxS < -margin || sc.x - rxS > W + margin ||
       sc.y + ryS < -margin || sc.y - ryS > H + margin) return;

    const isSelected = selectedBody === name;
    const [cr,cg,cb] = orbitRGB[name];
    const alpha = isSelected ? Math.min(1, 0.8 * fade) : Math.min(1, 0.22 * fade);

    ctx2.save();
    ctx2.strokeStyle = `rgba(${cr},${cg},${cb},${alpha})`;
    ctx2.lineWidth = isSelected ? 2 : 1;
    ctx2.beginPath();

    if(rxS > diagPx * 0.5) {
      // Zoomed in: ellipse is larger than viewport.
      // ctx2.ellipse() on a giant arc is slow because the browser bezier-approximates
      // the full curve. Instead: manually tessellate ONLY the visible arc window.

      // Direction from ellipse centre toward viewport centre, in ellipse-local space
      const cosRot = Math.cos(-g.angle), sinRot = Math.sin(-g.angle);
      const toVX = W * 0.5 - sc.x;
      const toVY = H * 0.5 - sc.y;
      const lx = toVX * cosRot - toVY * sinRot;
      const ly = toVX * sinRot + toVY * cosRot;
      // Parametric angle pointing toward viewport centre
      const baseAngle = Math.atan2(ly / (ryS || 1), lx / (rxS || 1));
      // Half-angle of arc to draw: enough to cover the screen plus 20% margin
      const halfAngle = Math.min(Math.PI, (diagPx * 2.4) / Math.max(rxS, ryS));

      const startA = baseAngle - halfAngle;
      const endA   = baseAngle + halfAngle;
      const segs   = 48; // fixed cost regardless of zoom
      const step   = (endA - startA) / segs;
      const cosG = Math.cos(g.angle), sinG = Math.sin(g.angle);
      for(let i = 0; i <= segs; i++){
        const t  = startA + i * step;
        const ex = rxS * Math.cos(t);
        const ey = ryS * Math.sin(t);
        const sx = sc.x + ex * cosG - ey * sinG;
        const sy = sc.y + ex * sinG + ey * cosG;
        i === 0 ? ctx2.moveTo(sx, sy) : ctx2.lineTo(sx, sy);
      }
    } else {
      // Small enough — native ellipse is fast and smooth
      ctx2.translate(sc.x, sc.y);
      ctx2.rotate(g.angle);
      ctx2.ellipse(0, 0, rxS, ryS, 0, 0, Math.PI * 2);
    }

    ctx2.stroke();
    ctx2.restore();
  });

  ctx2.restore(); // end lighter composite

  // ── Distance rings ────────────────────────────────────────────────────────
  // Concentric circles around the SELECTED body (or centre if nothing selected).
  // Only drawn when the setting is enabled (localStorage sfs_dist_rings).
  if(localStorage.getItem('sfs_dist_rings') !== '0'){
    // Determine ring centre: prefer selected body, fall back to system centre
    const _ringBodyName = (typeof selectedBody !== 'undefined' && selectedBody && bodies[selectedBody])
      ? selectedBody
      : names.find(n => bodies[n].isCenter);
    if(_ringBodyName){
      const _rWP = bodyWorldPos[_ringBodyName] || {x:0, y:0};
      const _cSP = worldToScreen(_rWP.x, _rWP.y);
      const _AU      = 1.496e11;
      const _smaScl  = getSMAScale();

      // Use configurable ring list
      const _ringAUs  = typeof _getDistRingsCfg === 'function' ? _getDistRingsCfg() : [0.1,0.25,0.5,1,2,5,10,20,50,100,500,1000];
      const _RINGS = _ringAUs.map(au => ({
        m: _AU * au,
        label: typeof _ringLabel === 'function' ? _ringLabel(au) : au + ' AU',
      }));

      const _diagPx2 = Math.hypot(vp.width, vp.height);

      ctx2.save();
      ctx2.setLineDash([4, 6]);
      ctx2.lineWidth = 0.7;

      for(const {m, label} of _RINGS){
        const _rpx = m * _smaScl * vpZ;
        if(_rpx < 20 || _rpx > _diagPx2 * 4) continue;

        const _fadeIn    = Math.min(1, (_rpx - 20) / 20);
        const _coverage  = Math.min(1, _diagPx2 / _rpx);
        const _alpha     = _fadeIn * Math.min(1, _coverage * 3) * 0.35;
        if(_alpha < 0.01) continue;

        ctx2.strokeStyle = `rgba(120,200,255,${_alpha})`;
        ctx2.beginPath();
        ctx2.arc(_cSP.x, _cSP.y, _rpx, 0, Math.PI * 2);
        ctx2.stroke();

        if(_rpx < _diagPx2 * 1.5 && _alpha > 0.05){
          const _lx = _cSP.x;
          const _ly = _cSP.y - _rpx;
          if(_lx >= 0 && _lx <= vp.width && _ly >= -10 && _ly <= vp.height){
            ctx2.globalAlpha = _alpha * 2.2;
            ctx2.fillStyle = 'rgba(120,200,255,1)';
            ctx2.font = '10px monospace';
            ctx2.textAlign = 'center';
            ctx2.textBaseline = 'bottom';
            ctx2.fillText(label, _lx, _ly - 2);
            ctx2.globalAlpha = 1;
          }
        }
      }

      ctx2.restore();
    }
  }
  // ── End distance rings ────────────────────────────────────────────────────

  // ── Habitable-zone gradient band (Universe Sandbox style) ───────────────
  // Draws concentric red→green→blue color bands around the star, using the
  // same inverse-square-law HZ math as the Habitability Visualizer modal
  // (js/utils.js: _hzGetViewportZone / HZ_FLUX_INNER / HZ_FLUX_OUTER).
  // Rendered as three overlapping radial gradients rather than hard-edged
  // rings so the transition reads as a continuous temperature gradient
  // (too-hot → habitable → too-cold), matching the "soft glow" look of
  // Universe Sandbox's HZ overlay rather than a technical diagram ring.
  if(localStorage.getItem('sfs_hz_band') === '1' && typeof _hzGetViewportZone === 'function'){
    const _hz = _hzGetViewportZone();
    if(_hz && bodyWorldPos[_hz.starName]){
      const _hzWP  = bodyWorldPos[_hz.starName];
      const _hzSP  = worldToScreen(_hzWP.x, _hzWP.y);
      const _hzScl = getSMAScale() * vpZ;
      const _innerPx = _hz.inner_m * _hzScl;
      const _outerPx = _hz.outer_m * _hzScl;
      // Inner/outer glow radii — extend a bit past the HZ edges themselves so
      // the red (too-hot) and blue (too-cold) zones are visually legible
      // rather than clipping exactly at the boundary. Scaled relative to the
      // band width so it looks proportional whether the HZ is a tight ring
      // (hot O/B star) or a huge span (dim M dwarf).
      const _bandWidth = Math.max(1, _outerPx - _innerPx);
      const _hotEdgePx  = Math.max(1, _innerPx - _bandWidth * 0.6);
      const _coldEdgePx = _outerPx + _bandWidth * 1.4;

      const _diagPx3 = Math.hypot(vp.width, vp.height);
      if(_coldEdgePx > 8 && _hotEdgePx < _diagPx3 * 3){
        ctx2.save();
        // Fade the whole overlay in as it grows on-screen, same shape as the
        // distance-rings fade, so it doesn't pop in harshly when zooming.
        const _hzFadeIn = Math.min(1, Math.max(0, (_outerPx - 8) / 24));
        ctx2.globalAlpha = _hzFadeIn * 0.55;
        ctx2.globalCompositeOperation = 'screen'; // additive-ish glow over dark space bg

        const grad = ctx2.createRadialGradient(_hzSP.x, _hzSP.y, 0, _hzSP.x, _hzSP.y, _coldEdgePx);
        // Stops expressed as fractions of _coldEdgePx (the gradient's outer radius).
        const _fracHot   = Math.min(0.98, _hotEdgePx  / _coldEdgePx);
        const _fracInner = Math.min(0.98, _innerPx    / _coldEdgePx);
        const _fracOuter = Math.min(0.99, _outerPx    / _coldEdgePx);
        grad.addColorStop(0,                          'rgba(255,70,40,0.85)');   // near star: scorching red
        grad.addColorStop(Math.max(0.001,_fracHot),   'rgba(255,140,40,0.35)'); // warming toward HZ
        grad.addColorStop(Math.max(_fracHot+0.001,_fracInner), 'rgba(90,230,110,0.55)'); // HZ inner edge: green
        grad.addColorStop((_fracInner+_fracOuter)/2,  'rgba(70,210,160,0.55)'); // HZ midpoint
        grad.addColorStop(Math.max(_fracInner+0.001,_fracOuter), 'rgba(80,160,255,0.30)'); // HZ outer edge: cooling to blue
        grad.addColorStop(1,                          'rgba(60,90,220,0)');     // fades to transparent

        ctx2.fillStyle = grad;
        ctx2.beginPath();
        ctx2.arc(_hzSP.x, _hzSP.y, _coldEdgePx, 0, Math.PI * 2);
        ctx2.fill();

        ctx2.restore();

        // Crisp boundary lines at the true inner/outer HZ edges — helps
        // precisely place a planet even though the fill itself is a soft
        // gradient. Faint, dashed, same visual language as distance rings.
        if(_innerPx > 8){
          ctx2.save();
          ctx2.globalAlpha = _hzFadeIn * 0.5;
          ctx2.strokeStyle = 'rgba(120,255,150,0.8)';
          ctx2.setLineDash([3,5]);
          ctx2.lineWidth = 1;
          ctx2.beginPath(); ctx2.arc(_hzSP.x, _hzSP.y, _innerPx, 0, Math.PI*2); ctx2.stroke();
          ctx2.beginPath(); ctx2.arc(_hzSP.x, _hzSP.y, _outerPx, 0, Math.PI*2); ctx2.stroke();
          ctx2.restore();
        }
      }
    }
  }
  // ── End habitable-zone band ──────────────────────────────────────────────


  const centerName2 = names.find(n => bodies[n].isCenter);
  const centerR_m = centerName2 ? ((bodies[centerName2].data.BASE_DATA||{}).radius || 1) : 1;
  const CENTER_PX = BODY_PX['star'];

  // ── Draw order: parents before children, then positionZ among siblings ──
  // Object.keys(bodies) has no meaningful order — it just reflects import/creation
  // order — so with no sort at all, a moon that happens to come before its planet
  // in the zip gets drawn (and thus visually painted over) first, hiding its own
  // effects behind the planet. This matters most for the "invisible moon with
  // front clouds" day/night trick: the moon's front-cloud disc must paint AFTER
  // the body it's decorating, which only happens reliably if we draw the orbit
  // hierarchy root-to-leaf.
  //
  // Hierarchy depth alone isn't the whole story, though. The actual game
  // (FrontClouds.cs) gives every front-cloud layer the exact same sortingOrder
  // (200) on every body — the ONLY thing that ever differentiates draw order
  // between them is each layer's own world Z, i.e. planet.data.frontClouds.
  // positionZ (Vector3.forward * positionZ, so more-negative Z sits closer to
  // camera and draws on top). Advanced setups stack multiple invisible moons
  // on the SAME parent to fake e.g. clouds (positionZ +5000, further back) +
  // a day/night terminator (positionZ ~0, middle) + city lights (positionZ
  // -5000, frontmost) — three siblings all at the same hierarchy depth, whose
  // correct relative order depends entirely on positionZ, not on which was
  // imported first. So: depth is still the primary (coarse) key, but among
  // bodies at the same depth we now break ties by positionZ — more positive
  // sorts earlier (drawn first/behind), more negative sorts later (drawn
  // last/in front) — matching the game exactly. Bodies without front-cloud
  // data are treated as positionZ=0 (neutral middle), same as the engine's
  // own convention of clouds/atmosphere/rings being local Z offsets from an
  // implicit zero at the body's own root. Both maps are memoized fresh each
  // frame since bodies/orbits can be edited live; Array.sort is stable, so
  // any remaining ties keep their original relative order.
  const _bodyDepth = {};
  function _depthOf(n, guard){
    if(_bodyDepth[n] !== undefined) return _bodyDepth[n];
    guard = guard || 0;
    const b = bodies[n];
    const par = b?.data?.ORBIT_DATA?.parent;
    if(!b || b.isCenter || !par || !bodies[par] || guard > 24) return (_bodyDepth[n] = 0);
    return (_bodyDepth[n] = _depthOf(par, guard + 1) + 1);
  }
  names.forEach(n => _depthOf(n));
  const _bodyFcZ = {};
  names.forEach(n => {
    const fcd = bodies[n]?.data?.FRONT_CLOUDS_DATA;
    _bodyFcZ[n] = (fcd && typeof fcd.positionZ === 'number') ? fcd.positionZ : 0;
  });
  const drawOrder = names.slice().sort((a, b) =>
    (_bodyDepth[a] - _bodyDepth[b]) || (_bodyFcZ[b] - _bodyFcZ[a])
  );

  bodyScreenPos = {};
  // Front-cloud composites are collected here instead of drawn immediately.
  // Reason: each body's surface/terrain/atmosphere is painted in this same
  // per-body pass, in drawOrder (hierarchy-depth-primary, positionZ only
  // breaking ties among siblings at the same depth). That's correct for
  // ordering separate decorator bodies against EACH OTHER, but it means a
  // body whose own FRONT_CLOUDS_DATA.positionZ happens to be very negative
  // (e.g. bioluminescence/city-lights painted directly on the planet itself,
  // not via a separate invisible moon) gets its ENTIRE draw pass — surface
  // included — sorted ahead of a sibling shadow body's pass, since the sort
  // key can't tell "this body's own decorative layer" apart from "this body's
  // solid surface". The shadow body then paints first and gets immediately
  // painted over by the planet's own surface, so the darkening never shows.
  // Fix: draw every body's surface/terrain/atmosphere fully in this loop as
  // before (unchanged), but defer the front-cloud disc itself into a second,
  // separate pass at the very end, sorted purely by positionZ across ALL
  // bodies regardless of hierarchy depth or which body they visually sit on.
  // That lets a shadow disc darken any surface it geometrically overlaps,
  // while still letting a more-negative-Z layer (front clouds, city lights)
  // paint back on top of that shadow afterward — matching the game, where
  // FrontClouds.cs gives every layer the same sortingOrder and only
  // positionZ (a flat, global Z) ever decides relative order.
  const _fcDeferred = [];
  // Screen-space discs drawn so far this frame, used by the icon-overlap cull
  // below to keep bigger bodies visually on top of smaller ones.
  const _drawnDiscs = [];
  drawOrder.forEach(name => {
    try {
    const b = bodies[name];
    const wp = bodyWorldPos[name] || {x:0, y:0};
    const sp = worldToScreen(wp.x, wp.y);
    bodyScreenPos[name] = sp; // always store for hit-test even if not drawn

    if(!bodyVisible[name]){ 
      if(!_sfsDbgLogged['cull_'+name]){ _sfsDbgLogged['cull_'+name]=true; console.log(`[SFS|CULL] "${name}" hidden by LOD ownSMApx too small`); }
      return; // LOD cull
    }

    const bodyRadius_m = (b.data.BASE_DATA||{}).radius || 1;

    // Fixed icon sizes — always the same pixel size regardless of zoom.
    // physR_px grows as you zoom in; once it exceeds the icon, the icon takes over.
    // This way bodies are always visible at any zoom level.
    const iconR = (b.isCenter ? 18
                : b.preset === 'star'         ? 14
                : b.preset === 'blackhole'    ? 12
                : (b.preset === 'gasgiant' || b.preset === 'ringedgiant') ? 10
                : (b.preset === 'planet' || b.preset === 'marslike' || b.preset === 'mercurylike') ? 7
                : b.preset === 'moon'         ? 5
                : b.preset === 'barycentre'   ? 4
                : 4) * iconScale; // asteroid

    // Physical radius in screen pixels at current zoom.
    // Apply radiusDifficultyScale so the body disc scales correctly relative to
    // orbital distances — matches game's ScalePlanetData(basics.radius *= radiusScale).
    const scale = getSMAScale();
    const radiusMult = getRadiusDifficultyMult(b.data.BASE_DATA);
    const physR_px = bodyRadius_m * radiusMult * scale * vpZ;

    // Use whichever is larger: icon floor or physical size. No viewport cap —
    // removing it lets the planet fill and exceed the screen when zoomed in,
    // and keeps atmosphere/clouds proportional at all zoom levels.
    const r = Math.max(iconR, physR_px);

    // Screen-space cull: use atmosphere outer radius so atmo doesn't flicker
    // when the planet disc goes off-screen but the halo is still visible.
    // Also extend for rings — physR_px * (endRadius/bodyRadius) is the physical ring outer extent.
    let _cullR = r;
    if(b.data.ATMOSPHERE_PHYSICS_DATA && b.data.ATMOSPHERE_VISUALS_DATA?.GRADIENT){
      const _GRD = b.data.ATMOSPHERE_VISUALS_DATA.GRADIENT;
      const _outerM = (b.data.ATMOSPHERE_PHYSICS_DATA.height || 0) +
                      (_GRD.positionZ || 0) + (_GRD.height || 0);
      if(_outerM > 0) _cullR = Math.max(r, r * (bodyRadius_m + _outerM) / bodyRadius_m);
    }
    if(b.data.RINGS_DATA && b.data.RINGS_DATA.endRadius){
      // Use r (display-clamped radius) times the ring ratio for cull — safe and bounded
      const _ringRatio = b.data.RINGS_DATA.endRadius / ((b.data.BASE_DATA||{}).radius || 1);
      _cullR = Math.max(_cullR, r * _ringRatio);
    }
    // Extend for FRONT_CLOUDS_DATA too — same reasoning as atmosphere above, but this
    // one matters far more in practice: the "invisible carrier" pattern (a near-zero-
    // radius dummy body whose entire visual footprint is a huge FRONT_CLOUDS_DATA.height,
    // e.g. a shadow/terminator disc orbiting the real planet) makes `r` here collapse to
    // just the tiny icon floor, since physR_px is sub-pixel for a radius~1 body and no
    // atmosphere/rings data exists to widen _cullR either. That tiny _cullR then culls the
    // ENTIRE body — cloud disc included — the instant the carrier's own (practically
    // meaningless) icon position drifts off-canvas, even though the disc itself, sized off
    // FRONT_CLOUDS_DATA.height rather than the carrier's own radius, can be huge enough to
    // still cover visible screen area from off-screen. Mirrors the same fcR_px math used
    // in the actual front-cloud draw below: (R_eff_px_fc + fcHeight_m) * scale * vpZ.
    if(b.data.FRONT_CLOUDS_DATA && b.data.FRONT_CLOUDS_DATA.cloudsTexture &&
       b.data.FRONT_CLOUDS_DATA.cloudsTexture !== 'None'){
      const _fcAtmoMult  = getAtmoDifficultyMult(b.data);
      const _fcR_eff_px   = bodyRadius_m * radiusMult;
      const _fcHeight_m   = Math.max(-_fcR_eff_px * 0.99, (b.data.FRONT_CLOUDS_DATA.height || 0) * _fcAtmoMult);
      const _fcCullR_px   = (_fcR_eff_px + _fcHeight_m) * scale * vpZ;
      _cullR = Math.max(_cullR, _fcCullR_px);
    }
    if(sp.x + _cullR < 0 || sp.x - _cullR > W || sp.y + _cullR < 0 || sp.y - _cullR > H) return;

    // ── Icon-overlap cull ────────────────────────────────────────────────────
    // Small bodies use a fixed-pixel "icon" floor (iconR) so they stay visible
    // at any zoom level. But draw order above is hierarchy-first (parents
    // before children) for terrain/front-cloud correctness elsewhere, which
    // means a moon's icon is always painted AFTER its (usually much bigger)
    // planet's icon — i.e. the smaller icon ends up on top of / inside the
    // bigger one. That reads as a rendering glitch rather than the intended
    // "bigger body wins" look. Painter's-algorithm already does the right
    // thing when a bigger body happens to draw after a smaller one (it just
    // covers it) — the only broken case is a smaller icon-floor-dominated
    // body drawn after an already-drawn bigger disc that it mostly overlaps.
    // Guard exactly that case: cull the smaller icon rather than let it paint
    // inside the bigger body. Only applies to bodies actually being shown at
    // their icon floor (iconR >= physR_px) — real, physically-sized terrain
    // discs are never culled this way.
    if(iconR >= physR_px){
      for(let _oi = 0; _oi < _drawnDiscs.length; _oi++){
        const _d = _drawnDiscs[_oi];
        if(_d.r <= r * 1.05) continue; // not meaningfully bigger — no cull
        const _dx = sp.x - _d.x, _dy = sp.y - _d.y;
        if(Math.sqrt(_dx*_dx + _dy*_dy) < _d.r * 0.85){
          if(!_sfsDbgLogged['ovcull_'+name]){ _sfsDbgLogged['ovcull_'+name]=true; console.log(`[SFS|CULL] "${name}" icon hidden inside larger "${_d.name}" icon`); }
          return; // culled — smaller icon fully overlapped by a bigger one
        }
      }
    }
    _drawnDiscs.push({x: sp.x, y: sp.y, r, name});

    const bodyFadeA  = bodyFadeVal[name]  ?? 1;
    const labelFadeA = labelFadeVal[name] ?? 1;
    const [c1, c2] = b.color.split(',');

    ctx2.save();
    ctx2.globalAlpha = bodyFadeA;

    // ── Barycentre: small cross marker ──
    // Only short-circuits the rest of the per-body pipeline when the body has
    // no visual data of its own. A body carrying real FRONT_CLOUDS_DATA/
    // ATMOSPHERE/RINGS/TERRAIN (e.g. the "invisible carrier" pattern — a
    // near-zero-radius, terrain-less body used purely to host a huge
    // FRONT_CLOUDS_DATA overlay) still needs to reach that code below, so it
    // falls through instead of being discarded here.
    if(b.preset === 'barycentre'){
      ctx2.strokeStyle = 'rgba(180,180,255,0.5)';
      ctx2.lineWidth = 1;
      ctx2.beginPath(); ctx2.moveTo(sp.x-6,sp.y); ctx2.lineTo(sp.x+6,sp.y); ctx2.stroke();
      ctx2.beginPath(); ctx2.moveTo(sp.x,sp.y-6); ctx2.lineTo(sp.x,sp.y+6); ctx2.stroke();
      ctx2.beginPath(); ctx2.arc(sp.x,sp.y,4,0,Math.PI*2);
      ctx2.strokeStyle='rgba(180,180,255,0.35)'; ctx2.stroke();
      if(selectedBody===name){ ctx2.beginPath(); polygonCircle(ctx2,sp.x,sp.y,10,64); ctx2.closePath(); ctx2.strokeStyle='rgba(80,180,255,0.75)'; ctx2.lineWidth=1.5; ctx2.setLineDash([3,3]); ctx2.stroke(); ctx2.setLineDash([]); }
      if(typeof groupSelectMode !== 'undefined' && groupSelectMode && typeof groupSelected !== 'undefined' && groupSelected.has(name)){ ctx2.beginPath(); polygonCircle(ctx2,sp.x,sp.y,11,64); ctx2.closePath(); ctx2.strokeStyle='rgba(255,155,40,0.9)'; ctx2.lineWidth=2; ctx2.setLineDash([3,3]); ctx2.stroke(); ctx2.setLineDash([]); }
      ctx2.fillStyle='rgba(150,200,240,0.7)'; ctx2.font='9px "JetBrains Mono",monospace'; ctx2.textAlign='center';
      ctx2.fillText(name, sp.x, sp.y+18);
      const _hasOwnVisuals = !!(b.data.FRONT_CLOUDS_DATA || b.data.ATMOSPHERE_PHYSICS_DATA ||
                                 b.data.RINGS_DATA || b.data.TERRAIN_DATA);
      if(!_hasOwnVisuals){
        ctx2.restore(); // must restore before early return
        return;
      }
      // fall through, deliberately NOT restoring — the rest of the per-body
      // pipeline expects ctx2 to still be in the bodyFadeA-applied save state
      // (it's balanced by the "end bodyFadeA globalAlpha" restore further down).
    }

    // ── Star / black hole glow ──
    // Glow fades when either a cloud band or front-cloud disc renders over the body
    const hasCloudDisc = !!(
      (b.data.ATMOSPHERE_VISUALS_DATA?.CLOUDS?.texture &&
       b.data.ATMOSPHERE_VISUALS_DATA.CLOUDS.texture !== 'None') ||
      (b.data.FRONT_CLOUDS_DATA?.cloudsTexture &&
       b.data.FRONT_CLOUDS_DATA.cloudsTexture !== 'None')
    );
    const glowSuppressFade = hasCloudDisc ? Math.max(0, 1 - (physR_px - 10) / 20) : 1;
    if((b.preset==='star' || b.preset==='blackhole') && glowSuppressFade > 0){
      const isBH = b.preset === 'blackhole';

      // Derive surface colour from atmosphere texture inner row, else fallback to b.glow
      let sr = 255, sg = 255, sb = 255;
      const atmoTex2 = b.data.ATMOSPHERE_VISUALS_DATA?.GRADIENT?.texture;
      const apx = atmoTex2 && atmoTex2 !== 'None' && texPixelCache[atmoTex2 + '_atmos'];
      if(apx){
        // Row 63 = innermost (surface) colour
        sr = apx[63*4]; sg = apx[63*4+1]; sb = apx[63*4+2];
        // If too dark (black-as-transparent texture), brighten proportionally
        const bri = Math.max(sr, sg, sb);
        if(bri < 20){ sr = 255; sg = 255; sb = 255; } // pure white fallback
        else if(bri < 180){ const f = 255/bri; sr=Math.min(255,sr*f|0); sg=Math.min(255,sg*f|0); sb=Math.min(255,sb*f|0); }
      } else {
        // Parse b.glow hex/rgb into components — cached per glow string
        if(!drawViewport._glowRGBCache) drawViewport._glowRGBCache = {};
        if(!drawViewport._glowRGBCache[b.glow]){
          const tmp = document.createElement('canvas'); tmp.width=1; tmp.height=1;
          const tc = tmp.getContext('2d'); tc.fillStyle = b.glow; tc.fillRect(0,0,1,1);
          const pd = tc.getImageData(0,0,1,1).data;
          drawViewport._glowRGBCache[b.glow] = [pd[0], pd[1], pd[2]];
        }
        [sr, sg, sb] = drawViewport._glowRGBCache[b.glow];
      }
      // Multi-stop exponential glow: tight bright core + wide diffuse bloom
      // Inner radius = 0 so the disc centre is always filled (no black hole at large radii).
      const glowR = Math.min(r * (isBH ? 5 : 4), diagPx * 1.5);
      const grd = ctx2.createRadialGradient(sp.x, sp.y, 0, sp.x, sp.y, glowR);
      if(isBH){
        // Black hole: dark centre, electric blue/purple ring
        grd.addColorStop(0,    `rgba(0,0,0,1)`);
        grd.addColorStop(0.08, `rgba(${sr},${sg},${sb},0.9)`);
        grd.addColorStop(0.18, `rgba(${sr},${sg},${sb},0.4)`);
        grd.addColorStop(0.35, `rgba(${sr},${sg},${sb},0.12)`);
        grd.addColorStop(1,    `rgba(${sr},${sg},${sb},0)`);
      } else {
        // Star: blinding white core fading through surface colour to transparent bloom
        grd.addColorStop(0,    `rgba(255,255,255,0.95)`);  // white hot centre
        grd.addColorStop(0.04, `rgba(255,255,255,0.9)`);   // keep white across core
        grd.addColorStop(0.12, `rgba(${sr},${sg},${sb},0.85)`); // transition to surface colour
        grd.addColorStop(0.25, `rgba(${sr},${sg},${sb},0.45)`);
        grd.addColorStop(0.45, `rgba(${sr},${sg},${sb},0.15)`);
        grd.addColorStop(0.7,  `rgba(${sr},${sg},${sb},0.04)`);
        grd.addColorStop(1,    `rgba(${sr},${sg},${sb},0)`);
      }
      ctx2.save();
      ctx2.globalAlpha *= glowSuppressFade;
      ctx2.globalCompositeOperation = 'lighter';
      ctx2.beginPath(); ctx2.arc(sp.x, sp.y, glowR, 0, Math.PI*2);
      ctx2.fillStyle = grd; ctx2.fill();
      ctx2.restore();
    }

    // ── Rings (RINGS_DATA) — drawn behind planet disc ──
    // Texture maps horizontally: left=inner edge, right=outer edge (radial gradient).
    // Black pixels = transparent (same convention as atmo/clouds).
    // positionZ controls vertical tilt — ignored in 2D top-down view.
    // Rings only fade in when physR_px > 4 (visible at system scale).
    if(b.data.RINGS_DATA){
      const RD = b.data.RINGS_DATA;
      const ringTex = RD.ringsTexture;
      const pxCache = ringTex && texPixelCache[ringTex + '_ring'];
      if(pxCache){
        const startR_m = RD.startRadius || 0;
        const endR_m   = RD.endRadius   || 0;
        const mc       = RD.mapColor    || {r:1,g:1,b:1,a:1};
        if(endR_m > startR_m && startR_m > 0){
          // SFS ring radii are from planet CENTER.
          // Use physR_px (true physical scale, unclamped) so rings don't shrink when zoomed.
          const ringScale  = physR_px / bodyRadius_m;
          const inner_px   = Math.max(ringScale * startR_m, physR_px); // never inside planet disc
          const outer_px   = ringScale * endR_m;
          // Fade rings out as we zoom into a child body (when ring inner leaves viewport).
          // ringFade = 1 when inner_px <= diagPx, fades to 0 at 3×diagPx.
          const ringFade   = Math.max(0, Math.min(1, 1 - (inner_px - diagPx) / (2 * diagPx)));
          if(ringFade > 0.01){
            const safeOuter  = Math.min(outer_px, diagPx * 4);
            const safeInner  = Math.min(inner_px, safeOuter * 0.9999);
            if(safeOuter > 0.5 && safeOuter > safeInner){
              // Cache ring stop strings per body+ringFade (colour-only, position-independent)
              if(!drawViewport._ringStopCache) drawViewport._ringStopCache = {};
              // ── Ground truth from decompiled source + RenderDoc capture ──
              // 1) Radial mapping: Rings.cs builds the ring mesh with vertex UV magnitude hardcoded to 1 at
              //    the inner edge and 2 at the outer edge (array2[i*2]=vector, array2[i*2+1]=vector*2f),
              //    REGARDLESS of the true endRadius/startRadius ratio. The GPU linearly interpolates that
              //    UV between the two vertex rings, so at fraction s (0=inner,1=outer) magnitude = (1+s).
              //    Shader: texU = length(v1.xy) - 1 = s. So texU is simply the ring's own 0..1 width
              //    fraction — confirmed via RenderDoc mesh viewer (TEXCOORD0 1.00 -> 2.00). Matches the
              //    original t=i/N mapping below; no ring-ratio correction needed.
              // 2) Colour: Planet.cs CreateRingsMaterial() only calls material.SetTexture("_RingsTex", ...)
              //    — mapColor is NEVER sent to this shader (it's only read in MapEnvironment.cs for the flat
              //    2D map-view dot, a different render entirely). The cb0[2]=(1,0.95,1.2,0) seen in RenderDoc
              //    is an unset material default, and only .x is read (broadcast, no-op at 1.0). So the real
              //    planet-view ring colour is just the ramp texture's own RGBA, unmodified.
              const ringStopKey = ringTex + '|' + ringFade.toFixed(3);
              if(!drawViewport._ringStopCache[ringStopKey]){
                const N = 64;
                const stops = [];
                for(let i = 0; i <= N; i++){
                  const t  = i / N;
                  const ci = Math.round(t * 63) * 4;
                  const cr = pxCache[ci], cg = pxCache[ci+1], cb = pxCache[ci+2], ca = pxCache[ci+3];
                  const alpha = (ca / 255) * ringFade;
                  stops.push([t, `rgba(${cr},${cg},${cb},${Math.min(1,alpha).toFixed(3)})`]);
                }
                drawViewport._ringStopCache[ringStopKey] = stops;
              }
              const stops = drawViewport._ringStopCache[ringStopKey];
              const grad = ctx2.createRadialGradient(sp.x, sp.y, safeInner, sp.x, sp.y, safeOuter);
              for(const [t, col] of stops) grad.addColorStop(t, col);
              ctx2.save();
              ctx2.beginPath();
              ctx2.arc(sp.x, sp.y, safeOuter, 0, Math.PI*2);
              ctx2.arc(sp.x, sp.y, safeInner, 0, Math.PI*2, true);
              ctx2.fillStyle = grad;
              ctx2.fill();
              ctx2.restore();
            }
          }
        }
      }
    }

    // ── Atmosphere halo — variable setup (draw call deferred to after front clouds) ──
    // Variables computed here because atmoFade is used by fog, water, cloud strip, etc.
    const _atmoH_m  = (b.data.ATMOSPHERE_PHYSICS_DATA?.height || 0) * getAtmoDifficultyMult(b.data);
    const _gradH_m  = (b.data.ATMOSPHERE_VISUALS_DATA?.GRADIENT?.height || _atmoH_m) * getAtmoDifficultyMult(b.data);
    const _R_eff_px = bodyRadius_m * radiusMult;
    const _atmoOuterPx = _atmoH_m > 0
      ? physR_px * (_R_eff_px + _gradH_m) / _R_eff_px
      : physR_px;
    // LOD threshold: larger atmospheres (by physical outer radius in metres) start
    // rendering from farther away (more screen pixels required before fade-in begins).
    // _atmoLod grows logarithmically with physical outer radius so a gas-giant atmosphere
    // (R+H ~500 000 km) fades in at ~32 px while a thin 50 km atmo uses the 2 px floor.
    const _atmoPhysOuter_m = _R_eff_px + _gradH_m; // metres, unscaled
    const _atmoLod = _atmoPhysOuter_m > 0
      ? Math.min(32, Math.max(2, 2 * Math.log10(Math.max(1, _atmoPhysOuter_m / 1e5))))
      : 2;
    const atmoFade = Math.max(0, Math.min(1, (_atmoOuterPx - _atmoLod) / Math.max(_atmoLod, 0.01)));

    // ── Physical atmosphere overlay (debug) ────────────────────────────────
    if(envFlags.physAtmo && b.data.ATMOSPHERE_PHYSICS_DATA){
      const _aphys_H  = (b.data.ATMOSPHERE_PHYSICS_DATA.height || 0) * getAtmoDifficultyMult(b.data);
      if(_aphys_H > 0){
        const _aphys_innerPx = physR_px;
        const _aphys_outerPx = physR_px * (bodyRadius_m * radiusMult + _aphys_H) / (bodyRadius_m * radiusMult);
        if(_aphys_outerPx > 0.5){
          const _NSIDES = 72;
          ctx2.save();
          ctx2.globalAlpha = 0.22;
          ctx2.fillStyle = '#7fc8ff';
          ctx2.beginPath();
          for(let _i=0;_i<_NSIDES;_i++){
            const _a = (_i/_NSIDES)*Math.PI*2;
            const _x = sp.x + Math.cos(_a)*_aphys_outerPx;
            const _y = sp.y + Math.sin(_a)*_aphys_outerPx;
            _i===0 ? ctx2.moveTo(_x,_y) : ctx2.lineTo(_x,_y);
          }
          ctx2.closePath();
          // cut out planet centre
          for(let _i=0;_i<_NSIDES;_i++){
            const _a = -(_i/_NSIDES)*Math.PI*2;
            const _ix = sp.x + Math.cos(_a)*_aphys_innerPx;
            const _iy = sp.y + Math.sin(_a)*_aphys_innerPx;
            _i===0 ? ctx2.moveTo(_ix,_iy) : ctx2.lineTo(_ix,_iy);
          }
          ctx2.closePath();
          ctx2.fill('evenodd');
          // border ring at outer edge
          ctx2.globalAlpha = 0.55;
          ctx2.strokeStyle = '#7fc8ff';
          ctx2.lineWidth = Math.max(1, Math.min(2, _aphys_outerPx * 0.012));
          ctx2.beginPath();
          for(let _i=0;_i<_NSIDES;_i++){
            const _a = (_i/_NSIDES)*Math.PI*2;
            const _x = sp.x + Math.cos(_a)*_aphys_outerPx;
            const _y = sp.y + Math.sin(_a)*_aphys_outerPx;
            _i===0 ? ctx2.moveTo(_x,_y) : ctx2.lineTo(_x,_y);
          }
          ctx2.closePath();
          ctx2.stroke();
          // label height
          if(_aphys_outerPx > 30){
            ctx2.globalAlpha = 0.85;
            ctx2.fillStyle = '#7fc8ff';
            ctx2.font = `bold ${Math.max(9, Math.min(13, _aphys_outerPx * 0.04))}px "JetBrains Mono", monospace`;
            ctx2.textAlign = 'left';
            ctx2.textBaseline = 'middle';
            const _hkm = (_aphys_H/1000).toFixed(0);
            ctx2.fillText(`atmo ${_hkm} km`, sp.x + _aphys_outerPx + 4, sp.y - _aphys_outerPx * 0.15);
          }
          ctx2.restore();
        }
      }
    }

    // ── Atmosphere halo ────────────────────────────────────────────────────
    // SFS atmosphere rendering rules:
    //   - Texture X = angle around planet (left=East, wraps CCW)
    //   - Texture bottom row (Y=SH-1) = planet circumference (radius r)
    //   - Texture top row    (Y=0)    = outer atmosphere edge (radius drawR)
    //   - Inside r: bottom row is stretched radially toward center (pizza slices)
    //   - No-terrain bodies (Sun): atmosphere is additive ('lighter') over star glow
    //   - Terrain bodies (Earth): atmosphere halo sits behind surface (source-over)
    //
    // We build a polar-warped disc canvas AT DRAW TIME (cached per body+zoomBin)
    // so we can correctly map pixel distance from center to texture row, taking
    // into account the actual r/drawR ratio at this zoom level.
    // This is the only way to preserve angular variation (sun flares, etc.)
    //
    // ── Surface base fill — non-terrain bodies only ──
    // For stars/gas-giants (no TERRAIN_DATA) the atmosphere uses 'lighter' blending,
    // which adds onto whatever is below. Without a solid fill the raw black canvas
    // bleeds through at the disc limb where the arc clip anti-aliases and where the
    // atmosphere texture bottom row is semi-transparent, producing a 1-2px dark ring.
    // Draw the surface colour as a solid disc here so the limb is always opaque.
    if(atmoFade > 0 && !b.data.TERRAIN_DATA && b.data.ATMOSPHERE_VISUALS_DATA?.GRADIENT){
      const atmoTex0 = b.data.ATMOSPHERE_VISUALS_DATA.GRADIENT.texture;
      if(atmoTex0 && atmoTex0 !== 'None'){
        // Derive surface colour from the cached innermost texture row (same source
        // used by the star glow code above), fallback to b.glow.
        let fr0 = 255, fg0 = 255, fb0 = 255;
        const apx0 = texPixelCache[atmoTex0 + '_atmos'];
        if(apx0){ fr0 = apx0[63*4]; fg0 = apx0[63*4+1]; fb0 = apx0[63*4+2]; }
        ctx2.save();
        ctx2.globalAlpha = atmoFade;
        ctx2.globalCompositeOperation = 'source-over';
        ctx2.beginPath(); ctx2.arc(sp.x, sp.y, physR_px, 0, Math.PI*2);
        ctx2.fillStyle = `rgb(${fr0},${fg0},${fb0})`;
        ctx2.fill();
        ctx2.restore();
      }
    }

    if(envFlags.atmo && !envFlags.heightmaps && atmoFade > 0 && b.data.ATMOSPHERE_PHYSICS_DATA && b.data.ATMOSPHERE_VISUALS_DATA?.GRADIENT){
      const APD = b.data.ATMOSPHERE_PHYSICS_DATA;
      const GRD = b.data.ATMOSPHERE_VISUALS_DATA.GRADIENT;
      const atmosH_m = APD.height || 0;
      const gradH_m  = GRD.height || atmosH_m;
      const atmoTex  = GRD.texture;

      if(atmosH_m > 0 && atmoTex && atmoTex !== 'None'){
        const srcImg = textureCache[atmoTex];
        if(srcImg && srcImg.complete && srcImg.naturalWidth > 0){
          // Always use physR_px (true physical pixel radius) for atmosphere sizing,
          // NOT the display-clamped r — the atmosphere must stay at its real physical
          // size regardless of the icon floor or zoom level.
          // Denominator MUST be the radiusMult-scaled body radius (R_eff_px), not raw
          // bodyRadius_m: physR_px already has radiusMult baked in (physR_px =
          // bodyRadius_m*radiusMult*scale*vpZ), so dividing by unscaled bodyRadius_m
          // lets radiusMult leak into the atmosphere-height term too. In-game, radius
          // and atmosphere height are scaled by two INDEPENDENT difficulty multipliers
          // (RadiusScale vs AtmosphereScale/atmoMult) — gradH_m below is already
          // atmoMult-scaled, so the ratio must only re-apply radiusMult to the radius
          // part. On Normal (radiusMult=1) this was invisible; on Hard/Realistic it
          // made the halo balloon outward past its correct outer edge.
          const R_eff_px_atmo = bodyRadius_m * radiusMult;
          const outer_r_px = physR_px * (R_eff_px_atmo + gradH_m) / R_eff_px_atmo;
          if(outer_r_px > 0.5){
            const hasTerrain = !!b.data.TERRAIN_DATA;
            // When the atmosphere outer edge exceeds the viewport diagonal, the planet
            // disc has zoomed past the screen edge — only the surface is visible, not
            // the halo ring. Skip the polar warp entirely in this case; it would produce
            // a misaligned ring artifact at the limb because drawR clamping breaks the
            // innerFrac/clip relationship.
            // For non-terrain bodies (stars) the atmosphere fills inward so still render.
            const drawR = Math.min(outer_r_px, diagPx * 2);
            const innerFrac = physR_px / drawR; // physical ratio: planet disc / atmo outer
            if(hasTerrain && innerFrac >= 1.0){
              // Planet disc fills/exceeds viewport — nothing to draw
            } else {
            const innerFracClamped = Math.min(0.999, innerFrac);

            // ── Build or retrieve polar disc canvas ──
            // Quantise innerFrac to 0.025 steps (~40 buckets) so the cache doesn't
            // rebuild on every zoom tick. Previously .toFixed(4) caused a fresh
            // 512k-pixel rebuild every frame while zooming, causing severe lag.
            const innerFracQ = (Math.round(innerFracClamped / 0.025) * 0.025).toFixed(3);
            if(!drawViewport._atmoPolarCache) drawViewport._atmoPolarCache = {};
            const cacheKey = atmoTex + '|' + innerFracQ;
            let polarCanvas = drawViewport._atmoPolarCache[cacheKey];

            if(!polarCanvas){
              // Build source pixel buffer once per texture
              if(!drawViewport._atmoSrcCache) drawViewport._atmoSrcCache = {};
              if(!drawViewport._atmoSrcCache[atmoTex]){
                const sc = document.createElement('canvas');
                sc.width = srcImg.naturalWidth; sc.height = srcImg.naturalHeight;
                sc.getContext('2d').drawImage(srcImg, 0, 0);
                drawViewport._atmoSrcCache[atmoTex] = {
                  data: sc.getContext('2d').getImageData(0,0,sc.width,sc.height).data,
                  w: sc.width, h: sc.height
                };
              }
              const {data: srcD, w: SW, h: SH} = drawViewport._atmoSrcCache[atmoTex];

              // Use higher resolution for thin atmospheres (small innerFrac gap)
              // or large bodies (physR_px already big on screen), so each texture
              // row maps to enough polar-canvas pixels and the limb stays sharp.
              const atmoBandFrac = 1 - innerFracClamped;
              const SZ = (atmoBandFrac < 0.15 || physR_px > 120) ? 1024 : 512;
              polarCanvas = document.createElement('canvas');
              polarCanvas.width = SZ; polarCanvas.height = SZ;
              const pCtx = polarCanvas.getContext('2d');
              const outD = pCtx.createImageData(SZ, SZ);
              const od = outD.data;
              const half = SZ / 2;

              // Pre-sample the innermost texture row (bottom of atmosphere = planet surface colour)
              // so pixels inside innerFracClamped can be filled solid instead of left transparent.
              // Transparent inner pixels composite as black over the canvas → dark gap ring.
              let inner_r = 255, inner_g = 255, inner_b = 255, inner_a = 255;
              {
                const innerRow = SH - 1; // bottom row = planet surface
                let rSum=0,gSum=0,bSum=0,aSum=0, cnt=0;
                for(let ix=0;ix<SW;ix++){
                  const ii=(innerRow*SW+ix)*4;
                  rSum+=srcD[ii]; gSum+=srcD[ii+1]; bSum+=srcD[ii+2]; aSum+=srcD[ii+3]; cnt++;
                }
                inner_r=rSum/cnt+.5|0; inner_g=gSum/cnt+.5|0;
                inner_b=bSum/cnt+.5|0; inner_a=aSum/cnt+.5|0;
              }

              for(let py = 0; py < SZ; py++){
                for(let ppx = 0; ppx < SZ; ppx++){
                  const dx = ppx - half, dy = py - half;
                  const dist = Math.sqrt(dx*dx + dy*dy);
                  const radFrac = dist / half;
                  const oi = (py*SZ + ppx)*4;

                  if(radFrac > 1.0){ od[oi+3]=0; continue; }

                  // Pixels inside the planet disc: fill with innermost atmosphere colour
                  // (fully opaque) so there is no transparent zone that composites as black.
                  if(radFrac <= innerFracClamped){
                    od[oi]=inner_r; od[oi+1]=inner_g; od[oi+2]=inner_b; od[oi+3]=inner_a;
                    continue;
                  }

                  let cwAngle = Math.atan2(dy, dx) / (Math.PI*2);
                  if(cwAngle < 0) cwAngle += 1;
                  const u = (1 - cwAngle) % 1;

                  const t = (radFrac - innerFracClamped) / (1 - innerFracClamped);
                  const texRowF = (1 - t) * (SH - 1);
                  const sx = Math.min(SW-1, Math.max(0, Math.round(u * (SW-1))));
                  // Bilinear interpolation along Y to avoid hard row-quantisation rings
                  const sy0 = Math.min(SH-1, Math.max(0, Math.floor(texRowF)));
                  const sy1 = Math.min(SH-1, sy0 + 1);
                  const fy  = texRowF - sy0;
                  const si0 = (sy0 * SW + sx) * 4;
                  const si1 = (sy1 * SW + sx) * 4;
                  od[oi]   = srcD[si0]   + (srcD[si1]   - srcD[si0])   * fy + 0.5 | 0;
                  od[oi+1] = srcD[si0+1] + (srcD[si1+1] - srcD[si0+1]) * fy + 0.5 | 0;
                  od[oi+2] = srcD[si0+2] + (srcD[si1+2] - srcD[si0+2]) * fy + 0.5 | 0;
                  od[oi+3] = srcD[si0+3] + (srcD[si1+3] - srcD[si0+3]) * fy + 0.5 | 0;
                }
              }
              pCtx.putImageData(outD, 0, 0);
              drawViewport._atmoPolarCache[cacheKey] = polarCanvas;
            }

            // ── Draw the polar disc — viewport-cropped ──
            // When drawR is huge (large star atmosphere zoomed in) the full-disc
            // drawImage scales a 512px canvas to thousands of screen pixels, forcing
            // the GPU to process an enormous blit even though only a small viewport
            // slice is visible. Instead we compute exactly which portion of the polar
            // canvas maps onto the current viewport and only blit that rectangle.
            // The arc clip below then masks it to the correct disc/ring shape.
            ctx2.save();
            ctx2.globalAlpha = atmoFade;
            ctx2.globalCompositeOperation = hasTerrain ? 'source-over' : 'lighter';

            if(hasTerrain){
              ctx2.beginPath();
              ctx2.arc(sp.x, sp.y, drawR, 0, Math.PI*2);
              ctx2.clip();
            } else {
              ctx2.beginPath();
              ctx2.arc(sp.x, sp.y, drawR, 0, Math.PI*2);
              ctx2.clip();
            }

            {
              const SZ = polarCanvas.width; // 512
              const fullD = drawR * 2;      // full disc diameter in screen px

              // Destination rect: intersection of the full disc bounding box with viewport
              const discL = sp.x - drawR, discT = sp.y - drawR;
              const dstX = Math.max(0, discL);
              const dstY = Math.max(0, discT);
              const dstR = Math.min(W, discL + fullD);
              const dstB = Math.min(H, discT + fullD);
              const dstW = dstR - dstX;
              const dstH = dstB - dstY;

              if(dstW > 0 && dstH > 0){
                // Corresponding source rect in the 512×512 polar canvas
                const scale = SZ / fullD; // polar-canvas px per screen px
                const srcX = (dstX - discL) * scale;
                const srcY = (dstY - discT) * scale;
                const srcW = dstW * scale;
                const srcH = dstH * scale;
                ctx2.imageSmoothingEnabled = true;
                ctx2.imageSmoothingQuality = 'high';
                ctx2.drawImage(polarCanvas, srcX, srcY, srcW, srcH, dstX, dstY, dstW, dstH);
              }
            }

            ctx2.restore();
            } // end else (innerFrac < 1.0)
          }
        }
      }
    }

    // ── Body disc ──
    // Draw order: (1) terrain polygon or fallback disc  (2) texture on top  (3) water overlay
    // The terrain polygon is ALWAYS the base fill — texture clips on top of it.
    const ptex = b.data.TERRAIN_DATA?.TERRAIN_TEXTURE_DATA?.planetTexture;
    const texImg = envFlags.surface && ptex && ptex !== 'None' && textureCache[ptex]
                   && textureCache[ptex].complete && textureCache[ptex].naturalWidth > 0
                   ? textureCache[ptex] : null;

    // ── LOD tier ─────────────────────────────────────────────────────────────
    // Controls sample counts for terrain / surface texture / rocks based on
    // how large the planet appears on screen (physR_px).
    //   0 = tiny (smooth disc only — no heightmap sampling at all)
    //   1 = far  (coarse terrain shape, no surface texture)
    //   2 = mid  (terrain shape + surface texture at low N)
    //   3 = near (full detail)
    const LOD = physR_px < 6   ? 0
              : physR_px < 40  ? 1
              : physR_px < 120 ? 2
              :                  3;
    // terrN: number of terrain polygon vertices around the full circumference.
    //
    // The game's LOD system scales with both screen size AND planet radius — a large
    // planet zoomed in has many more terrain vertices visible per screen pixel than
    // a small asteroid at the same screen size.
    //
    // Correct formula: we need ~2 vertices per screen pixel around the circumference.
    // Screen circumference in pixels = 2π × physR_px, so terrN = 2π × physR_px.
    // This replaces the old π × physR_px / 45 * 45 which under-sampled by ~2× and
    // was capped at 4096 — causing flat terrain on large planets when zoomed in.
    //
    // Hard physics cap: game never places vertices closer than verticeSize metres apart.
    //   maxN = floor(2π × radius_m / verticeSize)
    // This prevents over-sampling small bodies beyond the game's own resolution.
    const _vsRaw = b.data.TERRAIN_DATA?.verticeSize;
    const _vs = (_vsRaw > 0) ? _vsRaw : 2.0; // default 2m matches game default

    // ── Dev toggles: isolate arc culling vs LOD settle-timer independently ──
    // window.terrainQuality='detailed' flips BOTH off at once (convenience
    // shorthand matching the original pre-optimization behavior). For
    // narrowing down which specific mechanism causes the close-zoom
    // shape-shift bug, set them independently instead:
    //   window.dbgArcCull = false   → disable arc culling only (LOD settle
    //                                 timer still active, terrN still capped
    //                                 by INTERACTIVE_N_CAP during gesture)
    //   window.dbgLOD     = false   → disable the LOD settle timer only
    //                                 (arc culling still active, terrN
    //                                 always resolves to full precision
    //                                 immediately, no interactive cap)
    // Both default to true (i.e. both optimizations active — normal
    // 'optimized' behavior) when unset.
    const _dbgArcCullOn = (typeof window !== 'undefined' && window.dbgArcCull === false) ? false : true;
    const _dbgLODOn     = (typeof window !== 'undefined' && window.dbgLOD === false) ? false : true;

    // ── Detailed / Optimized quality mode ───────────────────────────────────
    // Arc culling (and everything built on top of it — the settle-timer LOD
    // cap, the arc-relative surface-strip indexing, the arc-keyed surface
    // cache) trades vertex/pixel budget for speed by only sampling the
    // visible slice of the planet. At very close (rover-scale) zoom, that
    // visible slice can be angularly tiny even though it fills the whole
    // screen — and the verticeSize-based vertex ceiling (_vsMaxN below)
    // scales with arc angle, not screen coverage, so it can end up far
    // stingier than what the screen actually needs, right at the zoom level
    // where fine terrain (small craters, Perlin hills) matters most.
    //
    // Despite several rounds of fixes to _computeVisibleArc and
    // _getTerrainSamples (proportional margin, finer cache-key quantization,
    // correct boundary-point heights), arc culling has continued to produce
    // a flat/straight silhouette at close zoom in user testing — confirmed
    // via direct A/B toggling that arc culling itself is the cause, not the
    // LOD settle-timer (which is independent and does NOT contribute to this
    // bug). Given that pattern, 'detailed' mode (arc culling off, LOD
    // settle-timer still on — full correctness AND zoom-gesture smoothness)
    // is now the DEFAULT rather than an opt-in fallback, until arc culling's
    // remaining issue is found. 'optimized' (arc culling on) remains
    // available as an explicit opt-in for lower-end devices once trusted.
    //
    // Persisted the same way as the existing terrain-detail % control.
    // (Loaded once at script init via the _loadTerrainDevSettings IIFE above
    // setTerrainQuality — this just supplies a default for the rare case a
    // draw happens before that ran, or the key was never set.)
    const _terrainQuality = (typeof window !== 'undefined' && window.terrainQuality) || 'detailed';
    const _canArcCull = _terrainQuality !== 'detailed' && _dbgArcCullOn &&
      envFlags.heightmaps && physR_px > 200 && (bodyRadius_m * radiusMult) >= 15000;
    const _arcInfo = _canArcCull
      ? (() => {
          const _dispR_px = Math.max(r, physR_px);
          const _r_m = Math.max(1, bodyRadius_m * radiusMult);
          const _maxH_m = _getMaxTerrainHeight(name, b, _r_m);
          const _paddedR_px = _dispR_px * (_r_m + _maxH_m) / _r_m;
          return _computeVisibleArc(sp, _paddedR_px, W, H);
        })()
      : null;

    const _vsMaxN = (_arcInfo && !_arcInfo.fullCircle)
      ? Math.max(90, Math.floor((_arcInfo.arcEnd - _arcInfo.arcStart) * (bodyRadius_m * radiusMult) / _vs))
      : Math.max(90, Math.floor(2 * Math.PI * (bodyRadius_m * radiusMult) / _vs));
    // Screen-based N: 2 vertices per pixel around the circumference.
    // Quantise to multiples of 360 at high zoom (stable cache keys, divisible by common angles),
    // multiples of 90 at low zoom (small bodies where cache thrash matters more than precision).
    //
    // ── Zoom-gesture stabilisation ──────────────────────────────────────────
    // physR_px changes on nearly every frame while the user is actively
    // zooming, which used to make terrN cross a quantisation boundary most
    // frames too — each crossing is a full cache miss on both
    // _terrainSampleCache (re-runs the formula: heightmaps, curves, flat
    // zones, water depression) AND _terrainClipCache (rebuilds the Path2D).
    // That's the dominant cost of "lag while zooming", independent of how
    // low the terrain-detail/LOD setting is set, since a fresh N still means
    // a fresh cache miss even at reduced vertex counts.
    //
    // Approach: use a settle TIMER, not a per-frame delta check. A sustained
    // zoom/pinch moves physR_px on nearly every frame for its whole duration
    // — comparing consecutive frames alone means "still moving" is true for
    // the entire gesture, so N would stay frozen at whatever it was when the
    // gesture STARTED and never reach full LOD even once you stop, if any
    // residual per-frame jitter kept re-triggering the freeze.
    //
    // Instead: track when physR_px last changed meaningfully. While that was
    // very recently (<120ms ago), draw at a fast, capped "interactive" N so
    // frames stay cheap and responsive during the gesture. Once physR_px has
    // been stable for >120ms, resolve to the FULL precise N — this fires
    // once, reliably, shortly after the gesture ends, rather than depending
    // on hitting an exact single quiet frame.
    const _rawScreenN = Math.ceil(2 * Math.PI * physR_px);
    const _qStep = physR_px > 500 ? 720 : 180; // widened from 360/90 — fewer boundaries crossed per zoom
    const _detailMult = (typeof window !== 'undefined' && window.terrainDetail != null)
      ? Math.max(0.01, window.terrainDetail / 100) : 1;

    if (!drawViewport._lastPhysR) drawViewport._lastPhysR = {};
    if (!drawViewport._lastMoveT) drawViewport._lastMoveT = {};
    const _now = performance.now();
    const _prevPhysR = drawViewport._lastPhysR[name];
    const _movedNow = _prevPhysR != null && Math.abs(physR_px - _prevPhysR) > _prevPhysR * 0.015;
    if (_movedNow || _prevPhysR == null) drawViewport._lastMoveT[name] = _now;
    drawViewport._lastPhysR[name] = physR_px;

    const SETTLE_MS = 120;
    const _settled = !_dbgLODOn || (_now - (drawViewport._lastMoveT[name] || 0)) > SETTLE_MS;
    // drawViewport() is event-driven (called from pan/zoom input handlers
    // elsewhere) — nothing else guarantees a frame fires ~120ms after the
    // LAST zoom tick to actually cross the settle threshold and resolve full
    // LOD. Schedule that follow-up frame ourselves so max detail reliably
    // arrives shortly after the gesture ends instead of only whenever the
    // next unrelated redraw happens to occur (which may be never).
    if (_dbgLODOn && !_settled) {
      clearTimeout(drawViewport._settleTimer);
      drawViewport._settleTimer = setTimeout(() => {
        if (typeof drawViewport === 'function') drawViewport();
      }, SETTLE_MS + 20);
    }

    // Fixed interactive cap: while actively zooming, never build more than
    // this many vertices regardless of how large physR_px gets — this is
    // the "fixed number of vertices so it never overloads" ceiling. Full
    // precision (up to _vsMaxN / the screen-density target) only applies
    // once settled.
    const INTERACTIVE_N_CAP = 2400;

    let terrN;
    if (LOD === 0) {
      terrN = 0;
    } else if (!_settled) {
      const _fastScreenN = Math.max(90, Math.ceil((_rawScreenN * _detailMult) / _qStep) * _qStep);
      terrN = Math.min(_vsMaxN, _fastScreenN, INTERACTIVE_N_CAP);
    } else {
      const _screenN = Math.max(90, Math.ceil((_rawScreenN * _detailMult) / _qStep) * _qStep);
      terrN = Math.min(_vsMaxN, _screenN);
    }

    // Dev-only terrain debug overlay — gated behind a Settings > Graphics
    // toggle (off by default) so regular visitors never see it. The
    // dbgArcCull/dbgLOD isolation toggles and the quality switch itself now
    // live in the Settings modal (see openAppSettings/switchAppTab 'graphics'
    // tab) rather than as buttons drawn on the canvas.
    if (typeof window !== 'undefined' && window.dbgTerrainOverlay) {
      if (!drawViewport._dbgEl) {
        const el = document.createElement('div');
        el.id = '_terrDbgOverlay';
        el.style.cssText = 'position:fixed;top:4px;left:4px;z-index:99999;' +
          'background:rgba(0,0,0,.75);color:#0f0;font:9px monospace;' +
          'padding:6px 8px;max-width:96vw;white-space:pre;pointer-events:none;' +
          'line-height:1.4;border-radius:4px;';
        document.body.appendChild(el);
        drawViewport._dbgEl = el;
      }
      drawViewport._dbgEl.style.display = '';
      // Only track/print the currently-selected body if there is one, else the
      // first terrain body seen this frame — avoids the overlay flickering
      // between multiple bodies' stats every frame.
      const _dbgTarget = (typeof selectedBody !== 'undefined' && selectedBody) ? selectedBody : name;
      if (name === _dbgTarget) {
        drawViewport._dbgEl.textContent =
          `${name}  quality:${_terrainQuality}  method:${(typeof window!=='undefined'&&window.dbgArcCullMethod)||'edge'}  [arcCullToggle:${_dbgArcCullOn?'ON':'OFF'} lodToggle:${_dbgLODOn?'ON':'OFF'}]\n` +
          `physR_px: ${physR_px.toFixed(0)}\n` +
          `settled: ${_settled}\n` +
          `arcCull: ${_arcInfo ? !_arcInfo.fullCircle : false}\n` +
          `arcSpan: ${_arcInfo && !_arcInfo.fullCircle ? ((_arcInfo.arcEnd - _arcInfo.arcStart) * 180 / Math.PI).toFixed(1) + '°' : 'n/a'}\n` +
          `vsMaxN: ${_vsMaxN}\n` +
          `screenN_target: ${Math.ceil(2 * Math.PI * physR_px)}\n` +
          `terrN: ${terrN}`;
      }
    } else if (drawViewport._dbgEl) {
      drawViewport._dbgEl.style.display = 'none';
    }

    // Minimum physR_px to draw terrain polygon. Water depression (up to ~3% of radius)
    // needs sufficient pixel resolution to look smooth rather than jagged.
    // Below this threshold, draw a smooth disc instead (matches game map-view behaviour).
    const hasWater = !!(b.data.WATER_DATA?.lowerTerrain && b.data.WATER_DATA?.oceanMaskTexture
                        && b.data.WATER_DATA.oceanMaskTexture !== 'None');
    const terrainDrawThreshold = hasWater ? 80 : 6;

    // ── Step 1: Base fill — terrain polygon or icon gradient ─────────────────
    {
      const mc_disc = b.data.BASE_DATA?.mapColor;
      // Try to draw terrain polygon (returns false if no formula / still loading).
      // Use display radius `r` (not raw physR_px) so even sub-physical asteroids
      // draw a visible shaped polygon — physR_px < iconR collapses to sub-pixel otherwise.
      const _terrainDrawn = envFlags.heightmaps && b.data.TERRAIN_DATA && physR_px > terrainDrawThreshold && LOD > 0 &&
        drawTerrainBody(ctx2, b, name, sp, Math.max(r, physR_px), bodyRadius_m * radiusMult, mc_disc, terrN, _arcInfo, texImg);

      if(!_terrainDrawn){
        // Fallback: icon gradient disc. Stars/barycentres fade out when zoomed in;
        // terrain bodies waiting for assets stay fully opaque.
        // Skip the disc entirely when heightmaps are on and this body has TERRAIN_DATA
        // but terrain just hasn't computed yet — the unclipped disc bleeds outside the
        // terrain silhouette when the planet centre is off-screen (the artifact).
        // The terrain polygon will appear the next frame once the cache is warm.
        if(envFlags.heightmaps && b.data.TERRAIN_DATA && physR_px > terrainDrawThreshold){
          // intentionally empty — no fallback disc for terrain bodies while loading
        } else {
        const mc = mc_disc;
        const atmoH  = b.data.ATMOSPHERE_PHYSICS_DATA?.height  ?? 1;
        const atmoD  = b.data.ATMOSPHERE_PHYSICS_DATA?.density ?? 1;
        const gradH  = b.data.ATMOSPHERE_VISUALS_DATA?.GRADIENT?.height ?? 1;
        const hasCollider = b.data.TERRAIN_DATA?.collider !== false;
        const isStationary = (b.data.ORBIT_DATA?.direction ?? 1) === 0;
        const isBarycentre = b.preset === 'barycentre' ||
          (atmoH === 0 && atmoD === 0 && gradH === 0 && !hasCollider && isStationary);
        const mr = isBarycentre ? 102 : (mc ? Math.min(255, Math.round(mc.r * 255)) : 170);
        const mg = isBarycentre ? 102 : (mc ? Math.min(255, Math.round(mc.g * 255)) : 170);
        const mb = isBarycentre ? 136 : (mc ? Math.min(255, Math.round(mc.b * 255)) : 204);
        if(!drawViewport._iconColCache) drawViewport._iconColCache = {};
        const icKey = `${mr},${mg},${mb}`;
        if(!drawViewport._iconColCache[icKey]){
          drawViewport._iconColCache[icKey] = [
            `rgb(${Math.min(255,mr+50)},${Math.min(255,mg+50)},${Math.min(255,mb+50)})`,
            `rgb(${mr},${mg},${mb})`,
            `rgb(${Math.max(0,mr-60)},${Math.max(0,mg-60)},${Math.max(0,mb-60)})`
          ];
        }
        const [hi, mid, lo] = drawViewport._iconColCache[icKey];
        const iconFade = b.data.TERRAIN_DATA
          ? 1
          : Math.max(0, Math.min(1, 1 - (physR_px - 8) / 22));
        if(iconFade > 0){
          ctx2.save();
          ctx2.globalAlpha *= iconFade;
          const grad = ctx2.createRadialGradient(sp.x-r*.25, sp.y-r*.25, r*.1, sp.x, sp.y, r);
          grad.addColorStop(0,    hi);
          grad.addColorStop(0.45, mid);
          grad.addColorStop(1,    lo);
          ctx2.beginPath(); ctx2.arc(sp.x, sp.y, r, 0, Math.PI*2);
          ctx2.fillStyle = grad; ctx2.fill();
          ctx2.restore();
        }
        } // end else (not a terrain body with heightmaps on)
      }
    }

    // ── Step 2: Planet texture — clipped to terrain silhouette ───────────────
    if(texImg && physR_px > 1){
      let ptCutout      = b.data.TERRAIN_DATA?.TERRAIN_TEXTURE_DATA?.planetTextureCutout      ?? 0;
      let ptRotDeg      = b.data.TERRAIN_DATA?.TERRAIN_TEXTURE_DATA?.planetTextureRotation    ?? 0;
      let ptDontDistort = b.data.TERRAIN_DATA?.TERRAIN_TEXTURE_DATA?.planetTextureDontDistort ?? false;
      if(selectedBody === name && !liveSync._filling){
        const cutEl = document.getElementById('tt-cut');
        const rotEl = document.getElementById('tt-rot');
        const ndEl  = document.getElementById('tt-nd');
        if(cutEl && cutEl.value !== '') ptCutout  = parseFloat(cutEl.value) || 0;
        if(rotEl && rotEl.value !== '') ptRotDeg  = parseFloat(rotEl.value) || 0;
        if(ndEl) ptDontDistort = !ndEl.classList.contains('on');
      }

      // ── UV formula from Chunk.cs / Planet.cs ─────────────────────────────
      // (!DontDistortTextureCutout) ? vector2.normalized : (vector2 / radius)
      //
      // DontDistort = false  →  vector2.normalized  →  direction-only UV
      //   The texture is pegged to the sphere surface and does NOT stretch
      //   with terrain height. This is "no distortion" visually: mountains
      //   don't warp the texture. drawHalf = physR_px / cutoutAbs (fixed).
      //
      // DontDistort = true   →  vector2 / radius    →  linear UV
      //   Terrain height pushes UV coords outward — the texture stretches
      //   over bumps ("distortion" in the visual sense).
      //   drawHalf must cover the tallest peak.
      //   hasWater always forces this path (Planet.DontDistortTextureCutout).
      const hasWater    = !!(b.data.WATER_DATA);
      const dontDistort = hasWater || ptDontDistort;

      const cutoutAbs = Math.max(0.01, Math.abs((ptCutout !== 0) ? ptCutout : 1.0));
      const _baseR    = Math.max(r, physR_px);
      const rotRad    = -ptRotDeg * Math.PI / 180;

      let drawHalf;
      if(dontDistort){
        // Normalized UV (vector2.normalized): direction-only, height irrelevant.
        drawHalf = _baseR / cutoutAbs;
      } else {
        // Linear UV (vector2 / radius): terrain height shifts UVs outward.
        // Scale drawHalf to cover the tallest terrain point.
        const _tSamp = envFlags.heightmaps && _getTerrainSamples(name, b, bodyRadius_m * radiusMult, terrN, _arcInfo);
        let _maxFrac = 0;
        if(_tSamp){
          const R_m = bodyRadius_m * radiusMult;
          for(let _mi = 0; _mi < _tSamp.heights.length; _mi++){
            const f = _tSamp.heights[_mi] / R_m;
            if(f > _maxFrac) _maxFrac = f;
          }
        }
        drawHalf = _baseR * (1 + _maxFrac) / cutoutAbs;
      }

      const _displayR = Math.max(r, physR_px);
      const _tcp = envFlags.heightmaps && physR_px > terrainDrawThreshold && _terrainClipPath(b, name, sp, _displayR, bodyRadius_m * radiusMult, terrN, _arcInfo);

      ctx2.save();
      if (_tcp) {
        _applyTerrainClip(ctx2, _tcp, sp, _displayR);
      } else {
        ctx2.beginPath(); ctx2.arc(sp.x, sp.y, _displayR, 0, Math.PI*2); ctx2.clip();
      }
      ctx2.translate(sp.x, sp.y);
      ctx2.rotate(rotRad);
      // Additional screen-bounds clip in rotated local space to prevent the GPU
      // rasterizing a massive off-screen rect. Compute viewport AABB in local space.
      { const cosR = Math.cos(-rotRad), sinR = Math.sin(-rotRad);
        const corners = [[0,0],[W,0],[0,H],[W,H]];
        let lxMn=Infinity,lxMx=-Infinity,lyMn=Infinity,lyMx=-Infinity;
        for (const [cx,cy] of corners) {
          const lx = cx-sp.x, ly = cy-sp.y;
          const rx = cosR*lx - sinR*ly, ry = sinR*lx + cosR*ly;
          if(rx<lxMn)lxMn=rx; if(rx>lxMx)lxMx=rx;
          if(ry<lyMn)lyMn=ry; if(ry>lyMx)lyMx=ry;
        }
        // Clamp to texture rect and add 1px margin
        const dx = Math.max(-drawHalf, lxMn-1), dy = Math.max(-drawHalf, lyMn-1);
        const dw = Math.min(drawHalf, lxMx+1) - dx, dh = Math.min(drawHalf, lyMx+1) - dy;
        if (dw > 0 && dh > 0) {
          // Map dest rect back to source UV
          const iw = texImg.naturalWidth, ih = texImg.naturalHeight;
          const toSrcX = iw / (drawHalf*2), toSrcY = ih / (drawHalf*2);
          const sx = Math.max(0, (dx + drawHalf) * toSrcX);
          const sy = Math.max(0, (dy + drawHalf) * toSrcY);
          const sw = Math.min(iw - sx, dw * toSrcX);
          const sh = Math.min(ih - sy, dh * toSrcY);
          if (sw > 0 && sh > 0)
            ctx2.drawImage(texImg, sx, sy, sw, sh, dx, dy, dw, dh);
        }
      }
      ctx2.restore();
    } else if(!texImg && ptex && ptex !== 'None'){
      // Texture named but not in cache yet — log once
      if(!_sfsDbgLogged) _sfsDbgLogged = {};
      if(!_sfsDbgLogged[name]){
        _sfsDbgLogged[name] = true;
        const cacheImg = textureCache[ptex];
        console.warn(`[SFS|NODRAW] ${name} | planetTexture:"${ptex}" | inCache:${!!cacheImg}` +
          (cacheImg ? ` | complete:${cacheImg.complete} naturalW:${cacheImg.naturalWidth}` : '') +
          ` | physR_px:${physR_px.toFixed(1)}`);
      }
    }

    // ── Water overlay (WATER_DATA) ─────────────────────────────────────────
    // Black = deep water, lighter grey = shallower, white = land.
    // We render the water mask as a colour overlay on the planet disc.
    // ── Surface Textures A & B — tiled world-space overlay on terrain surface ──────────
    // ── Surface Textures A & B — tiled strip at terrain surface ───────────────
    // Game tiles A and B in world-space arc coordinates, blended by textureFormula.
    if(envFlags.surface && b.data.TERRAIN_DATA && LOD >= 2){
      const TTD  = b.data.TERRAIN_DATA.TERRAIN_TEXTURE_DATA;
      const saName = TTD?.surfaceTexture_A;
      const sbName = TTD?.surfaceTexture_B;
      const saSize = TTD?.surfaceTextureSize_A;
      const sbSize = TTD?.surfaceTextureSize_B;
      const layerM  = (TTD?.surfaceLayerSize != null && TTD.surfaceLayerSize >= 0) ? TTD.surfaceLayerSize : 20;
      const maxFadeV = (TTD?.maxFade != null && TTD.maxFade >= 0) ? TTD.maxFade : 1.0;
      const minFadeV = (TTD?.minFade != null && TTD.minFade >= 0) ? TTD.minFade : 0.0;

      // Per-texture LOD thresholds — surfaceLOD_A/B override the default 80px fade-in distance.
      // Negative / missing = use default. The fade window is always 140px wide.
      const _lodA = (TTD?.surfaceLOD_A != null && TTD.surfaceLOD_A >= 0) ? TTD.surfaceLOD_A : 80;
      const _lodB = (TTD?.surfaceLOD_B != null && TTD.surfaceLOD_B >= 0) ? TTD.surfaceLOD_B : 80;
      // Combined fade start = minimum of the two active textures (show whichever kicks in first)
      const saHasTex = saName && saName !== 'None';
      const sbHasTex = sbName && sbName !== 'None';
      const abLodStart = (saHasTex && sbHasTex) ? Math.min(_lodA, _lodB)
                       : saHasTex ? _lodA : sbHasTex ? _lodB : 80;

      const saImg = saHasTex && textureCache[saName]?.complete && textureCache[saName].naturalWidth > 0 ? textureCache[saName] : null;
      const sbImg = sbHasTex && textureCache[sbName]?.complete && textureCache[sbName].naturalWidth > 0 ? textureCache[sbName] : null;

      if((saImg || sbImg) && layerM > 0){
        const surfFade = Math.min(1, (physR_px - abLodStart) / 140);
        if(surfFade > 0){
          const radius_m = bodyRadius_m * radiusMult;
          // N: strips per revolution — derived from LOD tier, then scaled by terrain detail.
          // LOD 2 (mid) = 90 strips, LOD 3 (near) = 180. Each strip is one drawImage call.
          const _detailFracSurf = (typeof window !== 'undefined' && window.terrainDetail != null)
            ? Math.max(0.05, window.terrainDetail / 100) : 1;
          const N = Math.max(12, Math.round((LOD >= 3 ? 180 : 90) * _detailFracSurf));

          // GetRepeat: SurfaceArea = 2π*radius_m, factor = 4.712389 = 3π/2
          // Negative sizes are valid sentinel values in SFS (-1 = default); use abs for tiling math.
          const SURF_AREA = 2 * Math.PI * radius_m;
          const REP_FACTOR = 4.712389;
          const saAbsX = saSize && saSize.x !== 0 ? Math.abs(saSize.x) : 100;
          const saAbsY = saSize && saSize.y !== 0 ? Math.abs(saSize.y) : 100;
          const sbAbsX = sbSize && sbSize.x !== 0 ? Math.abs(sbSize.x) : 100;
          const sbAbsY = sbSize && sbSize.y !== 0 ? Math.abs(sbSize.y) : 100;
          const repAx = saImg ? SURF_AREA / (saAbsX * REP_FACTOR) : 8;
          const repAy = saImg ? radius_m / saAbsY : 4;
          const repBx = sbImg ? SURF_AREA / (sbAbsX * REP_FACTOR) : 8;
          const repBy = sbImg ? radius_m / sbAbsY : 4;

          // textureFormula blend per angle
          const blendArr = _evalTextureFormula(name, b, radius_m, N);
          // terrain heights for surface-following strip
          const terrRes  = envFlags.heightmaps ? _getTerrainSamples(name, b, radius_m, N, _arcInfo) : null;

          const discR_px = Math.max(r, physR_px);
          const layerPx  = (layerM / radius_m) * discR_px;

          // Pre-sample textures at TEX_SZ resolution
          const TEX_SZ = Math.max(8, Math.round(128 * _detailFracSurf));
          function ensurePixels(img) {
            if(!img) return;
            // Re-sample if the cached size doesn't match the current TEX_SZ
            if(img._spx && img._spxSz === TEX_SZ) return;
            const tc = document.createElement('canvas'); tc.width = tc.height = TEX_SZ;
            tc.getContext('2d').drawImage(img, 0, 0, TEX_SZ, TEX_SZ);
            img._spx   = tc.getContext('2d').getImageData(0,0,TEX_SZ,TEX_SZ).data;
            img._spxSz = TEX_SZ;
          }
          ensurePixels(saImg); ensurePixels(sbImg);

          function sampleTex(img, u, v) {
            const tx = (((u % 1) + 1) % 1 * TEX_SZ) | 0;
            const ty = (((v % 1) + 1) % 1 * TEX_SZ) | 0;
            const i4 = (ty * TEX_SZ + tx) * 4;
            return [img._spx[i4]/255, img._spx[i4+1]/255, img._spx[i4+2]/255];
          }

          // ── Polar-mapped surface layer canvas ──────────────────────────────────
          // Render A/B surface textures into a square offscreen canvas in screen space,
          // sampling texture coordinates in polar space around the planet centre.
          // One drawImage call replaces the broken per-strip-rect approach.
          // Canvas size: 2*(discR_px+layerPx) square, planet centre at (SZ/2, SZ/2).
          // Size the offscreen canvas: diameter of planet + layer, scaled by detail,
          // capped at 1024 to keep memory/CPU reasonable.
          const _surfSZFull = Math.ceil((discR_px + layerPx) * 2);
          const _surfSZ = Math.min(1024, Math.max(64, Math.round(_surfSZFull * _detailFracSurf)));
          const _surfCx = _surfSZ / 2, _surfCy = _surfSZ / 2;
          const _pxPerM  = discR_px / radius_m; // screen pixels per metre

          // NOTE: cKey previously only recorded terrRes?1:0 (just "do we have
          // terrain data") rather than which ARC that data covers. Since
          // surfOff is a persistent offscreen canvas cached across frames,
          // that meant once built for one visible arc (e.g. while looking at
          // one part of the planet), it was reused UNCHANGED for every later
          // frame at the same zoom/N/texture settings — even after panning
          // to a completely different arc of the same planet. The canvas
          // just kept showing its original baked-in crater/hill pattern
          // pasted at the new screen position, which reads as "detail looks
          // flat/static regardless of panning" even though the underlying
          // per-pixel sampling math (see the arcCulled branch above) is
          // correct for whichever single build actually ran.
          //
          // Fix: key on the actual arc range so a genuine pan/zoom that
          // changes what's visible invalidates and rebuilds this canvas.
          // Rounded to ~0.01 rad (~0.6°) so we don't rebuild on meaningless
          // sub-degree jitter — still far finer than any visible seam.
          //
          // This canvas can be up to 1024×1024 pixels, each doing trig +
          // texture sampling — genuinely expensive to rebuild, which is
          // exactly the kind of per-frame cost the terrN settle-timer above
          // was built to avoid during active pan/zoom. So reuse the same
          // _settled flag here: keep showing the last-built (possibly
          // slightly stale/offset) canvas while the gesture is still moving,
          // and only let the arc key advance — triggering a real rebuild —
          // once the view has settled. The scheduled settle-timer redraw
          // above already guarantees a follow-up frame fires shortly after
          // motion stops, so this reliably catches up within ~150ms.
          const _liveArcKeyPart = (terrRes && terrRes.arcCulled)
            ? `${terrRes.arcStart.toFixed(2)},${terrRes.arcEnd.toFixed(2)}`
            : (terrRes ? 'full' : 'none');
          if (!drawViewport._lastArcKey) drawViewport._lastArcKey = {};
          const _arcKeyPart = _settled
            ? (drawViewport._lastArcKey[name] = _liveArcKeyPart)
            : (drawViewport._lastArcKey[name] || _liveArcKeyPart);
          const cKey = `sAB3|${name}|${radius_m.toFixed(0)}|${saName}|${sbName}|${layerM}|${maxFadeV}|${minFadeV}|${N}|${TEX_SZ}|${blendArr?1:0}|${_arcKeyPart}|${saAbsX}|${saAbsY}|${sbAbsX}|${sbAbsY}|${_lodA}|${_lodB}|${_surfSZ}`;
          if(!drawViewport._surfCache) drawViewport._surfCache = {};
          if(!drawViewport._surfCacheOrder) drawViewport._surfCacheOrder = [];
          let surfOff = drawViewport._surfCache[cKey];

          if(!surfOff){
            surfOff = document.createElement('canvas');
            surfOff.width = surfOff.height = _surfSZ;
            const sc = surfOff.getContext('2d');
            const imgData = sc.createImageData(_surfSZ, _surfSZ);
            const pix = imgData.data;

            for(let py = 0; py < _surfSZ; py++){
              for(let px2 = 0; px2 < _surfSZ; px2++){
                const dx = px2 - _surfCx, dy = py - _surfCy;
                const distPx = Math.sqrt(dx*dx + dy*dy);

                // Terrain radius at this angle (pixels)
                const rawAngle = Math.atan2(-dy, dx); // trig angle, always 0..2π
                const angle01  = ((rawAngle / (Math.PI*2)) + 1) % 1;
                let surfR_px = discR_px;
                if(terrRes && terrRes.heights){
                  // interpolate height at this angle
                  //
                  // BUG (fixed): terrRes.heights may be ARC-CULLED — i.e. it only
                  // covers a narrow visible slice [arcStart, arcEnd], not the full
                  // 0..2π circle, whenever _arcInfo was passed non-null and non-
                  // fullCircle to _getTerrainSamples above. angle01 is always a
                  // full-circle 0..1 fraction though (rawAngle covers every pixel
                  // around the centre). Indexing terrRes.heights directly by
                  // angle01*hN silently wrapped that narrow arc's data across the
                  // WHOLE circle — sampling essentially uncorrelated/averaged
                  // points for almost every pixel, which is why real height
                  // variation (small craters, Perlin hills) visually flattened
                  // out once arc culling started actually returning a real arc
                  // instead of always falling back to fullCircle.
                  const hN = terrRes.heights.length;
                  let hIdx;
                  if (terrRes.arcCulled) {
                    const TWO_PI = Math.PI * 2;
                    // Map rawAngle into the SAME angle space arcStart/arcEnd were
                    // computed in (see _computeVisibleArc / _getTerrainSamples),
                    // unwrapping across the 0/2π boundary as needed.
                    let a = rawAngle;
                    while (a < terrRes.arcStart) a += TWO_PI;
                    while (a > terrRes.arcEnd) a -= TWO_PI;
                    if (a < terrRes.arcStart || a > terrRes.arcEnd) {
                      // Genuinely outside the culled arc (shouldn't normally happen
                      // for on-screen pixels, but guard anyway) — use bare disc
                      // radius rather than an out-of-range/garbage sample.
                      surfR_px = discR_px;
                      hIdx = null;
                    } else {
                      const arcSpanLocal = terrRes.arcEnd - terrRes.arcStart;
                      const tLocal = arcSpanLocal > 0 ? (a - terrRes.arcStart) / arcSpanLocal : 0;
                      hIdx = tLocal * (hN - 1);
                    }
                  } else {
                    hIdx = angle01 * hN;
                  }
                  if (hIdx != null) {
                    const hLo  = Math.max(0, Math.min(hN - 1, Math.floor(hIdx)));
                    const hHi  = terrRes.arcCulled ? Math.min(hN - 1, hLo + 1) : (hLo + 1) % hN;
                    const hFrac = hIdx - Math.floor(hIdx);
                    const h = terrRes.heights[hLo] * (1-hFrac) + terrRes.heights[hHi] * hFrac;
                    surfR_px = discR_px * (1 + h / radius_m);
                  }
                }
                const outerR_px = surfR_px + layerPx;

                // Only paint pixels in the surface layer band
                if(distPx < surfR_px || distPx > outerR_px) continue;

                // depthT: 0 at outer edge (surface top), 1 at inner edge (surface base)
                const depthT = layerPx > 0 ? (outerR_px - distPx) / layerPx : 0;
                const fade   = minFadeV + (maxFadeV - minFadeV) * (1 - depthT);
                if(fade < 0.005) continue;

                const ai    = Math.round(angle01 * (N-1));
                const blend = blendArr ? Math.max(0, Math.min(1, blendArr[ai])) : 0;
                const uA = angle01 * repAx,  vA = depthT * repAy;
                const uB = angle01 * repBx,  vB = depthT * repBy;

                let rr, gg, bb;
                if(saImg && sbImg){
                  const [ar,ag,ab] = sampleTex(saImg, uA, vA);
                  const [br,bg,bb2] = sampleTex(sbImg, uB, vB);
                  rr = ar+(br-ar)*blend; gg = ag+(bg-ag)*blend; bb = ab+(bb2-ab)*blend;
                } else if(saImg){
                  [rr,gg,bb] = sampleTex(saImg, uA, vA);
                } else {
                  [rr,gg,bb] = sampleTex(sbImg, uB, vB);
                }

                const idx = (py * _surfSZ + px2) * 4;
                pix[idx]   = Math.round(rr * 255);
                pix[idx+1] = Math.round(gg * 255);
                pix[idx+2] = Math.round(bb * 255);
                pix[idx+3] = Math.round(fade * 255);
              }
            }
            sc.putImageData(imgData, 0, 0);
            drawViewport._surfCache[cKey] = surfOff;
            // Bounded LRU-ish eviction — this cache previously had none at
            // all, and now grows faster since the cache key includes arc
            // position (a new entry per distinct settled viewing angle, not
            // just once per body). Cap at 40 entries; each can be up to
            // 1024×1024, so unbounded growth over a long panning session
            // could otherwise leak real memory.
            drawViewport._surfCacheOrder.push(cKey);
            if (drawViewport._surfCacheOrder.length > 40) {
              const evict = drawViewport._surfCacheOrder.shift();
              delete drawViewport._surfCache[evict];
            }
          }

          // Single drawImage — pixel loop already paints only in the surface layer band,
          // so no clip path is needed. Just save/restore for globalAlpha and composite.
          ctx2.save();
          ctx2.globalAlpha *= surfFade;
          ctx2.globalCompositeOperation = 'multiply';
          ctx2.imageSmoothingEnabled = true;
          ctx2.imageSmoothingQuality = 'high';
          ctx2.drawImage(surfOff,
            sp.x - _surfCx, sp.y - _surfCy, _surfSZ, _surfSZ);
          ctx2.restore();
        }
      }
    }

    if(envFlags.water && atmoFade > 0 && b.data.WATER_DATA){
      const WD = b.data.WATER_DATA;
      const maskTex = WD.oceanMaskTexture;
      const maskImg = maskTex && maskTex !== 'None' && textureCache[maskTex];
      if(maskImg && maskImg.complete && maskImg.naturalWidth > 0){
        // Build or reuse a water overlay canvas keyed on the mask + colour state.
        // FIX (Bug 3): include colour alpha values in cache key — previously alpha
        // wasn't hashed so different shallow/sand alpha settings shared the same canvas.
        const sandC   = WD.sand    || {r:.9, g:.86,b:.81,a:1};
        const shalC   = WD.shallow || {r:.1, g:.68,b:1,  a:.4};
        const deepC   = WD.deep    || {r:.1, g:.15,b:.55,a:1};
        const cacheKey = maskTex + '|' + _surfaceSZ()
          + [sandC.r,sandC.g,sandC.b,sandC.a,shalC.r,shalC.g,shalC.b,shalC.a,
             deepC.r,deepC.g,deepC.b,deepC.a].map(v=>v.toFixed(3)).join(',');
        if(!drawViewport._waterCache) drawViewport._waterCache = {};
        let wCanvas = drawViewport._waterCache[cacheKey];
        if(!wCanvas){
          const SZ = _surfaceSZ();
          wCanvas = document.createElement('canvas');
          wCanvas.width = wCanvas.height = SZ;
          const wx2 = wCanvas.getContext('2d');
          // Draw the mask into an offscreen canvas to read pixels
          const mc = document.createElement('canvas');
          mc.width = mc.height = SZ;
          const mx2 = mc.getContext('2d');
          mx2.drawImage(maskImg, 0, 0, SZ, SZ);
          const mData = mx2.getImageData(0, 0, SZ, SZ).data;
          // Build output image
          const oData = wx2.createImageData(SZ, SZ);
          const od = oData.data;
          // The ocean mask is an azimuthal disc projection: 0=open ocean, 128=coastline,
          // 255=land interior.  The coastal gradient on the water side spans roughly
          // maskVal 114-127 (~7-10px wide at 512px canvas resolution).
          //
          // FIX (Bug 2): the previous code used thresholds 116/124 which exposed too
          // wide a visible fringe of cyan/shallow colour.  Inspecting the vanilla Earth
          // mask and comparing to in-game screenshots reveals the water should appear
          // almost entirely as flat deep colour from orbit — only the last ~3-4 value
          // steps immediately before the 128 coast boundary should show any transition.
          //
          // Correct thresholds confirmed by pixel analysis of Earth_OceanMask_V2.png:
          //   0   – 123 : flat deep colour  (open ocean + most of coastal gradient)
          //   124 – 125 : deep → shallow blend  (~2px, nearly invisible)
          //   126 – 127 : shallow → sand blend  (~1-2px, barely a pixel fringe)
          //
          // The shallow colour's own alpha (e.g. Earth's shallow.a = 0.4) is correctly
          // preserved here.  The extra opacity_Surface global scale is applied at draw
          // time via globalAlpha, keeping the two knobs independent.
          const cx = SZ/2, cy = SZ/2, cr = SZ/2;
          for(let py=0; py<SZ; py++){
            for(let px2=0; px2<SZ; px2++){
              const dx = px2-cx, dy = py-cy;
              if(dx*dx+dy*dy > cr*cr) continue; // outside inscribed circle — skip
              const idx = (py*SZ+px2)*4;
              const maskVal = mData[idx];
              if(maskVal >= 128) continue; // land — skip
              let r2,g2,b2,a2;
              if(maskVal < 124){
                // Open ocean — flat deep colour (the vast majority of water pixels)
                r2=deepC.r; g2=deepC.g; b2=deepC.b; a2=deepC.a;
              } else if(maskVal < 126){
                // Narrow deep→shallow fringe (~2 value steps right at the coast)
                const t=(maskVal-124)/2;
                r2=deepC.r+(shalC.r-deepC.r)*t; g2=deepC.g+(shalC.g-deepC.g)*t;
                b2=deepC.b+(shalC.b-deepC.b)*t; a2=deepC.a+(shalC.a-deepC.a)*t;
              } else {
                // Shore pixel — shallow→sand (~2 value steps, right at land edge)
                const t=(maskVal-126)/2;
                r2=shalC.r+(sandC.r-shalC.r)*t; g2=shalC.g+(sandC.g-shalC.g)*t;
                b2=shalC.b+(sandC.b-shalC.b)*t; a2=shalC.a+(sandC.a-shalC.a)*t;
              }
              od[idx]   = Math.round(r2*255);
              od[idx+1] = Math.round(g2*255);
              od[idx+2] = Math.round(b2*255);
              od[idx+3] = Math.round(Math.min(1,a2)*255);
            }
          }
          wx2.putImageData(oData, 0, 0);
          drawViewport._waterCache[cacheKey] = wCanvas;
        }
        // Draw water overlay clipped to planet disc.
        // FIX (Bug 1): apply the same planetTextureRotation and planetTextureCutout
        // transforms used when drawing the surface texture so the ocean mask aligns
        // with the terrain beneath it.  Read live from sidebar when this body is selected.
        let wtCutout = b.data.TERRAIN_DATA?.TERRAIN_TEXTURE_DATA?.planetTextureCutout  ?? 1;
        let wtRotDeg = b.data.TERRAIN_DATA?.TERRAIN_TEXTURE_DATA?.planetTextureRotation ?? 0;
        if(selectedBody === name && !liveSync._filling){
          const cutEl = document.getElementById('tt-cut');
          const rotEl = document.getElementById('tt-rot');
          if(cutEl && cutEl.value !== '') wtCutout = parseFloat(cutEl.value) || 1;
          if(rotEl && rotEl.value !== '') wtRotDeg  = parseFloat(rotEl.value) || 0;
        }
        // wtCutoutAbs drives drawHalf sizing — sign of cutout has no visual effect in the editor.
        const wtCutoutAbs = Math.max(0.01, Math.min(1, Math.abs(wtCutout !== 0 ? wtCutout : 1.0)));
        const wtDrawHalf = r / wtCutoutAbs;
        const wtRotRad   = -wtRotDeg * Math.PI / 180;
        // atmoFade gates rendering (same as clouds) — on Titan the thick atmo naturally
        // tints the layer via the atmosphere renderer drawn on top.
        // opacity_Surface controls base transparency.
        const waterAlpha = Math.min(1, (WD.opacity_Surface ?? 0.8));
        ctx2.save();
        // Water clips to plain disc (NOT terrain polygon) — water fills the depressed areas
        // that were cut from the terrain polygon, so clipping to terrain would hide all water.
        ctx2.beginPath();
        ctx2.arc(sp.x, sp.y, Math.max(r, physR_px), 0, Math.PI * 2);
        ctx2.clip();
        ctx2.globalAlpha *= waterAlpha;
        ctx2.translate(sp.x, sp.y);
        ctx2.rotate(wtRotRad);
        ctx2.drawImage(wCanvas, -wtDrawHalf, -wtDrawHalf, wtDrawHalf*2, wtDrawHalf*2);
        ctx2.restore();
      }
    }

    // ── Terrain Texture C — tiled close-up detail overlay ──────────────────
    // terrainTexture_C is a repeating texture tiled in world-space over the
    // surface at surfaceTextureSize_C.x × surfaceTextureSize_C.y metres per tile.
    // It is only meaningful close-up; we fade it in when physR_px > 80px.
    if(envFlags.surface && b.data.TERRAIN_DATA){
      const TTD = b.data.TERRAIN_DATA.TERRAIN_TEXTURE_DATA;
      const tcName = TTD?.terrainTexture_C;
      const tcSize = TTD?.terrainTextureSize_C;
      const tcImg  = tcName && tcName !== 'None' && tcSize &&
                     textureCache[tcName] && textureCache[tcName].complete &&
                     textureCache[tcName].naturalWidth > 0
                     ? textureCache[tcName] : null;
      // Per-texture LOD threshold for C. surfaceLOD_C overrides the default 80px fade-in.
      const _lodC = (TTD?.surfaceLOD_C != null && TTD.surfaceLOD_C >= 0) ? TTD.surfaceLOD_C : 80;
      if(tcImg && physR_px > _lodC){
        // Negative sizes are valid SFS sentinels (-1 = default ~100m); use abs for tiling.
        const tcSzX = tcSize && tcSize.x !== 0 ? Math.abs(tcSize.x) : 100;
        const tcSzY = tcSize && tcSize.y !== 0 ? Math.abs(tcSize.y) : 100;
        const tileW_px = (tcSzX / (bodyRadius_m * radiusMult)) * physR_px;
        const tileH_px = (tcSzY / (bodyRadius_m * radiusMult)) * physR_px;
        if(tileW_px >= 0.5 && tileH_px >= 0.5){
          // Fade: 0 at lodC threshold, full 120px later
          const tcAlpha = Math.min(1, (physR_px - _lodC) / 120) * 0.55;
          ctx2.save();
          // Clip to terrain shape (or disc fallback)
          const _tccp = envFlags.heightmaps && physR_px > terrainDrawThreshold && _terrainClipPath(b, name, sp, Math.max(r, physR_px), bodyRadius_m * radiusMult, terrN, _arcInfo);
          if(_tccp){ _applyTerrainClip(ctx2, _tccp, sp, Math.max(r, physR_px)); }
          else { ctx2.beginPath(); ctx2.arc(sp.x, sp.y, Math.max(r, physR_px), 0, Math.PI*2); ctx2.clip(); }
          // Tile the texture in a pattern centred on the body
          ctx2.globalAlpha *= tcAlpha;
          ctx2.globalCompositeOperation = 'multiply';
          // Scale down the source image for texture C when detail < 100 —
          // lower detail → smaller internal canvas → coarser tiling quality.
          const _detailFracC = (typeof window !== 'undefined' && window.terrainDetail != null)
            ? Math.max(0.05, window.terrainDetail / 100) : 1;
          const _tcSrc = (() => {
            if(_detailFracC >= 1) return tcImg;
            const _tcSz = Math.max(4, Math.round(tcImg.naturalWidth * _detailFracC));
            const _tcSzH = Math.max(4, Math.round(tcImg.naturalHeight * _detailFracC));
            const _ckC = `tcDown|${tcName}|${_tcSz}|${_tcSzH}`;
            if(!drawViewport._tcDownCache) drawViewport._tcDownCache = {};
            if(!drawViewport._tcDownCache[_ckC]){
              const _dc = document.createElement('canvas');
              _dc.width = _tcSz; _dc.height = _tcSzH;
              _dc.getContext('2d').drawImage(tcImg, 0, 0, _tcSz, _tcSzH);
              drawViewport._tcDownCache[_ckC] = _dc;
            }
            return drawViewport._tcDownCache[_ckC];
          })();
          const pat = ctx2.createPattern(_tcSrc, 'repeat');
          if(pat){
            // Scale the pattern to tileW_px × tileH_px, anchored at sp
            const mx = new DOMMatrix();
            mx.a = tileW_px / _tcSrc.width;
            mx.d = tileH_px / _tcSrc.height;
            mx.e = sp.x % tileW_px;
            mx.f = sp.y % tileH_px;
            pat.setTransform(mx);
            ctx2.fillStyle = pat;
            // Use the terrain-aware max radius so the fillRect covers the full
            // heightmap silhouette. When the heightmap extends beyond physR_px
            // (e.g. large terrain bumps), using plain `r` leaves the pattern
            // short of the terrain polygon edges, making the square rect boundary
            // visible as a box artifact against the bumpy silhouette.
            const _tcSamp = envFlags.heightmaps && _getTerrainSamples(name, b, bodyRadius_m * radiusMult, terrN, _arcInfo);
            let _tcMaxR = Math.max(r, physR_px);
            if(_tcSamp){
              const R_m = bodyRadius_m * radiusMult;
              for(let _tci = 0; _tci < _tcSamp.heights.length; _tci++){
                const _tcFrac = _tcSamp.heights[_tci] / R_m;
                const _tcR = physR_px * (1 + _tcFrac);
                if(_tcR > _tcMaxR) _tcMaxR = _tcR;
              }
            }
            ctx2.fillRect(sp.x - _tcMaxR - tileW_px, sp.y - _tcMaxR - tileH_px,
                          (_tcMaxR + tileW_px) * 2, (_tcMaxR + tileH_px) * 2);
          }
          ctx2.restore();
        }
      }
    }

    // ── Cloud texture band — gated on outer_px threshold, independent of atmoFade ──
    if(envFlags.clouds && !envFlags.heightmaps){
      const CLD = b.data.ATMOSPHERE_VISUALS_DATA?.CLOUDS;
      if(CLD && CLD.texture && CLD.texture !== 'None'){
        const srcImg = textureCache[CLD.texture];
        if(srcImg && srcImg.complete && srcImg.naturalWidth > 0){
          // ScalePlanetData multiplies all atmosphere heights by atmoMult before shader setup
          const atmoMult  = getAtmoDifficultyMult(b.data);
          const startH_m  = (CLD.startHeight || 0)                              * atmoMult;
          const cloudH_m  = Math.max(1, (CLD.height || 1))                      * atmoMult;
          const rawAlpha  = CLD.alpha || 0;
          const widthM    = Math.max(1, (CLD.width || 1)) * atmoMult; // ScalePlanetData: width *= atmoMult

          if(rawAlpha > 0.005){
            // Match Planet.cs exactly:
            //   _CloudStartY = (R + startH + gradH) / gradH - 1  (line 427)
            //   _CloudSizeY  = (R + gradH) / cloudH              (line 428)
            //   _CloudSizeX  = ceil((R + startH) * 2π / width)   (line 429)
            // Cloud mesh covers the full gradient disc (planet surface → R+gradH).
            // UV v=0 is disc outer edge, increasing inward. _CloudStartY offsets
            // where texture starts; _CloudSizeY tiles it radially.
            const R_eff_px    = bodyRadius_m * radiusMult;
            const gradH_cld   = _gradH_m;
            const atmoOuter_m = R_eff_px + gradH_cld;
            const atmoDisk_px = physR_px * atmoOuter_m / R_eff_px;
            // Cloud disc spans full gradient disc: planet surface → atmo outer
            const inner_px    = physR_px;
            const outer_px    = atmoDisk_px;

            const cldThr = 2;
            if(atmoDisk_px >= cldThr){
              const cldFade = Math.max(0, Math.min(1, (atmoDisk_px - cldThr) / Math.max(cldThr, 0.01)));
              if(cldFade > 0){
                const baseAlpha = Math.min(rawAlpha, 1) * cldFade;

                // _CloudSizeX = ceil((R + startH) * 2π / width)  — Planet.cs line 429
                // Epsilon subtracted before ceil: when the ratio lands a hair above a
                // clean integer (e.g. 1.0000000003) purely from float rounding — which
                // happens whenever an edit nudges R_eff_px by a tiny amount — ceil()
                // was flipping numTiles from 1 to 2, tiling the texture twice around
                // the disc and producing a second, duplicate ring.
                const numTiles = Math.max(1, Math.ceil((R_eff_px + startH_m) * 6.283185307 / widthM - 1e-6));
                // _CloudSizeY = (R + gradH) / cloudH  — Planet.cs line 428
                const cloudSizeY = (R_eff_px + gradH_cld) / cloudH_m;
                // _CloudStartY = (R + startH + gradH) / gradH - 1  — Planet.cs line 427
                const cloudStartY_val = (R_eff_px + startH_m + gradH_cld) / gradH_cld - 1;

                if(!drawViewport._cldDbg) drawViewport._cldDbg = {};
                if(!drawViewport._cldDbg[name]){ drawViewport._cldDbg[name]=true; console.log(`[CLD] ${name}: R=${R_eff_px}, startH=${startH_m}, cloudH=${cloudH_m}, gradH=${gradH_cld}, numTiles=${numTiles}, cloudSizeY=${cloudSizeY.toFixed(3)}, cloudStartY=${cloudStartY_val.toFixed(3)} | PIXELS: physR_px=${physR_px.toFixed(2)}, atmoDisk_px=${atmoDisk_px.toFixed(2)}, outer/inner ratio=${(atmoDisk_px/physR_px).toFixed(4)} (theoretical (R+gradH)/R=${(atmoOuter_m/R_eff_px).toFixed(4)})`); }

                const cacheKey = 'cld9:' + CLD.texture
                                + '|' + R_eff_px.toFixed(1)
                                + '|' + gradH_cld.toFixed(1)
                                + '|' + startH_m.toFixed(1)
                                + '|' + cloudH_m.toFixed(1)
                                + '|' + numTiles
                                + '|' + cloudSizeY.toFixed(3)
                                + '|' + _surfaceSZ()
                                + '|' + window._cldDebug.radialFlip
                                + '|' + window._cldDebug.vInputFlip
                                + '|' + window._cldDebug.angularFlip
                                + '|' + window._cldDebug.scaleY
                                + '|' + window._cldDebug.offsetY
                                + '|' + window._cldDebug.wrapMode
                                + '|' + window._cldDebug.formulaMode;
                if(!drawViewport._cloudCache) drawViewport._cloudCache = {};
                let wc = drawViewport._cloudCache[cacheKey];
                if(!wc){
                  const SZ = _surfaceSZ();
                  wc = document.createElement('canvas');
                  wc.width = wc.height = SZ;
                  const wctx = wc.getContext('2d');

                  const sc = document.createElement('canvas');
                  sc.width = srcImg.naturalWidth; sc.height = srcImg.naturalHeight;
                  sc.getContext('2d').drawImage(srcImg, 0, 0);
                  const sd = sc.getContext('2d').getImageData(0, 0, sc.width, sc.height).data;
                  const tw = sc.width, th = sc.height;

                  const od = wctx.createImageData(SZ, SZ);
                  const out = od.data;
                  const cx0 = SZ / 2, cy0 = SZ / 2;
                  // outerN = half canvas = full gradient disc radius
                  const outerN = SZ / 2;
                  // innerN = planet surface radius in canvas px
                  const innerN = outerN * (physR_px / atmoDisk_px);

                  const edgeFade = 1.5;
                  for(let py = 0; py < SZ; py++){
                    for(let px2 = 0; px2 < SZ; px2++){
                      const dx = px2 - cx0, dy = py - cy0;
                      const dist = Math.sqrt(dx * dx + dy * dy);
                      if(dist < innerN - edgeFade || dist > outerN + edgeFade) continue;
                      const innerAlpha = Math.min(1, (dist - (innerN - edgeFade)) / edgeFade);
                      const outerAlpha = Math.min(1, ((outerN + edgeFade) - dist) / edgeFade);
                      const edgeA = Math.min(innerAlpha, outerAlpha);
                      // v_disc: 0 at atmo outer edge, 1 at planet surface — matches shader
                      const v_disc = Math.max(0, Math.min(1, (outerN - dist) / (outerN - innerN)));
                      // History: earlier attempts tried Math.max(1,cloudSizeY) clamps and
                      // additive offset guesses on the WRONG formula shape — disproven by
                      // Kōjin and others. A RenderDoc capture of the actual compiled
                      // SFS/Atmosphere pixel shader (ps_4_0 disassembly) resolved this for
                      // real: the true per-pixel radial coordinate is
                      //   cloudV = _CloudSizeY * ( v1.y*(_CloudStartY+1) - _CloudStartY )
                      // — not a simple offset+scale. That's now the default ('real' mode
                      // below). 'legacy' (the old shape) stays selectable for comparison.
                      const cloudSizeYEff = cloudSizeY;
                      // Everything below reads from window._cldDebug, wired to the live
                      // cloud debug panel (window.showCloudDebugPanel()) so these can be
                      // experimented with in real time without editing code:
                      //  - formulaMode: 'real' (default) = cloudSizeY*scaleY * ( v_disc*
                      //                 (cloudStartY+offsetY+1) - (cloudStartY+offsetY) )
                      //                 — the confirmed real shader shape (see above).
                      //                 'legacy' = offsetY + v_disc*cloudSizeY*scaleY, the
                      //                 old guessed shape, kept for comparison only.
                      //                 offsetY adjusts _CloudStartY directly (additive);
                      //                 scaleY multiplies _CloudSizeY. Same two sliders,
                      //                 correctly combined for whichever shape is selected.
                      //  - scaleY:      multiplies cloudSizeYEff
                      //  - offsetY:     legacy: added directly to v_raw. real: added to
                      //                 cloudStartY_val before it enters the real formula.
                      //  - wrapMode:    'wrap' fracs the result (allows multi-layer
                      //                 stacking), 'clamp' holds it at [0,1] (never
                      //                 stacks, even if the scaled value exceeds 1)
                      //  - radialFlip:  mirrors which end of the texture (outer edge vs
                      //                 surface) reads which row — still relevant since
                      //                 v1.y's orientation (0 at surface vs 0 at outer
                      //                 edge) wasn't directly recoverable from the
                      //                 disassembly alone
                      //  - angularFlip: mirrors top/bottom (the -dy vs dy debate from
                      //                 earlier in this conversation), independent axis
                      const dbg = window._cldDebug;
                      let v_raw;
                      if(dbg.formulaMode === 'exact'){
                        // Derived directly from a RenderDoc capture: the Mesh Viewer's
                        // VS Output table showed TEXCOORD0 (= v1) is the atmosphere
                        // mesh's own LOCAL radius — 0 at the planet's exact center, 1 at
                        // the mesh's outer rim — NOT "0 at surface, 1 at outer edge" as
                        // every earlier attempt assumed. The surface sits partway through
                        // that range, at local radius R/(R+gradH), because the mesh is a
                        // simple unit disc scaled out to R+gradH while still starting
                        // from the true center. Substituting that into the *proven*
                        // shader formula (confirmed against the actual constant buffer:
                        // _CloudStartY=0.8255, _CloudSizeY=0.9127 for Somber, matching
                        // this code's own computed values exactly) and simplifying
                        // algebraically collapses everything to a clean linear closed
                        // form — no offset/scale fudging needed, in principle:
                        //   v_raw = [ (R+gradH) − v_disc·(R+startHeight+gradH) ] / cloudH
                        // offsetY/scaleY below still apply on top in case this needs
                        // fine correction, but should ideally be near 0/1 if this is
                        // truly the whole picture.
                        // v_raw is negated from the raw derivation (1 - ...) to bake in
                        // a confirmed, permanent correction: Unity's texture V=0 row is
                        // the opposite end of the image from what this code's row-index
                        // math (texRowF = v_frac*(th-1)) treats as row 0 — a standard
                        // OpenGL/Unity-vs-canvas texture-coordinate convention mismatch,
                        // not a per-planet fudge. Confirmed by testing: without this, the
                        // bright/structured part of the texture lands at the outer edge
                        // and black lands at the surface — backwards from every in-game
                        // reference screenshot in this conversation, which consistently
                        // show bright content near the planet fading to black outward.
                        const csY = dbg.scaleY;
                        const num = (R_eff_px + gradH_cld) - v_disc * (R_eff_px + startH_m + gradH_cld);
                        v_raw = dbg.offsetY + (1 - csY * (num / cloudH_m));
                      } else if(dbg.formulaMode === 'real'){
                      // v_disc_input: which physical end feeds the formula as "0". The
                      // real formula is NOT symmetric (it's not simply mirrored by
                      // flipping the OUTPUT), so whether v1.y in the actual mesh runs
                      // surface->outer or outer->surface has to be tested by flipping
                      // the INPUT, separately from radialFlip (which flips the result
                      // afterward and is a different, weaker operation on this formula
                      // shape). Cone meshes conventionally have V=0 at the apex — if the
                      // apex is at the planet's center, v1.y=0 could mean "surface" (or
                      // even inside it), the opposite of what v_disc assumes by default.
                        const v_disc_input = dbg.vInputFlip ? (1 - v_disc) : v_disc;
                        const csY = cloudSizeYEff * dbg.scaleY;
                        const cStart = cloudStartY_val + dbg.offsetY;
                        v_raw = csY * (v_disc_input * (cStart + 1) - cStart);
                      } else {
                        const v_disc_input = dbg.vInputFlip ? (1 - v_disc) : v_disc;
                        v_raw = dbg.offsetY + v_disc_input * cloudSizeYEff * dbg.scaleY;
                      }
                      let v_frac = (dbg.wrapMode === 'clamp')
                        ? Math.max(0, Math.min(1, v_raw))
                        : v_raw - Math.floor(v_raw);
                      if(dbg.radialFlip) v_frac = 1 - v_frac;
                      let ang = Math.atan2(dbg.angularFlip ? -dy : dy, dx) / (2 * Math.PI);
                      if(ang < 0) ang += 1;
                      const u = (ang * numTiles) % 1;
                      const sx = Math.min(tw - 1, Math.floor(u * tw));
                      const texRowF = v_frac * (th - 1);
                      // Bilinear interpolation along Y — same fix the atmosphere polar
                      // warp already applies (see _atmoPolarCache build above) and for
                      // the same reason: nearest-neighbor row sampling stairsteps hard
                      // when a texture's rows are meaningful radial/ring geometry rather
                      // than generic tileable cloud noise, which is exactly the case the
                      // "3D ring via clouds" trick relies on.
                      const sy0 = Math.min(th - 1, Math.max(0, Math.floor(texRowF)));
                      const sy1 = Math.min(th - 1, sy0 + 1);
                      const fy  = texRowF - sy0;
                      const si0 = (sy0 * tw + sx) * 4;
                      const si1 = (sy1 * tw + sx) * 4;
                      const oi = (py * SZ + px2) * 4;
                      out[oi]     = sd[si0]     + (sd[si1]     - sd[si0])     * fy + 0.5 | 0;
                      out[oi + 1] = sd[si0 + 1] + (sd[si1 + 1] - sd[si0 + 1]) * fy + 0.5 | 0;
                      out[oi + 2] = sd[si0 + 2] + (sd[si1 + 2] - sd[si0 + 2]) * fy + 0.5 | 0;
                      const a0 = sd[si0 + 3], a1 = sd[si1 + 3];
                      out[oi + 3] = Math.round((a0 + (a1 - a0) * fy) * edgeA);
                    }
                  }
                  wctx.putImageData(od, 0, 0);
                  drawViewport._cloudCache[cacheKey] = wc;
                }
                ctx2.save();
                ctx2.globalAlpha *= baseAlpha;
                ctx2.imageSmoothingEnabled = true;
                ctx2.imageSmoothingQuality = 'high';
                // SFS convention: cloud/ring textures are unlit source art with NO
                // alpha channel (most are opaque JPGs) — black pixels mean "nothing
                // here" and blend additively/emissively in-game, same convention
                // already used for GRADIENT above (see the 'lighter' composite
                // branch around line 1355). Left at the default 'source-over',
                // every near-black texel (the vast majority of a ring texture like
                // Ring_Somber, which is mostly empty space around a thin ring band)
                // gets painted as an OPAQUE dark-grey disc instead of staying
                // invisible, producing the muddy, mismatched smear seen over the
                // planet instead of a clean ring silhouette.
                ctx2.globalCompositeOperation = 'lighter';
                ctx2.drawImage(wc, sp.x - outer_px, sp.y - outer_px, outer_px * 2, outer_px * 2);
                ctx2.restore();
              }
            }
          }
        }
      }
    }

    // ── FOG overlay ────────────────────────────────────────────────────────
    // In-game: FOG.Evaluate(viewDistance) returns a single Color that is set as
    // a flat _Fog uniform on the terrain shader. The limb effect is produced by
    // the 3D shader using surface normals. In 2D we approximate this as a radial
    // gradient: fully transparent at the disc centre, full fog colour at the limb.
    //
    // FOG key `distance` = camera view distance in metres (Z from planet surface),
    // NOT altitude. We evaluate the gradient at bodyRadius_m (typical map-view
    // distance) to get the representative fog colour for the current zoom level,
    // then apply it as a centre→limb radial, scaled by dbgFogOpacity.
    if(envFlags.fog && !envFlags.heightmaps && atmoFade > 0 && b.data.ATMOSPHERE_VISUALS_DATA?.FOG?.keys){
      const fogKeys = b.data.ATMOSPHERE_VISUALS_DATA.FOG.keys;
      if(fogKeys.length >= 1){
        // ColorGradient.Evaluate — mirrors the C# implementation exactly:
        // clamp below first key, clamp above last key, lerp between keys.
        const evalFog = (keys, dist) => {
          const sorted = keys.slice().sort((a,b) => a.distance - b.distance);
          if(dist <= sorted[0].distance) return sorted[0].color;
          const last = sorted[sorted.length - 1];
          if(dist >= last.distance) return last.color;
          for(let i = 0; i < sorted.length - 1; i++){
            if(dist <= sorted[i+1].distance){
              const t = (dist - sorted[i].distance) / (sorted[i+1].distance - sorted[i].distance);
              const a = sorted[i].color, b = sorted[i+1].color;
              return { r: a.r+(b.r-a.r)*t, g: a.g+(b.g-a.g)*t,
                       b: a.b+(b.b-a.b)*t, a: a.a+(b.a-a.a)*t };
            }
          }
          return last.color;
        };
        // Evaluate at current view distance: physR_px encodes how zoomed we are,
        // but fog should represent a fixed "from space" look — use bodyRadius_m.
        const fogColor = evalFog(fogKeys, bodyRadius_m);
        const {r:fr, g:fg, b:fb, a:fa} = fogColor;
        const fogAlpha = Math.min(1, fa * dbgFogOpacity);
        if(fogAlpha > 0.005){
          // ── Fog is rendered from a cached 256×256 offscreen canvas ──
          // Previously ctx2.createRadialGradient used screen-space sp.x/sp.y/r, which
          // changes every frame while zooming — a new gradient object was allocated on
          // every draw call. Instead, build a fixed canvas once per fog colour+alpha
          // combination and scale it with drawImage (same approach as water/clouds).
          const frI = Math.round(fr*255), fgI = Math.round(fg*255), fbI = Math.round(fb*255);
          const fogCacheKey = 'fog:' + frI + ',' + fgI + ',' + fbI + ',' + fogAlpha.toFixed(4);
          if(!drawViewport._fogCache) drawViewport._fogCache = {};
          let fogCanvas = drawViewport._fogCache[fogCacheKey];
          if(!fogCanvas){
            const SZ = 256;
            fogCanvas = document.createElement('canvas');
            fogCanvas.width = fogCanvas.height = SZ;
            const fCtx = fogCanvas.getContext('2d');
            const half = SZ / 2;
            // Gradient centre→limb. Full opacity is placed at stop 0.94 so the
            // gradient is already at maximum density before reaching the canvas edge
            // and the arc-clip anti-alias fringe. The last stop repeats that opacity
            // all the way to the edge so no under-filled ring survives.
            const fogGrad = fCtx.createRadialGradient(half, half, 0, half, half, half);
            fogGrad.addColorStop(0,    `rgba(${frI},${fgI},${fbI},0)`);
            fogGrad.addColorStop(0.5,  `rgba(${frI},${fgI},${fbI},${(fogAlpha*0.25).toFixed(4)})`);
            fogGrad.addColorStop(0.94, `rgba(${frI},${fgI},${fbI},${fogAlpha.toFixed(4)})`);
            fogGrad.addColorStop(1.0,  `rgba(${frI},${fgI},${fbI},${fogAlpha.toFixed(4)})`);
            fCtx.fillStyle = fogGrad;
            fCtx.fillRect(0, 0, SZ, SZ);
            drawViewport._fogCache[fogCacheKey] = fogCanvas;
          }
          const fogR_px = physR_px;
          ctx2.save();
          ctx2.globalAlpha = 1;
          ctx2.globalCompositeOperation = 'source-over';
          ctx2.beginPath(); ctx2.arc(sp.x, sp.y, fogR_px, 0, Math.PI*2); ctx2.clip();
          ctx2.drawImage(fogCanvas, sp.x - fogR_px, sp.y - fogR_px, fogR_px * 2, fogR_px * 2);
          ctx2.restore();
        }
      }
    }

    // ── Front Clouds overlay (FRONT_CLOUDS_DATA) ──
    // Game builds the mesh at radius = planet.Radius + frontClouds.height, so the
    // cloud disc extends *beyond* the surface. Match that here.
    // Soft edge fade: the game's FrontClouds shader uses a _FadeZoneM that fades
    // alpha toward zero at the disc edge. We replicate this with a destination-out
    // radial mask applied after drawing the image.
    if(envFlags.fclouds && !envFlags.heightmaps && b.data.FRONT_CLOUDS_DATA){
      const FCD = b.data.FRONT_CLOUDS_DATA;
      const fcTex = FCD.cloudsTexture;
      const fcImg = fcTex && fcTex !== 'None' && textureCache[fcTex];
      if(fcImg && fcImg.complete && fcImg.naturalWidth > 0){
        let fcCutout = FCD.cloudTextureCutout ?? 0.5;
        if(selectedBody === name && !liveSync._filling){
          const fcCutEl = document.getElementById('fc-cut');
          if(fcCutEl && fcCutEl.value !== '') fcCutout = parseFloat(fcCutEl.value) ?? fcCutout;
        }
        const fcCutClamped = Math.max(0, Math.min(1, fcCutout));
        // Decompiled Front Clouds shader (hash d5d4dade-c536bd60-dcf5e788-7b8a0660): cb0[2].x
        // (_TextureCutout) is used ONLY to rescale the sample UV before the texture lookup
        // (step 2 — replicated below via the texture-cache zoom, dh = cx/fcCutClamped). The
        // shader's final output alpha (steps 7-15) is radialFade * (sharpened) textureAlpha —
        // _TextureCutout never re-enters as an overall opacity multiplier. Previously fcAlpha
        // multiplied fcCutClamped in here too, silently dimming/fading front-cloud discs whose
        // texture is deliberately cropped tight (cutout < 1) with no basis in the real shader.
        //
        // fcAlpha's LOD fade used to just be `atmoFade` — computed from the CARRIER body's
        // own on-screen radius (physR_px), not from the cloud disc it actually draws. That's
        // fine when the body and its clouds are comparable sizes, but it breaks the common
        // "invisible carrier" pattern: a near-zero-radius dummy body (BASE_DATA.radius ~1,
        // e.g. a moving shadow/terminator layer orbiting the real planet) whose entire visual
        // footprint comes from a huge FRONT_CLOUDS_DATA.height. physR_px for a radius-1 body
        // is always sub-pixel, so atmoFade permanently clamped to 0 (see its formula above:
        // (physR_px - _atmoLod)/_atmoLod, floor _atmoLod=2px) and the disc never drew, no
        // matter the zoom or the disc's own actual on-screen size. Fix: compute fcR_px (the
        // disc's real screen radius) first, then derive ITS OWN LOD fade from that, mirroring
        // the atmoFade formula above but keyed to the cloud disc's own physical outer size
        // instead of the carrier body's.
        //
        // Difficulty.ScalePlanetData: frontClouds.height *= atmoMult;
        // frontClouds.fadeZoneHeight *= atmoMult; — both were being read raw here,
        // so front-cloud discs (shadow terminators, city lights, etc.) sat at the
        // wrong altitude on anything but Normal difficulty. Apply atmoMult, and
        // — same fix as the atmosphere halo above — use the radiusMult-scaled
        // body radius (R_eff_px) as the ratio denominator, not raw bodyRadius_m,
        // since physR_px already has radiusMult baked in and the two multipliers
        // (radiusMult, atmoMult) are independent in-game.
        const fcAtmoMult  = getAtmoDifficultyMult(b.data);
        const R_eff_px_fc = bodyRadius_m * radiusMult;
        // Clamp so a negative FRONT_CLOUDS_DATA.height (now reachable via the
        // day/night SMA-offset slider) can never push the effective disc
        // radius (R_eff_px_fc + fcHeight_m) to zero/negative — that would
        // flip fcR_px negative and corrupt all the downstream circle math.
        const fcHeight_m  = Math.max(-R_eff_px_fc * 0.99, (FCD.height || 0) * fcAtmoMult);
        // Screen radius of the cloud disc. Built from `scale * vpZ` (px-per-metre,
        // same factors physR_px itself is built from — see its definition above)
        // rather than "physR_px * ratio", so it stays correct even when the carrier
        // body's own radius is ~0 (the ratio form divided by R_eff_px_fc and
        // produced 0/0 = NaN for a true zero-radius carrier).
        const fcR_px      = (R_eff_px_fc + fcHeight_m) * scale * vpZ;
        // Same LOD-fade shape as atmoFade (see _atmoLod/_atmoPhysOuter_m above), but
        // driven by the cloud disc's own physical outer size, not the carrier body's.
        const fcPhysOuter_m = R_eff_px_fc + fcHeight_m; // metres, unscaled
        const fcLod = fcPhysOuter_m > 0
          ? Math.min(32, Math.max(2, 2 * Math.log10(Math.max(1, fcPhysOuter_m / 1e5))))
          : 2;
        const fcAlpha = Math.max(0, Math.min(1, (fcR_px - fcLod) / Math.max(fcLod, 0.01)));
        if(fcAlpha > 0.01){
          // Distinguish "explicitly set to 0" (true hard edge) from "field never
          // set" (older planet files without this key at all) — both used to
          // collapse to the same fcFadeZone_m===0 value below, which silently
          // forced every hard-edge request into an 8% fallback fade instead.
          const fcFadeZoneSpecified = FCD.fadeZoneHeight != null;
          const fcFadeZone_m = (FCD.fadeZoneHeight || 0) * fcAtmoMult;

          // fadeZoneHeight is world-space — convert to a fraction of the cloud radius
          // so it's zoom-independent (used in cache key and for rendering).
          const fadeZoneFrac = fcFadeZoneSpecified
            ? Math.min(1, Math.max(0, fcFadeZone_m) / (bodyRadius_m + fcHeight_m))
            : 0.08; // fallback: 8% of cloud radius only if the field was never set

          // ── Front-cloud texture cache (image content only — no clip, no fade) ──
          // The disc's circular clip AND its radial edge-fade are pure vector
          // geometry, drawn natively on the main canvas below, so they're always
          // crisp regardless of zoom. The texture itself is a different story:
          // many front-cloud textures (e.g. a day/night terminator shading used
          // for the "invisible moon" trick) bake a soft gradient INTO the image
          // content, not just at the outer rim — and that gradient is genuine
          // raster content, so caching it at a small fixed size (512/1024) and
          // stretching it to a large on-screen disc (big radius, or zoomed in)
          // pixelates that internal gradient even though the outer edge stays
          // sharp. So: bucket the texture-cache resolution up to the nearest
          // power of two that covers the actual on-screen diameter, same
          // approach as the geometry fix, capped to avoid runaway memory use.
          const _fcTexNeeded = fcR_px * 2;
          let fcTexSZ = _surfaceSZ();
          while (fcTexSZ < _fcTexNeeded && fcTexSZ < 2048) fcTexSZ *= 2;
          const fcTexCacheKey = 'fctex:' + fcTex + '|' + fcCutClamped.toFixed(3) + '|' + fcTexSZ + '|' + (FCD.sharpenAlpha ? 1 : 0);
          if(!drawViewport._fcTexCache) drawViewport._fcTexCache = {};
          let fcTexCanvas = drawViewport._fcTexCache[fcTexCacheKey];
          if(!fcTexCanvas){
            const SZ = fcTexSZ;
            fcTexCanvas = document.createElement('canvas');
            fcTexCanvas.width = fcTexCanvas.height = SZ;
            const tCtx = fcTexCanvas.getContext('2d');
            const cx = SZ / 2, cy = SZ / 2;
            const dh = fcCutClamped > 0 ? cx / fcCutClamped : cx;
            tCtx.drawImage(fcImg, cx - dh, cy - dh, dh*2, dh*2);
            // Decompiled shader steps 9-13: when sharpenAlpha (_SharpenAlpha) is enabled, the
            // TEXTURE's own alpha channel (not the disc's radial fade) is put through a hard
            // cutout curve: alpha' = saturate((alpha - 0.25) * 1.5), instead of being used raw.
            // This is a per-pixel op on the cached texture content, cached alongside it since
            // it depends only on the source image + this flag, not per-frame state.
            if(FCD.sharpenAlpha){
              const id = tCtx.getImageData(0, 0, SZ, SZ);
              const d = id.data;
              for(let p = 3; p < d.length; p += 4){
                const a = d[p] / 255;
                d[p] = Math.max(0, Math.min(1, (a - 0.25) * 1.5)) * 255;
              }
              tCtx.putImageData(id, 0, 0);
            }
            drawViewport._fcTexCache[fcTexCacheKey] = fcTexCanvas;
          }

          // ── Composite: build in an isolated scratch canvas, then one normal draw ──
          // The disc clip + edge fade must NOT be applied directly on ctx2: by the
          // time we get here, the planet's own surface/terrain for this body has
          // already been painted onto ctx2 earlier in this same per-body pass, and
          // destination-out erases whatever pixels are already there — not just the
          // cloud layer we just drew. Since the cloud disc radius (fcR_px, which
          // includes cloud height) is larger than the planet's own visible radius,
          // whenever the fade zone's inner edge dips inside the planet's actual
          // surface it visibly eats a ring out of the surface itself. Building the
          // texture + clip + fade in an isolated scratch canvas first (containing
          // ONLY the cloud content, nothing else) and compositing that with a
          // single normal source-over draw guarantees the fade can only ever
          // affect the cloud layer. The scratch canvas is reused across frames and
          // sized to the same bucketed resolution as the texture cache, so it only
          // reallocates when crossing a bucket threshold, not every frame.
          // Each deferred entry needs its OWN canvas that survives until the
          // later global pass — a single shared scratch canvas would be
          // overwritten by the next body in this same loop before the
          // deferred draw for this body ever ran. Pool by index instead: the
          // number of front-cloud layers per frame is small and stable, so
          // this still reuses canvases across frames, just one per
          // concurrent layer instead of one shared total.
          if(!drawViewport._fcScratchPool) drawViewport._fcScratchPool = [];
          const _fcPoolIdx = _fcDeferred.length;
          let fcScratch = drawViewport._fcScratchPool[_fcPoolIdx];
          if(!fcScratch){
            fcScratch = document.createElement('canvas');
            drawViewport._fcScratchPool[_fcPoolIdx] = fcScratch;
          }
          if(fcScratch.width !== fcTexSZ){ fcScratch.width = fcTexSZ; fcScratch.height = fcTexSZ; }
          const sCtx = fcScratch.getContext('2d');
          sCtx.clearRect(0, 0, fcTexSZ, fcTexSZ);
          const scx = fcTexSZ / 2, scy = fcTexSZ / 2, scr = fcTexSZ / 2;
          // The circular clip is scoped ONLY to the image draw, then ended (restore())
          // before the erase pass below. Previously the clip stayed active through the
          // destination-out erase too — at partially-covered clip-AA pixels (coverage
          // c, 0<c<1) that made the erase itself only c-strong (1*c instead of 1), so
          // result = (image_alpha*c) * (1-c), which is NON-ZERO for any c strictly
          // between 0 and 1 (peaks at c=0.5: a full quarter of the original alpha
          // survives). That's a faint ring baked in at exactly the clip radius,
          // wobbling in/out of the intended edge with sub-pixel rounding — visible
          // even in the raw (pre-blit-scale) mask. Ending the clip first means the
          // erase gradient's alpha=1 zone (r >= fadeOuterR) applies at FULL strength,
          // uniformly, with no coverage multiplication of its own — cleanly zeroing
          // any residual from the draw's clip AA regardless of where exactly it sits.
          sCtx.save();
          sCtx.beginPath(); sCtx.arc(scx, scy, scr, 0, Math.PI*2); sCtx.clip();
          sCtx.drawImage(fcTexCanvas, 0, 0, fcTexSZ, fcTexSZ);
          sCtx.restore();
          // fadeZoneFrac is a FRACTION of body radius, set as an absolute km value
          // in FRONT_CLOUDS_DATA (fadeZoneHeight). For very large bodies that
          // fraction can be tiny (e.g. an 88km fade zone on a 76,000km-radius
          // planet is ~0.1% of the radius) — at any normal on-screen size that
          // converts to well under one screen pixel, and a gradient can't
          // visually transition across less than a pixel: the rasterizer just
          // snaps it to a hard, jagged-antialiased edge no matter how high-res
          // the texture cache is. Convert the on-screen minimum (in real pixels)
          // into scratch-space units via the scratch→screen stretch factor, and
          // never let the fade go thinner than that — this is a small, deliberate
          // deviation from literal physical accuracy, justified because a
          // sub-pixel-wide "gradient" isn't perceivable as a gradient anyway, it
          // just reads as noise; enforcing a visible minimum better honors the
          // actual intent (a smooth edge) than exact-but-invisible precision.
          const MIN_FADE_SCREEN_PX = 2.5;
          const minFadeZone_sc = fcR_px > 0 ? MIN_FADE_SCREEN_PX * (scr / fcR_px) : 0;
          let fadeZone_sc = Math.max(scr * fadeZoneFrac, minFadeZone_sc);
          fadeZone_sc = Math.min(fadeZone_sc, scr);
          // AA_MARGIN declared here (rather than only inside the if-block below) so it's
          // always available for the debug snapshot even when fadeZone_sc rounds to ~0.
          const AA_MARGIN = 1;
          const fadeOuterR = Math.max(0, scr - AA_MARGIN);
          if(fadeZone_sc > 0.01){
            sCtx.save();
            sCtx.globalCompositeOperation = 'destination-out';
            // Full-erase (alpha=1) must land strictly INSIDE the clip circle's edge,
            // not exactly on it. sCtx.clip() anti-aliases the disc boundary over
            // ~1px, giving that rim partial image coverage even with no fade at
            // all. If the gradient's alpha=1 stop sits at the same radius as the
            // clip (scr), that AA rim gets multiplied by an erase alpha that
            // hasn't actually reached 1 yet at those sub-pixel positions — so a
            // thin ring of leftover opacity survives right at the edge on every
            // disc. Pulling the outer stop in by 1 scratch-px guarantees erasure
            // is already complete by the time rendering reaches the AA rim.
            // NOTE: this fillRect is intentionally UNCLIPPED (no arc/clip() active
            // here — that clip already ended above) so the erase applies at full,
            // uniform strength past fadeOuterR with no coverage-fraction multiplying
            // against the image draw's own clip AA. See comment above the drawImage.
            const fadeGrad = sCtx.createRadialGradient(scx, scy, Math.max(0, fadeOuterR - fadeZone_sc), scx, scy, fadeOuterR);
            fadeGrad.addColorStop(0, 'rgba(0,0,0,0)');
            fadeGrad.addColorStop(1, 'rgba(0,0,0,1)');
            sCtx.fillStyle = fadeGrad;
            sCtx.fillRect(0, 0, fcTexSZ, fcTexSZ);
            sCtx.restore();
          }

          // ── Debug: log geometry once per unique parameter combo, per body ──
          if(FC_DEBUG){
            if(!drawViewport._fcDbgLogged) drawViewport._fcDbgLogged = {};
            const _dbgKey = name + '|' + fcTexCacheKey + '|' + fadeZone_sc.toFixed(3) + '|' + fcR_px.toFixed(2);
            if(drawViewport._fcDbgLogged[_dbgKey] !== true){
              drawViewport._fcDbgLogged[_dbgKey] = true;
              const scaleFactor = scr > 0 ? (fcR_px / scr) : 0;
              console.log(
                `[FC_DEBUG] ${name}\n` +
                `  fcR_px (on-screen cloud radius)       = ${fcR_px.toFixed(2)}\n` +
                `  fcTexSZ (scratch canvas resolution)   = ${fcTexSZ}\n` +
                `  scr (scratch clip radius)             = ${scr.toFixed(2)}\n` +
                `  scale factor (screen px / scratch px) = ${scaleFactor.toFixed(4)}\n` +
                `  AA_MARGIN (scratch px)                = ${AA_MARGIN}  →  ${(AA_MARGIN*scaleFactor).toFixed(3)} screen px\n` +
                `  fadeOuterR (scratch px, full-erase pt) = ${fadeOuterR.toFixed(2)}  →  screen radius ${(fadeOuterR*scaleFactor).toFixed(2)}\n` +
                `  fadeZone_sc (scratch px, fade width)   = ${fadeZone_sc.toFixed(2)}  →  ${(fadeZone_sc*scaleFactor).toFixed(2)} screen px\n` +
                `  fadeZoneFrac (config)                  = ${fadeZoneFrac.toFixed(4)}\n` +
                `  fade start screen radius               = ${((fadeOuterR-fadeZone_sc)*scaleFactor).toFixed(2)}\n` +
                `  entry blit size (screen px)            = ${(fcR_px*2).toFixed(2)}  (source ${fcTexSZ}px → ${fcTexSZ===Math.round(fcR_px*2)?'1:1':'SCALED'})`
              );
            }
          }

          // Defer the actual paint — see _fcDeferred comment above the loop start.
          // Everything up to this point (texture cache, scratch composite, fade)
          // is unchanged; only the final blit onto ctx2 moves to a later, globally
          // Z-sorted pass so this layer can correctly darken/light ANY body's
          // surface, not just bodies drawn later than it in hierarchy order.
          _fcDeferred.push({
            z: (typeof FCD.positionZ === 'number') ? FCD.positionZ : 0,
            scratch: fcScratch,
            x: sp.x - fcR_px,
            y: sp.y - fcR_px,
            size: fcR_px * 2,
            alpha: fcAlpha,
            // debug-only fields, cheap to always attach
            _dbgName: name,
            _dbgSpX: sp.x, _dbgSpY: sp.y,
            _dbgFcR_px: fcR_px, _dbgScr: scr,
            _dbgFadeOuterR: fadeOuterR, _dbgFadeZoneSc: fadeZone_sc,
            _dbgAaMargin: AA_MARGIN, _dbgFcTexSZ: fcTexSZ
          });
        }
      }
    }

    // ── Terrain surface helper (mirrors _lmSurfaceXY from landmarks) ──
    // Returns screen-space radius at a given trig angle (radians, CCW).
    // Uses the exact same formula as landmark placement: physR_px * (1 + h / radius_m)
    const _terrRes360 = (envFlags.heightmaps && b.data.TERRAIN_DATA && physR_px > terrainDrawThreshold)
      ? _getTerrainSamples(name, b, bodyRadius_m * radiusMult, 360, null)
      : null;
    const _terrRadius_m = bodyRadius_m * radiusMult;
    function _surfaceRpx(rad) {
      if(_terrRes360 && _terrRes360.heights){
        const normAng = ((rad % (Math.PI*2)) + Math.PI*2) % (Math.PI*2);
        const idx = Math.round(normAng / (Math.PI*2) * _terrRes360.N) % _terrRes360.N;
        const h = _terrRes360.heights[idx] || 0;
        return Math.max(r, physR_px * (1 + h / _terrRadius_m));
      }
      return r;
    }

    // ── Selection ring — traces the actual terrain surface ──
    if(selectedBody === name){
      const RING_GAP = 6;
      const ringSteps = 128;
      ctx2.beginPath();
      for(let _si = 0; _si <= ringSteps; _si++){
        const rad = (_si / ringSteps) * Math.PI * 2;
        const rPx = _surfaceRpx(rad) + RING_GAP;
        const px = sp.x + rPx * Math.cos(rad);
        const py = sp.y - rPx * Math.sin(rad);
        _si === 0 ? ctx2.moveTo(px, py) : ctx2.lineTo(px, py);
      }
      ctx2.closePath();
      ctx2.strokeStyle='rgba(80,180,255,0.75)'; ctx2.lineWidth=1.5;
      ctx2.setLineDash([4,4]); ctx2.stroke(); ctx2.setLineDash([]);
    }
    // ── Group-select ring — orange, slightly larger ──
    if(typeof groupSelectMode !== 'undefined' && groupSelectMode &&
       typeof groupSelected !== 'undefined' && groupSelected.has(name)){
      const GS_GAP = selectedBody === name ? 10 : 6;
      const ringSteps2 = 128;
      ctx2.beginPath();
      for(let _si = 0; _si <= ringSteps2; _si++){
        const rad = (_si / ringSteps2) * Math.PI * 2;
        const rPx = _surfaceRpx(rad) + GS_GAP;
        const px = sp.x + rPx * Math.cos(rad);
        const py = sp.y - rPx * Math.sin(rad);
        _si === 0 ? ctx2.moveTo(px, py) : ctx2.lineTo(px, py);
      }
      ctx2.closePath();
      ctx2.strokeStyle = 'rgba(255,155,40,0.9)';
      ctx2.lineWidth = 2;
      ctx2.setLineDash([4,4]); ctx2.stroke(); ctx2.setLineDash([]);
    }

    ctx2.restore(); // end bodyFadeA globalAlpha

    // ── Label — fades out earlier than the body ──
    if(labelFadeA > 0.01){
      const fontSize = Math.round(9 * iconScale);
      ctx2.globalAlpha = labelFadeA;
      ctx2.font = `${fontSize}px "JetBrains Mono",monospace`;
      ctx2.textAlign = 'center';
      const displayName = (selectedBody===name && drawViewport._pendingName) ? drawViewport._pendingName : name;
      // Sample terrain at bottom of planet (trig 3π/2 = canvas straight-down)
      // so the label always sits below the actual surface, not buried in terrain.
      const bottomRpx = _surfaceRpx(Math.PI * 1.5);
      const labelY = sp.y + bottomRpx + fontSize + 2;
      // Dark shadow for readability against any background
      ctx2.fillStyle = 'rgba(0,0,0,0.65)';
      ctx2.fillText(displayName, sp.x+1, labelY + 1);
      ctx2.fillStyle = selectedBody===name ? 'rgba(180,230,255,0.98)' : 'rgba(160,210,255,0.85)';
      ctx2.fillText(displayName, sp.x, labelY);
      ctx2.globalAlpha = 1;
    }

    // ── Landmarks — show midpoint dot+label always when zoomed close enough (physR_px > 40),
    //              AND show full arc extent in neon when "SHOW ON PLANET" is checked ──
    const lms = b.data.LANDMARKS;
    if(lms && lms.length && physR_px > 40){
      const lmAlpha = Math.min(1, (physR_px - 40) / 60);
      // Neon palette — one colour per landmark index, cycles if more than 6
      const NEON_COLORS = [
        '#00ffff',   // cyan
        '#ff00ff',   // magenta
        '#00ff44',   // green
        '#ffee00',   // yellow
        '#ff6600',   // orange
        '#aa00ff',   // violet
      ];
      const showLmArcs = document.getElementById('lm-show')?.checked && selectedBody === name;

      // ── Terrain height lookup for landmark placement ──────────────────────
      // Fetch the N=360 full-circle sample (always cached; non-blocking).
      // When heightmaps are enabled and terrain exists, use actual surface radius
      // so landmark dots/arcs sit on the terrain surface rather than on the bare disc.
      const _lmTerrRes = envFlags.heightmaps && b.data.TERRAIN_DATA
        ? _getTerrainSamples(name, b, bodyRadius_m * radiusMult, 360, null)
        : null;
      const _lmRadius_m = bodyRadius_m * radiusMult;

      // Given a SFS angle in degrees → screen-space {x,y} on the terrain surface.
      // SFS convention: 0°=right, 90°=top.
      // Canvas convention: angle 0=right, positive=CW (y-down).
      // So canvas_rad = deg * PI/180, and we use cos(rad) for x, -sin(rad) for y
      // (because SFS +angle is CCW = canvas -y direction).
      function _lmSurfaceXY(deg) {
        const rad = deg * Math.PI / 180;  // trig angle (CCW)
        let rPx = physR_px;
        if(_lmTerrRes) {
          // Find nearest sample index for this angle
          const normAng = ((rad % (Math.PI*2)) + Math.PI*2) % (Math.PI*2);
          const idx = Math.round(normAng / (Math.PI*2) * _lmTerrRes.N) % _lmTerrRes.N;
          const h = _lmTerrRes.heights[idx] || 0;
          rPx = physR_px * (1 + h / _lmRadius_m);
        }
        return { x: sp.x + rPx * Math.cos(rad), y: sp.y - rPx * Math.sin(rad), rPx };
      }

      // Match the game's Math_Utility formulas exactly (see LandmarkData.cs):
      //   AngularWidth = NormalizeAngleDegrees(endAngle - startAngle)      -> (-180, 180]
      //   Center       = NormalizePositiveAngleDegrees(startAngle + AngularWidth/2) -> [0, 360)
      // A naive (start+end)/2 + min/max breaks for arcs that cross the 0°/360° wrap
      // (e.g. startAngle:353, endAngle:13), which is exactly what Utopia Planitia does.
      function _lmNormAngleDeg(a){ while(a>180) a-=360; while(a<=-180) a+=360; return a; }
      function _lmNormPosAngleDeg(a){ while(a>360) a-=360; while(a<0) a+=360; return a; }

      lms.forEach((lm, lmIdx) => {
        if(!lm.name) return;
        const neon = NEON_COLORS[lmIdx % NEON_COLORS.length];
        const lmWidth  = _lmNormAngleDeg(lm.endAngle - lm.startAngle) || 0;
        const midDeg   = _lmNormPosAngleDeg(lm.startAngle + lmWidth / 2);
        const { x: lx, y: ly } = _lmSurfaceXY(midDeg);

        // ── Full arc extent (neon glow) — follows terrain surface ──
        if(showLmArcs){
          // Build a polyline along the terrain surface between startAngle and endAngle,
          // walking in the direction given by the normalized width (handles wraparound).
          // Step every 1° so the arc hugs the terrain bumps.
          const angStart = lm.startAngle;
          const angSpan  = lmWidth; // signed: positive = CCW, negative = CW
          const arcSteps = Math.max(2, Math.ceil(Math.abs(angSpan)));

          // Helper: build Path2D polyline along terrain surface for this arc
          function _buildLmArcPath(offset_px) {
            const p = new Path2D();
            for(let si = 0; si <= arcSteps; si++){
              const deg = angStart + (si / arcSteps) * angSpan;
              const rad = deg * Math.PI / 180;
              let rPx = physR_px;
              if(_lmTerrRes){
                const normAng = ((rad % (Math.PI*2)) + Math.PI*2) % (Math.PI*2);
                const idx = Math.round(normAng / (Math.PI*2) * _lmTerrRes.N) % _lmTerrRes.N;
                const h = _lmTerrRes.heights[idx] || 0;
                rPx = physR_px * (1 + h / _lmRadius_m);
              }
              rPx += offset_px;
              const px = sp.x + rPx * Math.cos(rad);
              const py = sp.y - rPx * Math.sin(rad);
              si === 0 ? p.moveTo(px, py) : p.lineTo(px, py);
            }
            return p;
          }

          // Outer glow pass
          ctx2.save();
          ctx2.globalAlpha = lmAlpha * 0.45;
          ctx2.strokeStyle = neon;
          ctx2.lineWidth = 10;
          ctx2.lineCap = 'round';
          ctx2.shadowColor = neon;
          ctx2.shadowBlur = 14;
          ctx2.stroke(_buildLmArcPath(5));
          ctx2.restore();

          // Solid neon arc
          ctx2.save();
          ctx2.globalAlpha = lmAlpha * 0.9;
          ctx2.strokeStyle = neon;
          ctx2.lineWidth = 3;
          ctx2.lineCap = 'round';
          ctx2.shadowColor = neon;
          ctx2.shadowBlur = 8;
          ctx2.stroke(_buildLmArcPath(5));
          ctx2.restore();
        }

        // ── Midpoint dot ──
        ctx2.save();
        ctx2.globalAlpha = lmAlpha;
        ctx2.beginPath(); ctx2.arc(lx, ly, 3.5, 0, Math.PI*2);
        ctx2.fillStyle = showLmArcs ? neon : 'rgba(255,255,255,0.95)';
        if(showLmArcs){
          ctx2.shadowColor = neon;
          ctx2.shadowBlur = 8;
        }
        ctx2.fill();

        // ── Label ──
        ctx2.font = 'bold 12px "JetBrains Mono",monospace';
        ctx2.fillStyle = showLmArcs ? neon : 'rgba(255,255,255,0.95)';
        ctx2.textAlign = 'center';
        ctx2.shadowColor = showLmArcs ? neon : 'rgba(0,0,0,0.85)';
        ctx2.shadowBlur = showLmArcs ? 8 : 4;
        ctx2.fillText(lm.name, lx, ly - 10);
        ctx2.restore();
      });
      ctx2.globalAlpha = 1;
    }

    // ── Flat Zones — draw arc on circumference when checkbox is on ──
    const showFZ = document.getElementById('fz-show')?.checked && selectedBody === name;
    if(showFZ && r > 8){
      // Read live from DOM so slider/input changes update immediately without Apply
      const liveFzs = collectFlatZones();
      const fzs = liveFzs.length ? liveFzs : (b.data.TERRAIN_DATA?.flatZones || []);
      if(fzs && fzs.length){
        fzs.forEach(fz => {
          // fz.angle is centre in radians, fz.width is half-width in metres
          // Convert to angular half-width: width / radius (in rad)
          const bodyR = (b.data.BASE_DATA||{}).radius || 1;
          const centre = fz.angle || 0; // radians, SFS coord (0=right,PI/2=top)
          const halfW  = (fz.width || 0) / bodyR; // radians
          // SFS to canvas: canvas_ang = -sfs_rad
          const cStart = -(centre + halfW);
          const cEnd   = -(centre - halfW);
          // Outer glow pass
          ctx2.beginPath();
          ctx2.arc(sp.x, sp.y, r + 4, cStart, cEnd);
          ctx2.strokeStyle = 'rgba(80,255,160,0.25)';
          ctx2.lineWidth = 7;
          ctx2.lineCap = 'round';
          ctx2.stroke();
          // Solid arc
          ctx2.beginPath();
          ctx2.arc(sp.x, sp.y, r + 4, cStart, cEnd);
          ctx2.strokeStyle = 'rgba(120,255,180,1.0)';
          ctx2.lineWidth = 3;
          ctx2.lineCap = 'round';
          ctx2.stroke();
          // Tick spike at centre
          const cx2 = sp.x + (r+2) * Math.cos(-centre);
          const cy2 = sp.y + (r+2) * Math.sin(-centre);
          const ox = sp.x + (r+14) * Math.cos(-centre);
          const oy = sp.y + (r+14) * Math.sin(-centre);
          ctx2.beginPath(); ctx2.moveTo(cx2, cy2); ctx2.lineTo(ox, oy);
          ctx2.strokeStyle = 'rgba(120,255,180,0.9)';
          ctx2.lineWidth = 2; ctx2.stroke();
        });
        ctx2.lineCap = 'butt';
      }
    }
    } catch(e) { console.error('[SFS|DRAW] Error drawing body "'+name+'": '+e.message, e); }
  });

  // ── Deferred front-cloud pass — globally Z-sorted across ALL bodies ──
  // Every body's surface/terrain/atmosphere is now fully painted (loop above).
  // Draw the front-cloud composites collected during that loop here, sorted
  // purely by positionZ (more-positive first/behind, more-negative last/in
  // front) with no regard for hierarchy depth or draw order above. This is
  // what lets a shadow body (near-zero Z) darken a planet's surface even
  // when that planet's OWN front-cloud layer (e.g. city lights, very
  // negative Z) was painted in the same per-body pass as its surface — the
  // shadow now always gets a chance to composite onto that surface here,
  // and anything with more-negative Z than the shadow still correctly
  // layers back on top of it afterward, matching FrontClouds.cs where every
  // layer shares one sortingOrder and only this flat Z ever decides order.
  _fcDeferred
    .sort((a, b) => b.z - a.z)
    .forEach(entry => {
      try {
        ctx2.save();
        ctx2.globalAlpha = entry.alpha;
        ctx2.drawImage(entry.scratch, entry.x, entry.y, entry.size, entry.size);
        ctx2.restore();
      } catch(e) { console.error('[SFS|DRAW] Error compositing deferred front-clouds: '+e.message, e); }
    });

  // ── Front-cloud debug overlay ──
  // Draws three rings per layer directly on the main canvas, in SCREEN space,
  // using the exact same scratch→screen scale factor the real blit uses:
  //   RED    = fcR_px, the intended outer disc edge (== scratch clip radius scr)
  //   ORANGE = fadeOuterR mapped to screen — where the erase gradient reaches
  //            alpha=1 (full erase). If the visible artifact ring sits at/near
  //            this exact radius, the erase math isn't fully zeroing the AA rim.
  //   CYAN   = fade-start radius mapped to screen — where the fade begins.
  // If the artifact sits OUTSIDE the red ring, it isn't coming from this scratch
  // canvas at all (rules out this whole code path). If it sits exactly ON the
  // red/orange ring, it's the clip/erase boundary leaking through the final
  // scaled drawImage. Also draws an unscaled 1:1 thumbnail of each scratch
  // canvas (the raw mask BEFORE the scaled blit) in the top-left corner —
  // if the ring is visible in the thumbnail, it's baked into the mask itself;
  // if the thumbnail edge looks clean but the on-screen disc still shows a
  // ring, the artifact is introduced by drawImage's scaling/resampling.
  if(FC_DEBUG && _fcDeferred.length){
    ctx2.save();
    _fcDeferred.forEach(entry => {
      if(entry._dbgFcR_px == null) return;
      const scaleFactor = entry._dbgScr > 0 ? (entry._dbgFcR_px / entry._dbgScr) : 0;
      const rOuter = entry._dbgFcR_px;                                   // red
      const rFadeOuter = entry._dbgFadeOuterR * scaleFactor;             // orange
      const rFadeStart = (entry._dbgFadeOuterR - entry._dbgFadeZoneSc) * scaleFactor; // cyan

      const ring = (radius, color) => {
        ctx2.beginPath();
        ctx2.arc(entry._dbgSpX, entry._dbgSpY, Math.max(0, radius), 0, Math.PI*2);
        ctx2.strokeStyle = color;
        ctx2.lineWidth = 1;
        ctx2.setLineDash([3,3]);
        ctx2.stroke();
      };
      ring(rOuter, 'rgba(255,0,0,0.9)');
      ring(rFadeOuter, 'rgba(255,150,0,0.9)');
      ring(rFadeStart, 'rgba(0,220,255,0.9)');
      ctx2.setLineDash([]);

      ctx2.font = '10px monospace';
      ctx2.fillStyle = 'rgba(255,255,255,0.9)';
      ctx2.fillText(
        `${entry._dbgName} fcR=${rOuter.toFixed(1)} tex=${entry._dbgFcTexSZ} scale=${scaleFactor.toFixed(2)}`,
        entry._dbgSpX + rOuter + 4, entry._dbgSpY
      );
    });

    // Unscaled raw-mask thumbnails, stacked top-left, capped at 160px so large
    // scratch canvases (up to 2048) don't blow past the visible area — this
    // thumbnail blit is itself a SEPARATE scale step from the real one, so
    // don't read the on-screen thumbnail edge as identical to the real edge;
    // it only tells you whether the ring exists in the mask's raw pixels at all.
    const THUMB = 160;
    let ty = 8;
    const seenScratch = new Set();
    _fcDeferred.forEach(entry => {
      if(!entry.scratch || seenScratch.has(entry.scratch)) return;
      seenScratch.add(entry.scratch);
      ctx2.save();
      ctx2.fillStyle = 'rgba(0,0,0,0.6)';
      ctx2.fillRect(8, ty, THUMB, THUMB + 14);
      ctx2.drawImage(entry.scratch, 8, ty, THUMB, THUMB);
      ctx2.strokeStyle = 'rgba(255,255,255,0.6)';
      ctx2.lineWidth = 1;
      ctx2.strokeRect(8, ty, THUMB, THUMB);
      ctx2.font = '10px monospace';
      ctx2.fillStyle = '#fff';
      ctx2.fillText(`${entry._dbgName} mask (${entry._dbgFcTexSZ}px raw)`, 10, ty + THUMB + 11);
      ctx2.restore();
      ty += THUMB + 20;
    });
    ctx2.restore();
  }

  bodyScreenPos = {};
  names.forEach(name => {
    const wp = bodyWorldPos[name] || {x:0, y:0};
    const sp = worldToScreen(wp.x, wp.y);
    bodyScreenPos[name] = sp; // always store for hit-test
  });

  // ── Post-processing: find the relevant body's PP key once ──
  // Prefer system center PP keys; fall back to any body that has keys.
  let _ppBody = null;
  const _cname = Object.keys(bodies).find(n => bodies[n].isCenter);
  if(_cname && bodies[_cname].data?.POST_PROCESSING?.keys?.length) _ppBody = bodies[_cname];
  if(!_ppBody){
    const _fallback = Object.keys(bodies).find(n => bodies[n].data?.POST_PROCESSING?.keys?.length);
    if(_fallback) _ppBody = bodies[_fallback];
  }
  const _ppKey = _ppBody ? getPostProcessKey(_ppBody.data, 0) : null;

  // Star intensity feeds the 'gamelike' background (js/background.js) so its
  // starfield dims/brightens the same way the game's own background stars do
  // (SFS fades stars out based on a body's authored PostProcessing curve —
  // see PostProcessingModule.Key.starIntensity / WorldView.UpdatePostProcessing
  // in the decompiled source). This is intentionally independent of the
  // envFlags.postProc toggle below (that toggle is just the colour-grading
  // overlay) — star visibility is its own concern and should track the real
  // per-body curve regardless of whether colour tinting is enabled. Defaults
  // to 1 (fully visible) when there's no relevant body/curve data.
  window._sfsBgStarIntensity = (_ppKey && typeof _ppKey.starIntensity === 'number') ? _ppKey.starIntensity : 1;

  // ── Post-processing colour-tint overlay — applied after world render, before
  //    editor overlays (SOI circles, physAtmo disk, labels must not be graded) ──
  if(envFlags.postProc){
    if(_ppKey) _applyPostProcessingOverlay(ctx2, vp.width, vp.height, _ppKey);
  }

  // ── SOI pass — drawn on top of everything else ──
  if(envFlags.soi){
    ctx2.save();
    names.forEach(name => {
      const b = bodies[name];
      if(b.isCenter || !b.data.ORBIT_DATA) return;

      const soiR_m = computeSOI_m(name);
      if(!soiR_m || soiR_m <= 0) return;

      const wp  = bodyWorldPos[name] || {x:0, y:0};
      const sp  = worldToScreen(wp.x, wp.y);
      const sc  = getSMAScale();
      const soiR_px = soiR_m * sc * vpZ;  // SOI radius in screen pixels

      // Cull: SOI circle entirely off-screen
      const W2 = vp.width, H2 = vp.height;
      if(sp.x + soiR_px < 0 || sp.x - soiR_px > W2 ||
         sp.y + soiR_px < 0 || sp.y - soiR_px > H2) return;

      // Fade-out when the SOI circle is very small on screen (< 10px = almost invisible)
      // Fade-out also when very far away — use body's own LOD fade value.
      const bodyF   = bodyFadeVal[name] ?? 1;
      const sizeFade = Math.max(0, Math.min(1, (soiR_px - 6) / 10));
      let   alpha    = bodyF * sizeFade;

      // Selected body always gets full SOI alpha
      if(selectedBody === name) alpha = Math.max(alpha, 0.85);

      if(alpha < 0.01) return;

      const isSelected = selectedBody === name;

      // ── Draw SOI circle ──
      // When the SOI is larger than the viewport we are inside it — only a small
      // arc is visible. Draw only that arc with a fixed segment count so cost is
      // O(1) regardless of how large soiR_px grows.
      ctx2.beginPath();
      if(soiR_px > diagPx * 0.5) {
        const toVX = W2 * 0.5 - sp.x;
        const toVY = H2 * 0.5 - sp.y;
        const baseAngle = Math.atan2(toVY, toVX);
        const halfAngle = Math.min(Math.PI, (diagPx * 2.4) / soiR_px);
        const segs = 48;
        const startA = baseAngle - halfAngle;
        const arcStep = (halfAngle * 2) / segs;
        for(let i = 0; i <= segs; i++){
          const a = startA + i * arcStep;
          const px = sp.x + soiR_px * Math.cos(a);
          const py = sp.y + soiR_px * Math.sin(a);
          i === 0 ? ctx2.moveTo(px, py) : ctx2.lineTo(px, py);
        }
        // open arc — no closePath
      } else {
        const sides = Math.max(32, Math.min(96, Math.ceil(soiR_px * 0.5)));
        const step  = (Math.PI * 2) / sides;
        for(let i = 0; i <= sides; i++){
          const a = i * step;
          const px = sp.x + soiR_px * Math.cos(a);
          const py = sp.y + soiR_px * Math.sin(a);
          i === 0 ? ctx2.moveTo(px, py) : ctx2.lineTo(px, py);
        }
        ctx2.closePath();
      }

      if(isSelected){
        ctx2.setLineDash([8, 5]);
        ctx2.strokeStyle = `rgba(192,128,255,${(alpha * 0.9).toFixed(3)})`;
        ctx2.lineWidth = 1.5;
      } else {
        ctx2.setLineDash([4, 6]);
        ctx2.strokeStyle = `rgba(160,100,255,${(alpha * 0.55).toFixed(3)})`;
        ctx2.lineWidth = 1;
      }
      ctx2.stroke();
      ctx2.setLineDash([]);

      // Small label showing SOI radius when body is selected or SOI > 40px
      if((isSelected || soiR_px > 40) && alpha > 0.2){
        const soiKm = soiR_m / 1000;
        const soiLabel = soiKm >= 1e6
          ? (soiKm / 1e6).toFixed(2) + ' Gm'
          : soiKm >= 1e3
          ? (soiKm / 1e3).toFixed(1) + ' Mm'
          : soiKm.toFixed(0) + ' km';
        ctx2.globalAlpha = alpha * 0.75;
        ctx2.font = '8px "JetBrains Mono",monospace';
        ctx2.fillStyle = isSelected ? 'rgba(210,170,255,0.9)' : 'rgba(180,140,255,0.75)';
        ctx2.textAlign = 'center';
        ctx2.fillText('SOI ' + soiLabel, sp.x, sp.y - soiR_px - 4);
        ctx2.globalAlpha = 1;
      }
    });
    ctx2.restore();
  }

  // ── Distance indicators overlay ──
  if(typeof _drawDistanceIndicators === 'function'){
    _drawDistanceIndicators(ctx2, vpZ, vpOffX, vpOffY, vp.width, vp.height);
  }

  // ── Image overlays — drawn on top of everything ──
  if(typeof imgDrawOverlays === 'function'){
    imgDrawOverlays(ctx2, vpZ, vpOffX, vpOffY, vp.width, vp.height);
  }
}

function shadeHex(hex, amt){
  // darken/lighten a hex colour string by amt (negative = darker)
  try {
    let c = hex.trim().replace('#','');
    if(c.length===3) c=c.split('').map(x=>x+x).join('');
    const n = parseInt(c,16);
    const r = Math.max(0,Math.min(255,((n>>16)&0xff)+amt));
    const g = Math.max(0,Math.min(255,((n>>8)&0xff)+amt));
    const b = Math.max(0,Math.min(255,(n&0xff)+amt));
    return `rgb(${r},${g},${b})`;
  } catch(e){ return hex; }
}



// ══════════════════════════════════════════════════════════════════════════════
//  SFS TERRAIN ENGINE — HeightMap evaluator + TerrainSampler JS port
//  Mirrors: HeightMap.cs · TerrainSampler.cs · TerrainModule.cs
// ══════════════════════════════════════════════════════════════════════════════

// ── HeightMap cache — keyed by asset name ────────────────────────────────────
const _hmCache = {};

// ── HeightMap.EvaluateDoubleOut — mirrors game C# exactly ────────────────────
// Game: a *= (points.Length-1); num = (int)a % (points.Length-1); frac = a % 1
// The caller passes a as angle_rad * (radius_m / width), which can be a very
// large number (e.g. 20000+). Operating directly on such values loses fractional
// precision: at a=80,000,000 a float64 has ~1 ULP of ~0.016, so
// (a - Math.floor(a)) snaps to 0 or 1 in chunks -> hard steps -> rectangular blocks.
// Fix: wrap a to [0,1) at low magnitude first, then scale by N.
function _hmEval(points, a) {
  const N = points.length - 1; // index range 0..N-1; points[N] is wrap sentinel
  if (N <= 0) return 0;
  // Wrap to [0,1) before scaling -- preserves fractional precision regardless of
  // how large the tiling multiplier (radius_m/width) is.
  a = ((a % 1) + 1) % 1;
  a *= N;
  const lo = Math.trunc(a) | 0;             // integer index, always in [0, N-1]
  const t  = a - lo;                        // fractional part, precise since a < N+1
  return points[lo] * (1 - t) + points[lo + 1] * t;
}

// ── Parse JSON-text heightmap → Float64Array ──────────────────────────────────
function _parseHmText(content, filename) {
  const label = filename ? `"${filename}"` : '(unknown)';
  if (!content || !content.trim()) {
    console.warn(`[SFS|HM] ${label}: empty content`);
    return new Float64Array([0, 1]);
  }

  // ── Format 1: Unity JsonUtility  { "points": [0.1, 0.2, ...] }
  try {
    const obj = JSON.parse(content);
    if (Array.isArray(obj.points) && obj.points.length > 1) {
      console.log(`[SFS|HM] ${label}: parsed JSON {points:[]} → ${obj.points.length} pts, range [${Math.min(...obj.points).toFixed(4)}, ${Math.max(...obj.points).toFixed(4)}]`);
      return new Float64Array(obj.points);
    }
    if (Array.isArray(obj) && obj.length > 1) {
      console.log(`[SFS|HM] ${label}: parsed JSON array → ${obj.length} pts`);
      return new Float64Array(obj);
    }
    console.warn(`[SFS|HM] ${label}: JSON parsed OK but no usable array (keys: ${Object.keys(obj).join(',')})`);
  } catch(e) {
    console.log(`[SFS|HM] ${label}: not JSON (${e.message.slice(0,40)}), trying plain float list…`);
  }

  // ── Format 2: plain whitespace/comma-separated floats (some export tools)
  const nums = content.trim().split(/[\s,;]+/).map(Number).filter(v => !isNaN(v));
  if (nums.length > 1) {
    console.log(`[SFS|HM] ${label}: parsed plain floats → ${nums.length} pts, range [${Math.min(...nums).toFixed(4)}, ${Math.max(...nums).toFixed(4)}]`);
    return new Float64Array(nums);
  }

  console.error(`[SFS|HM] ${label}: FAILED to parse — content starts with: ${JSON.stringify(content.slice(0,80))}`);
  return new Float64Array([0, 1]);
}

// ── Parse PNG heightmap → Promise<Float64Array> ───────────────────────────────
// SFS PNG heightmaps are silhouette images: terrain fills from the bottom up.
// Encoding: black = sky/empty, non-black = terrain body.
// Per column, scan TOP→BOTTOM to find the first non-black pixel.
// That row y gives height fraction = 1 - (y / H)  (0=flat, 1=full radius).
// Files are RGB with no alpha (sometimes JPEG data inside a .png extension).
// A luminance threshold of 8 rejects compression noise from near-black sky.
// Game convention: column x → points[W - x - 1] (horizontally mirrored).
function _parseHmPng(dataUrl) {
  return new Promise(resolve => {
    const img = new Image();
    img.onload = () => {
      const W = img.width, H = img.height;
      const oc = document.createElement('canvas');
      oc.width = W; oc.height = H;
      oc.getContext('2d').drawImage(img, 0, 0);
      const px = oc.getContext('2d').getImageData(0, 0, W, H).data;

      // Detect whether alpha channel varies (true RGBA PNG with transparency mask).
      // JPEG-inside-PNG and plain RGB PNGs will have alpha=255 everywhere.
      let hasAlphaVariation = false;
      for (let i = 3; i < px.length; i += 4) {
        if (px[i] < 255) { hasAlphaVariation = true; break; }
      }

      // Game (HeightMap.cs): scan bottom→top (Unity Y-up, j=0 is bottom row).
      // First pixel where alpha < 1.0 = terrain top edge.
      // height = (j + alpha_frac) / H   where j=0 means bottom of image.
      // Canvas pixel data is Y-down, so bottom row = index (H-1-j).
      // Only alpha is used — RGB content is irrelevant.
      const pts = new Float64Array(W);
      for (let x = 0; x < W; x++) {
        let frac = 1.0; // default: full height (all pixels opaque = solid column)
        for (let j = 0; j < H; j++) {
          // j=0 → bottom of image → canvas row (H-1)
          const canvasY = H - 1 - j;
          const a = px[(canvasY * W + x) * 4 + 3] / 255;
          if (a < 1.0) {
            frac = (j + a) / H;
            break;
          }
        }
        pts[W - x - 1] = frac;
      }
      if (!hasAlphaVariation) {
        console.warn(`[SFS|HM] PNG has no alpha variation — all columns will be height 1.0. ` +
          `SFS heightmap PNGs must have an alpha channel (RGBA). JPEG files are not supported.`);
      }

      resolve(pts);
    };
    img.onerror = () => resolve(new Float64Array([0, 1]));
    img.src = dataUrl;
  });
}

// ── Resolve heightmap by name → Float64Array (sync) or null (loading) ────────
function _getHeightMap(hmName) {
  if (!hmName || hmName === 'null' || hmName === 'None') return new Float64Array([0, 1]);
  if (_hmCache[hmName] instanceof Float64Array) return _hmCache[hmName];
  if (_hmCache[hmName]) return null; // Promise in-flight

  // Search assets — match by full name OR basename (formula uses name without extension,
  // but custom uploaded files have e.name = "Earth.txt")
  const assetList = (typeof assets !== 'undefined') ? assets.heightmaps : [];
  const entry = assetList.find(e =>
    e.name === hmName ||
    e.name.replace(/\.[^.]+$/, '') === hmName
  );

  if (!entry) {
    // Do NOT permanently cache flat here — assets load async and may arrive later.
    // Return flat without caching so the next render retries the lookup.
    return new Float64Array([0, 1]);
  }

  if (entry.content) {
    // .txt heightmap — parse JSON immediately and cache by lookup name
    const parsed = _parseHmText(entry.content, entry.name);
    _hmCache[hmName] = parsed;
    return _hmCache[hmName];
  }

  if (entry.url) {
    _hmCache[hmName] = _parseHmPng(entry.url).then(pts => {
      _hmCache[hmName] = pts;
      if (typeof invalidateTerrainCache === 'function') invalidateTerrainCache('*');
      if (typeof drawViewport === 'function') drawViewport();
    });
    return null;
  }

  return new Float64Array([0, 1]);
}

// ── TerrainSampler JS port ────────────────────────────────────────────────────
// Mirrors Compiler.Compile() + Executor.Calculate().
// Returns Float64Array of heights (metres), or null if an asset is still loading.
//
// KEY DIFFERENCES FROM GAME:
//   - surfaceArea = radius_m  (game passes planet.data.basics.radius)
//   - Strings in formula lines may be quoted ("name") OR bare identifiers (name)
//   - OUTPUT is the required output variable name (game checks userVariables["OUTPUT"])
//
// Parsed-formula cache — the terrain formula's TEXT rarely changes, but this
// function used to be re-parsed character-by-character on every single
// evaluation (i.e. every time N changed during a smooth zoom). Splitting
// parse (cached, once per formula text) from execute (still runs per-call,
// since it depends on the current angle/N/radius) removes that redundant
// string-parsing work from the hot path.
const _formulaOpsCache = {};
function _compileTerrainFormula(formulaLines) {
  const fKey = formulaLines.join('§');
  const cached = _formulaOpsCache[fKey];
  if (cached) return cached;

  const ops = [];

  // ── Parser — mirrors game's character-by-character approach ─────────────────
  // Handles: VARNAME = FUNC(args)  and  FUNC(args)
  // Args: quoted strings "foo", bare identifiers bar, numbers 123.4
  for (const rawLine of formulaLines) {
    const line = rawLine.trim();
    if (!line || line.startsWith('//')) continue;

    // State machine parser (mirrors game exactly)
    let inString = false, inIdent = false, inNumber = false, inFunc = false;
    let strBuf = null, identBuf = null, numBuf = null;
    let fname = '', varName = null, isAssign = false;
    const args = [];

    for (let ci = 0; ci < line.length; ci++) {
      const c = line[ci];

      if (!inFunc) {
        // Outside function call — parsing "VARNAME =" or "FUNCNAME"
        if (c === '(') {
          // Open function
          if (inIdent) { fname = identBuf; identBuf = null; inIdent = false; }
          inFunc = true;
        } else if (c === '=' && inIdent) {
          // Assignment: varName = ...
          varName = identBuf.trim(); identBuf = null; inIdent = false; isAssign = true;
        } else if (c === ' ' || c === '\t') {
          // whitespace — if we were accumulating an ident and no = yet, keep it
          // (game trims names)
        } else if (char_isLetter(c)) {
          if (!inIdent) { inIdent = true; identBuf = ''; }
          identBuf += c;
        }
        continue;
      }

      // Inside function args
      if (inString) {
        if (c === '"') { inString = false; args.push(strBuf); strBuf = null; }
        else strBuf += c;
      } else if (inIdent) {
        if (c === ',' || c === ')') {
          args.push(identBuf.trim()); identBuf = null; inIdent = false;
          if (c === ')') { inFunc = false; }
        } else {
          identBuf += c;
        }
      } else if (inNumber) {
        if (c === ',' || c === ')') {
          args.push(parseFloat(numBuf)); numBuf = null; inNumber = false;
          if (c === ')') { inFunc = false; }
        } else {
          numBuf += c;
        }
      } else {
        if (c === '"') { inString = true; strBuf = ''; }
        else if (c === ')') { inFunc = false; }
        else if (c === ',') { /* separator between args */ }
        else if (c === ' ' || c === '\t') { /* skip whitespace */ }
        else if (c === '-' || char_isDigit(c)) { inNumber = true; numBuf = c; }
        else if (char_isLetter(c)) { inIdent = true; identBuf = c; }
      }
    }

    ops.push({ fname, varName, isAssign, args });
  }

  const cacheKeys = Object.keys(_formulaOpsCache);
  if (cacheKeys.length >= 100) delete _formulaOpsCache[cacheKeys[0]];
  _formulaOpsCache[fKey] = ops;
  return ops;
}

function _evalTerrainFormula(formulaLines, angles_rad, radius_m) {
  if (!formulaLines || formulaLines.length === 0) return null;

  const N = angles_rad.length;
  const userVars = {};
  // current output target — mirrors sampler.output pointer
  let outputTarget = new Float64Array(N); // default flat if no OUTPUT assigned

  function getVar(name) {
    if (!userVars[name]) userVars[name] = new Float64Array(N);
    return userVars[name];
  }

  const ops = _compileTerrainFormula(formulaLines);

  for (const op of ops) {
    const { fname, varName, isAssign, args } = op;

    // Execute the parsed function call
    const target = isAssign ? getVar(varName) : outputTarget;
    if (isAssign) {
      outputTarget = target;
    }

    switch (fname) {
      case 'AddHeightMap': {
        const hmName  = args[0];
        const width   = typeof args[1] === 'number' ? args[1] : parseFloat(args[1]);
        const hmHeight= typeof args[2] === 'number' ? args[2] : parseFloat(args[2]);
        const curveName = (args[3] && args[3] !== 'null' && args[3] !== 'None') ? args[3] : null;
        const multName  = args[4] ? args[4] : null;

        const pts = _getHeightMap(hmName);
        if (!pts) return null; // still loading

        const curvePts = curveName ? _getHeightMap(curveName) : null;
        if (curveName && !curvePts) return null;

        const multArr = multName ? getVar(multName) : null;
        // Game: num = surfaceArea / width  where surfaceArea = radius_m
        const num = radius_m / width;

        for (let i = 0; i < N; i++) {
          let v = _hmEval(pts, angles_rad[i] * num);
          if (curvePts) v = _hmEval(curvePts, Math.max(0, Math.min(1, v)));
          if (multArr)  v *= multArr[i];
          target[i] += v * hmHeight;
        }
        break;
      }
      case 'ApplyCurve': {
        const cPts = _getHeightMap(args[0]);
        if (!cPts) return null;
        for (let i = 0; i < N; i++) {
          target[i] = _hmEval(cPts, Math.max(0, Math.min(1, target[i])));
        }
        break;
      }
      case 'Add': {
        const v = typeof args[0] === 'number' ? args[0] : parseFloat(args[0]);
        for (let i = 0; i < N; i++) target[i] += v;
        break;
      }
      case 'Multiply': {
        const v = typeof args[0] === 'number' ? args[0] : parseFloat(args[0]);
        for (let i = 0; i < N; i++) target[i] *= v;
        break;
      }
      case 'ClampMinMax': {
        const mn = typeof args[0] === 'number' ? args[0] : parseFloat(args[0]);
        const mx = typeof args[1] === 'number' ? args[1] : parseFloat(args[1]);
        for (let i = 0; i < N; i++) target[i] = Math.max(mn, Math.min(mx, target[i]));
        break;
      }
      default:
        if (fname) console.warn('[SFS|TERRAIN] Unknown function:', fname);
    }
  }

  // Game returns userVariables["OUTPUT"] — if not set, returns zeros
  return userVars['OUTPUT'] || new Float64Array(N);
}

// ── Seeded RNG matching .NET System.Random (subtractive generator) ────────────
// .NET uses a 55-element subtractive table seeded from the integer seed.
// This matches DynamicTerrain.GenerateRocks: new System.Random((int)(from*100000))
function _seededRng(seed) {
  seed = seed | 0;
  // .NET System.Random init
  const MBIG = 2147483647;
  const table = new Int32Array(56);
  let mj = 161803398 - Math.abs(seed);
  table[55] = mj;
  let mk = 1;
  for (let i = 1; i < 55; i++) {
    const ii = (21 * i) % 55;
    table[ii] = mk;
    mk = mj - mk;
    if (mk < 0) mk += MBIG;
    mj = table[ii];
  }
  for (let k = 1; k < 5; k++) {
    for (let i = 1; i < 56; i++) {
      table[i] -= table[1 + (i + 30) % 55];
      if (table[i] < 0) table[i] += MBIG;
    }
  }
  let inext = 0, inextp = 21;
  return function() {
    if (++inext  >= 56) inext  = 1;
    if (++inextp >= 56) inextp = 1;
    let retVal = table[inext] - table[inextp];
    if (retVal < 0) retVal += MBIG;
    table[inext] = retVal;
    return retVal / MBIG;
  };
}

// ── Evaluate textureFormula → per-vertex blend [0..1] across N samples ────────
// Same evaluator as terrain formula but for the texture sampler.
// Returns Float64Array[N] with values in [0..1], or null if still loading.
function _evalTextureFormula(bodyName, b, radius_m, N) {
  const TD = b.data.TERRAIN_DATA;
  if (!TD) return null;
  const formula = TD.textureFormula;
  if (!formula || formula.length === 0) return new Float64Array(N); // all zeros → full A
  // Reuse terrain sample cache with a 'tex|' prefix key
  const fHash = formula.join('§');
  const key = `tex|${bodyName}|${radius_m.toFixed(0)}|${N}|${fHash}`;
  if (_terrainSampleCache[key]) return _terrainSampleCache[key].heights;
  const angles = new Float64Array(N);
  for (let i = 0; i < N; i++) angles[i] = (i / N) * Math.PI * 2;
  const result = _evalTerrainFormula(formula, angles, radius_m);
  if (!result) return null;
  // Clamp to [0,1]
  const clamped = new Float64Array(N);
  for (let i = 0; i < N; i++) clamped[i] = Math.max(0, Math.min(1, result[i]));
  _terrainSampleCache[key] = { heights: clamped, angles };
  return clamped;
}

function char_isLetter(c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c === '_'; }
function char_isDigit(c)  { return c >= '0' && c <= '9'; }

// ── Water depression (mirrors GetTerrainSamples water loop) ──────────────────
// Game: num = GetWaterColor(CosSin(angle - texRotRad)) * 2f
//       depression = num * oceanDepth + 50
// GetWaterColor samples the ocean mask texture: black(0)=water, white(1)=land
// So waterMask = maskR (red channel, 0=ocean, 1=land)
// num = (1 - maskR) * 2  → ranges 0 (land) to 2 (deep ocean)
// cutout mirrors game's GetWaterColor UV formula:
//   vector = normalPosition * (cutout * 0.5) + (0.5, 0.5)
// where normalPosition is a unit vector (cos,sin).
// The mask canvas stores the texture occupying the full [0,1] UV space,
// so we must scale the unit circle by (cutout * 0.5) before mapping to pixels.
function _applyWaterDepression(heights, angles_rad, maskPixels, maskSZ, oceanDepth, texRotRad, cutout, depressionOut) {
  if (!maskPixels) return;
  const SZ = maskSZ;
  // cutout scales how far from centre the planet edge sits in UV space.
  // cutout=1 → edge at UV 0 or 1 (full texture). cutout<1 → edge sits inside.
  // Game: vector = normalPosition * (cutout * 0.5) + 0.5
  // Negative cutout flips both axes (same as the main texture). Use signed value.
  const uvScale = cutout * 0.5; // signed — game passes cutout directly (can be negative)
  const SZ2 = SZ;
  for (let i = 0; i < angles_rad.length; i++) {
    const ang = angles_rad[i] - texRotRad;
    // Game UV: vec = normalPos * (cutout*0.5) + 0.5  — Y-up in game, flip for canvas
    const uvX =  Math.cos(ang) * uvScale + 0.5;
    const uvY = -Math.sin(ang) * uvScale + 0.5;  // negate sin: game +Y is up, canvas +Y is down
    // Convert UV [0,1] → pixel [0,SZ]
    const fx = uvX * SZ;
    const fy = uvY * SZ;
    const x0 = Math.floor(fx), y0 = Math.floor(fy);
    const x1 = x0 + 1, y1 = y0 + 1;
    const tx = fx - x0, ty = fy - y0;
    const clamp = (v, lo, hi) => v < lo ? lo : v > hi ? hi : v;
    const sample = (px, py) => {
      const cx2 = clamp(px, 0, SZ-1), cy2 = clamp(py, 0, SZ-1);
      return maskPixels[(cy2 * SZ + cx2) * 4] / 255;
    };
    const r00 = sample(x0, y0), r10 = sample(x1, y0);
    const r01 = sample(x0, y1), r11 = sample(x1, y1);
    const pixelR = r00*(1-tx)*(1-ty) + r10*tx*(1-ty) + r01*(1-tx)*ty + r11*tx*ty;
    // Game: GetWaterColor = 1 - r - 0.5 = 0.5 - r
    //       num = GetWaterColor * 2  (ranges -1 land → +1 ocean)
    //       depression = num * oceanDepth + 50
    const num = (0.5 - pixelR) * 2 * oceanDepth + 50;
    if (num > 0) {
      heights[i] -= num;
      if (depressionOut) depressionOut[i] = num;
    } else if (depressionOut) {
      depressionOut[i] = 0;
    }
  }
}

// ── FlatZones (mirrors GetTerrainSamples flatzone loop exactly) ───────────────
// Game code uses raw angles_Rad[k] with no wrapping — it does a bounds check
// (num3 > endAngle, num4 < startAngle) to skip irrelevant zones, then applies
// InverseLerp directly on the raw angle values.  We replicate that exactly.
// The editor's angles array runs [0, 2π), and fz.angle is stored in that same
// space, so no wrapping is needed or correct here.
function _applyFlatZones(heights, angles_rad, flatZones, radius_m, depressions) {
  if (!flatZones || !flatZones.length) return;
  for (const fz of flatZones) {
    // Game: num2 = (width + transition) / radius / 2
    const halfFull  = (fz.width + fz.transition) / radius_m / 2;  // outer half-angle (rad)
    const halfInner = fz.width / radius_m / 2;                     // inner half-angle (rad)
    const angleCenter = fz.angle; // radians — stored directly from JSON
    const zoneMin = angleCenter - halfFull;   // num3
    const zoneMax = angleCenter + halfFull;   // num4
    const innerMin = angleCenter - halfInner; // b
    const innerMax = angleCenter + halfInner; // b2

    // Game skips the whole zone if it is entirely outside the chunk's angle range.
    // In the editor we always process all angles, so skip the start/end guard.
    for (let i = 0; i < angles_rad.length; i++) {
      const a = angles_rad[i]; // raw angle, no wrapping
      // Game: value3 = Min(InverseLerp(num3, b, a), InverseLerp(num4, b2, a))
      // Left ramp:  0 at outer edge (zoneMin), 1 at inner edge (innerMin)
      // Right ramp: 0 at outer edge (zoneMax), 1 at inner edge (innerMax)
      const tLeft  = halfFull === halfInner ? 0 : (a - zoneMin)  / (innerMin - zoneMin);
      const tRight = halfFull === halfInner ? 0 : (a - zoneMax)  / (innerMax - zoneMax);
      const tc = Math.max(0, Math.min(1, Math.min(tLeft, tRight)));
      if (tc > 0) {
        heights[i] = heights[i] * (1 - tc) + fz.height * tc;
        // Proportionally remove water tint wherever a flatzone raises terrain
        // that water depression had lowered — matches the game's own order
        // (flatzones applied AFTER water depression, so they can fully or
        // partially override it). A fully-flattened point (tc=1) should show
        // no sand/floor tint at all, since it's no longer underwater.
        if (depressions) depressions[i] *= (1 - tc);
      }
    }
  }
}

// ── Visible arc computation ───────────────────────────────────────────────────
// Returns the angular range [arcStart, arcEnd] of the planet circumference that
// is actually visible within the viewport rectangle [0,W]×[0,H].
// When the entire circumference is visible (planet fits on screen) returns
// { fullCircle: true }.  The arc is expressed in the canvas coordinate system
// (angles increase clockwise, angle 0 = right) and arcEnd >= arcStart always.
// If arc spans > 355° we also set fullCircle=true to avoid rounding edge cases.
// Dispatcher — picks between the two visible-arc algorithms based on a
// dev/debug setting (Settings > Graphics > Developer Diagnostics), so both
// can be A/B tested live without touching call sites. Defaults to the
// original edge-intersection method ('edge') until the binary-search method
// ('binary') is confirmed to fix the close-zoom silhouette bug without
// introducing regressions of its own.
function _computeVisibleArc(sp, physR_px, vpW, vpH) {
  const method = (typeof window !== 'undefined' && window.dbgArcCullMethod) || 'edge';
  if (method === 'binary') {
    const result = _computeVisibleArcBinarySearch(sp, physR_px, vpW, vpH);
    if (result) return result;
    // Binary search couldn't find a confirmed on-screen seed angle (rare —
    // e.g. the circle only grazes a screen corner) — fall back to the
    // proven edge-intersection method rather than guess.
  }
  return _computeVisibleArcEdgeIntersect(sp, physR_px, vpW, vpH);
}

// ── NEW: binary-search-based visible-arc computation ───────────────────────
// The edge-intersection method below computes disc = r^2 - d^2 where r can
// be in the millions (physR_px at rover-scale close zoom) — subtracting two
// very large, nearly-equal floats is a textbook catastrophic-cancellation
// setup, and independently, near-tangent/grazing viewing angles (looking
// toward the horizon on a huge body) produce candidate angles that cluster
// within a fraction of a degree of each other, making the min/max selection
// sensitive to tiny numerical differences. Both effects are plausible
// contributors to the close-zoom silhouette bug that survived three rounds
// of fixes to the edge-intersection method's margin/quantization.
//
// This method never computes anything at physR_px^2 scale — every check
// inside onScreenAtAngle() works with screen-scale coordinates only (vpW,
// vpH, sp.x/y, which are screen positions, not radius-scale numbers), so it
// sidesteps both issues by construction rather than by patching symptoms.
//
// Approach: find a confirmed on-screen seed angle (checking the direction
// toward the viewport's center and its 4 corners), then binary-search
// outward from that seed in both directions to find exactly where the
// circle's silhouette point crosses off-screen. ~80 cos/sin evaluations
// total per call — benchmarked at under 1 microsecond, negligible next to
// the terrain sampling/rendering work this result feeds into.
//
// Returns null if no seed angle can be confirmed on-screen (the circle may
// only graze a corner in a way none of the 5 seed directions catch) — the
// dispatcher above falls back to the edge-intersection method in that case.
function _computeVisibleArcBinarySearch(sp, physR_px, vpW, vpH) {
  const onScreenAtAngle = (a) => {
    const px = sp.x + Math.cos(a) * physR_px;
    const py = sp.y - Math.sin(a) * physR_px;
    return px >= 0 && px <= vpW && py >= 0 && py <= vpH;
  };

  const seedCandidates = [
    [vpW / 2, vpH / 2], // viewport center — usual case
    [0, 0], [vpW, 0], [0, vpH], [vpW, vpH], // corners — covers off-center/grazing cases
  ];
  let seedAngle = null;
  for (const [cx, cy] of seedCandidates) {
    const a = Math.atan2(-(cy - sp.y), cx - sp.x);
    if (onScreenAtAngle(a)) { seedAngle = a; break; }
  }
  if (seedAngle == null) return null;

  const BISECT_ITERS = 40; // more than enough for sub-arcsecond precision
  let loP = 0, hiP = Math.PI;
  for (let i = 0; i < BISECT_ITERS; i++) {
    const mid = (loP + hiP) / 2;
    if (onScreenAtAngle(seedAngle + mid)) loP = mid; else hiP = mid;
  }
  let loN = 0, hiN = Math.PI;
  for (let i = 0; i < BISECT_ITERS; i++) {
    const mid = (loN + hiN) / 2;
    if (onScreenAtAngle(seedAngle - mid)) loN = mid; else hiN = mid;
  }

  const TWO_PI = Math.PI * 2;
  const arcSpan = loN + loP;
  if (arcSpan >= TWO_PI * (355 / 360)) {
    return { fullCircle: true, arcStart: 0, arcEnd: TWO_PI };
  }

  // Same proportional margin as the edge-intersection method, for parity.
  const ANGLE_MARGIN = Math.min(0.05, Math.max(0.002, arcSpan * 0.08));
  return {
    fullCircle: false,
    arcStart: seedAngle - loN - ANGLE_MARGIN,
    arcEnd:   seedAngle + loP + ANGLE_MARGIN,
  };
}

// ── OLD: edge-intersection-based visible-arc computation (untouched, kept
// as the default and as the binary-search method's fallback) ──────────────
function _computeVisibleArcEdgeIntersect(sp, physR_px, vpW, vpH) {
  // If the planet is small enough to fit fully on screen → full circle
  if (sp.x - physR_px >= 0 && sp.x + physR_px <= vpW &&
      sp.y - physR_px >= 0 && sp.y + physR_px <= vpH) {
    return { fullCircle: true, arcStart: 0, arcEnd: Math.PI * 2 };
  }

  // If the entire viewport is inside the planet disc, the disc's silhouette
  // edge is entirely OFF-screen in every direction — there is no boundary
  // crossing to find below, so the generic edge-intersection logic falls
  // through to its own "visible.length < 2" fallback and returns fullCircle.
  // That was the actual bug: this is the deepest-zoom case (camera essentially
  // on the surface, planet fills the whole canvas), and it was silently
  // building and filling the ENTIRE circumference — tens of thousands of
  // vertices for a large planet — every time the cache rebuilt, instead of
  // culling to just the small angular patch actually on screen. This was
  // the dominant cost of "still lags after arc culling", since it's exactly
  // the zoom level where culling matters most.
  //
  // Fix: when fully inside the disc, find the angular range (as seen from
  // the disc centre, sp) that covers the visible canvas rectangle's corners.
  // That's the actual visible slice of the sphere's near side.
  const corners = [[0,0],[vpW,0],[0,vpH],[vpW,vpH]];
  const r2 = physR_px * physR_px;
  if (corners.every(([cx,cy]) => (cx-sp.x)**2 + (cy-sp.y)**2 <= r2)) {
    const TWO_PI = Math.PI * 2;
    const cornerAngles = corners.map(([cx, cy]) =>
      ((Math.atan2(-(cy - sp.y), cx - sp.x) % TWO_PI) + TWO_PI) % TWO_PI
    );
    const sorted = [...cornerAngles].sort((a, b) => a - b);
    // Smallest arc that contains all 4 corner angles — same "largest gap is
    // the hidden side" logic used below for the boundary-crossing case.
    let maxGap = 0, gapAfter = 0;
    for (let i = 0; i < sorted.length; i++) {
      const next = sorted[(i + 1) % sorted.length];
      const gap = i + 1 < sorted.length ? next - sorted[i] : sorted[0] + TWO_PI - sorted[i];
      if (gap > maxGap) { maxGap = gap; gapAfter = i; }
    }
    const arcStart = sorted[(gapAfter + 1) % sorted.length];
    const arcEndRaw = sorted[gapAfter];
    const arcEnd = arcEndRaw < arcStart ? arcEndRaw + TWO_PI : arcEndRaw;
    const arcSpan = arcEnd - arcStart;

    // If the 4 corners still span nearly the full circle (camera very close
    // to the surface, wide FOV relative to radius), culling wouldn't help
    // much anyway — fall back to full circle rather than risk a degenerate
    // near-360° "slice".
    if (arcSpan >= TWO_PI * (355 / 360)) {
      return { fullCircle: true, arcStart: 0, arcEnd: TWO_PI };
    }

    // Margin used to be a FIXED 0.05 rad (~2.86°) regardless of arc size.
    // At rover-scale close zoom the true visible arc can be well under 1°
    // (a single crater filling the screen) — a fixed ~2.86° margin on each
    // side there doesn't just pad the edges, it inflates a e.g. 0.5° arc
    // into ~6.2°, over 12x wider than what's actually visible. The extra
    // vertex BUDGET that unlocks (since _vsMaxN scales with arc span) is
    // real, but it's spread across a mostly off-screen range — only a small,
    // shifting fraction of those vertices ever land in the true visible
    // window, and which fraction shifts as physR_px/arcSpan change slightly
    // between frames. That reads exactly as "shape changes as you keep
    // zooming in" even though nothing about the underlying terrain data
    // changed — this was the actual cause of the close-zoom crater/hill
    // flattening-and-shifting bug (confirmed by A/B testing arc culling
    // on/off). Scale the margin to a fraction of the arc's own span instead,
    // with a small fixed floor/ceiling so it stays sane at both extremes.
    const ANGLE_MARGIN = Math.min(0.05, Math.max(0.002, arcSpan * 0.08));
    return {
      fullCircle: false,
      arcStart: arcStart - ANGLE_MARGIN,
      arcEnd:   arcEnd   + ANGLE_MARGIN,
    };
  }

  // Collect candidate angles: where the planet disc edge intersects each
  // viewport edge (top, bottom, left, right).  Also include planet-centre
  // angles toward each screen corner so we never miss a partially visible arc.
  const angles = [];

  // Planet-centre → corner angles (always include even if outside disc)
  for (const [cx, cy] of corners) {
    angles.push(Math.atan2(-(cy - sp.y), cx - sp.x)); // canvas Y-down → negate for trig
  }

  // Intersections of planet disc with horizontal lines y = 0 and y = vpH
  for (const ey of [0, vpH]) {
    const dy = -(ey - sp.y); // negate for canvas Y-down
    const disc = r2 - dy * dy;
    if (disc >= 0) {
      const dx = Math.sqrt(disc);
      angles.push(Math.atan2(dy,  dx));
      angles.push(Math.atan2(dy, -dx));
    }
  }
  // Intersections with vertical lines x = 0 and x = vpW
  for (const ex of [0, vpW]) {
    const dx = ex - sp.x;
    const disc = r2 - dx * dx;
    if (disc >= 0) {
      const dy = Math.sqrt(disc);
      angles.push(Math.atan2( dy, dx));
      angles.push(Math.atan2(-dy, dx));
    }
  }

  // Normalise angles to [0, 2π)
  const TWO_PI = Math.PI * 2;
  const norm = angles.map(a => ((a % TWO_PI) + TWO_PI) % TWO_PI);

  // Filter to angles where that point on the disc is actually inside the viewport
  const MARGIN = 2; // 2px tolerance
  const visible = norm.filter(a => {
    const px = sp.x + Math.cos(a) * physR_px;
    const py = sp.y - Math.sin(a) * physR_px;
    return px >= -MARGIN && px <= vpW + MARGIN && py >= -MARGIN && py <= vpH + MARGIN;
  });

  if (visible.length < 2) {
    // Disc intersects screen but we couldn't find endpoints → full circle fallback
    return { fullCircle: true, arcStart: 0, arcEnd: TWO_PI };
  }

  // Find the min and max angle of the visible set, but we need the smallest arc
  // that contains all visible angles — handle wrap-around by choosing the
  // complement arc if it's smaller.
  const sorted = [...visible].sort((a, b) => a - b);
  // Largest gap between consecutive angles (mod circle) tells us the hidden arc
  let maxGap = 0, gapAfter = 0;
  for (let i = 0; i < sorted.length; i++) {
    const next = sorted[(i + 1) % sorted.length];
    const gap = i + 1 < sorted.length ? next - sorted[i] : sorted[0] + TWO_PI - sorted[i];
    if (gap > maxGap) { maxGap = gap; gapAfter = i; }
  }
  // The visible arc is everything EXCEPT the largest gap
  const arcStart = sorted[(gapAfter + 1) % sorted.length];
  const arcEndRaw = sorted[gapAfter];
  const arcEnd   = arcEndRaw < arcStart ? arcEndRaw + TWO_PI : arcEndRaw;
  const arcSpan  = arcEnd - arcStart;

  if (arcSpan >= TWO_PI * (355 / 360)) {
    return { fullCircle: true, arcStart: 0, arcEnd: TWO_PI };
  }


  // Margin used to be a fixed ~3° (0.05 rad) regardless of arc size — same
  // issue as the fully-inside-disc branch above: at close zoom this can
  // inflate a small arc many times over, diluting effective on-screen
  // vertex density right when it matters most. Scale to a fraction of the
  // arc's own span instead (see full explanation above).
  const ANGLE_MARGIN = Math.min(0.05, Math.max(0.002, arcSpan * 0.08));
  return {
    fullCircle: false,
    arcStart: arcStart - ANGLE_MARGIN,
    arcEnd:   arcEnd   + ANGLE_MARGIN,
  };
}

// ── Terrain sample cache ──────────────────────────────────────────────────────
const _terrainSampleCache = {};

// ── Max terrain height (mirrors Planet.cs: maxTerrainHeight = TerrainModule.
//    GetMaxTerrainHeight(planet) + 200) ─────────────────────────────────────
const _maxTerrainHeightCache = {};
function _getMaxTerrainHeight(bodyName, b, radius_m) {
  const TD = b.data.TERRAIN_DATA;
  if (!TD) return 0;
  const tfd = TD.terrainFormulaDifficulties;
  const formula = (tfd && (tfd[viewDiffKey] || tfd[viewDifficulty] || tfd['Normal'] || tfd['normal'])) || TD.terrainFormula;
  if (!formula || !formula.length) return 0;

  const fHash = formula.join('§');
  const key = `${bodyName}|${radius_m.toFixed(0)}|${viewDiffKey}|${fHash}`;
  if (_maxTerrainHeightCache[key] != null) return _maxTerrainHeightCache[key];

  const N = 1001;
  const angles = new Float64Array(N);
  for (let i = 0; i < N; i++) angles[i] = (Math.PI / 500) * i;
  const heights = _evalTerrainFormula(formula, angles, radius_m);
  if (!heights) return 0;

  const depressions = new Float64Array(N);
  _applyWaterDepressionIfNeeded(b, TD, heights, angles, depressions);
  const fzd = TD.flatZonesDifficulties;
  const flatZones = (fzd && (fzd[viewDiffKey] || fzd['Normal'])) || TD.flatZones || [];
  _applyFlatZones(heights, angles, flatZones, radius_m, depressions);

  let maxH = 0;
  for (let i = 0; i < N; i++) if (heights[i] > maxH) maxH = heights[i];
  const result = maxH + 200;

  const keys = Object.keys(_maxTerrainHeightCache);
  if (keys.length >= 100) delete _maxTerrainHeightCache[keys[0]];
  _maxTerrainHeightCache[key] = result;
  return result;
}

// Terrain silhouette path cache — paths are built in UNIT-RADIUS local space
// (radius 1 = sea level, centred at origin), so the cached Path2D is valid at
// ANY zoom level or pan position: only bodyName/N/radius_m/visible-arc affect
// the shape. Draw time applies translate(sp)+scale(physR_px) to place it
// (see _applyTerrainClip / _getUnitTerrainPath). This is what makes smooth
// zoom/pan cheap — geometry work only happens when the LOD-driven vertex
// count N actually changes, not on every pixel of camera movement.
const _terrainClipCache = {};

function _getUnitTerrainPath(bodyName, result, N, radius_m) {
  // arcKey quantization was 0.1 rad (~5.7°) — coarse enough that, before the
  // proportional-margin fix, arcs were inflated wide enough to usually still
  // round into overlapping buckets between nearby frames. Now that arcs can
  // correctly be well under 1° at close zoom, that same 5.7° bucket size can
  // silently merge two genuinely DIFFERENT, non-overlapping small arcs into
  // the same cache key — serving a stale wedge from a different angular
  // position than what's actually visible, which reads as terrain vanishing
  // or showing wrong/edge-artifact geometry as you pan/zoom slightly.
  // Quantize far finer (0.002 rad ≈ 0.11°) so distinct small arcs reliably
  // get distinct keys, while still coalescing true sub-pixel jitter.
  const arcKey = result.arcCulled ? `a${Math.round(result.arcStart / 0.002)}_${Math.round(result.arcEnd / 0.002)}` : 'full';
  const key = `${bodyName}|${N}|${radius_m.toFixed(0)}|${arcKey}`;
  let path = _terrainClipCache[key];
  if (!path) {
    path = new Path2D();
    _buildTerrainPathUnit(path, result, radius_m);
    const keys = Object.keys(_terrainClipCache);
    if (keys.length >= 300) delete _terrainClipCache[keys[0]];
    _terrainClipCache[key] = path;
  }
  return path;
}

function invalidateTerrainCache(bodyName) {
  const all = bodyName === '*';
  const prefix = bodyName + '|';
  for (const k of Object.keys(_terrainSampleCache)) {
    if (all || k.startsWith(prefix)) delete _terrainSampleCache[k];
  }
  for (const k of Object.keys(_terrainClipCache)) {
    if (all || k.startsWith(prefix)) delete _terrainClipCache[k];
  }
  // Also clear _lastSample so stale geometry (e.g. after radius edit) doesn't
  // persist as the clip source for the next frame.
  if (drawTerrainBody._lastSample) {
    if (all) {
      for (const k of Object.keys(drawTerrainBody._lastSample)) delete drawTerrainBody._lastSample[k];
    } else if (drawTerrainBody._lastSample[bodyName]) {
      delete drawTerrainBody._lastSample[bodyName];
    }
  }
}

// ── Main sample resolver — cached, arc-culled ─────────────────────────────────
// arcInfo: optional { fullCircle, arcStart, arcEnd } from _computeVisibleArc.
// When arcInfo is provided and NOT fullCircle, we use a two-tier strategy:
//   • Coarse baseline (360 vertices, full circle) — always evaluated, cheap.
//   • Fine detail (N vertices) — evaluated ONLY for the visible arc slice.
// The returned result always has N entries covering the full 0…2π range, but
// only the arc region has high-res formula heights; the rest use the coarse
// baseline.  This reduces formula evaluation work from O(N) to
// O(360 + N × arcFraction), typically 10–50× faster when zoomed in.
// ── Main sample resolver — cached, arc-culled when zoomed in ─────────────────
// arcInfo: optional { fullCircle, arcStart, arcEnd } from _computeVisibleArc.
//
// STRATEGY: when physR_px is large and only a partial arc is visible, we evaluate
// the terrain formula only for the ~arcFraction × N angles that fall inside the
// visible arc.  The result carries those arc angles+heights directly.  The draw
// functions close the polygon on the hidden side with a single ctx.arc() call at
// the bare disc radius — no need to evaluate hidden terrain at all.
//
// Cache keys snap arcStart/arcEnd to the nearest 2° bucket so that small pans
// don't bust the cache on every pixel.
function _getTerrainSamples(bodyName, b, radius_m, N, arcInfo) {
  const TD = b.data.TERRAIN_DATA;
  if (!TD) return null;

  const tfd = TD.terrainFormulaDifficulties;
  const formula = (tfd && (tfd[viewDiffKey] || tfd[viewDifficulty] || tfd['Normal'] || tfd['normal'])) || TD.terrainFormula;
  if (!formula || !formula.length) return null;

  const fHash = formula.join('§');
  const TWO_PI = Math.PI * 2;

  // Arc culling is only worthwhile at high N with a partial arc visible
  const useArcCull = arcInfo && !arcInfo.fullCircle && N > 180;

  if (!useArcCull) {
    // ── Full-circle path ──────────────────────────────────────────────────
    const key = `${bodyName}|${radius_m.toFixed(0)}|${viewDiffKey}|${N}|${fHash}`;
    if (_terrainSampleCache[key]) return _terrainSampleCache[key];

    // Return nearest cached N as fallback while computing (avoids blank frames)
    let fallback = null;
    for (const k of Object.keys(_terrainSampleCache)) {
      if (k.startsWith(`${bodyName}|${radius_m.toFixed(0)}|${viewDiffKey}|`) &&
          !k.includes('|arc|')) {
        fallback = _terrainSampleCache[k]; break;
      }
    }

    const angles = new Float64Array(N);
    for (let i = 0; i < N; i++) angles[i] = (i / N) * TWO_PI;
    const heights = _evalTerrainFormula(formula, angles, radius_m);
    if (!heights) return fallback; // async heightmap — return stale data if available

    const depressions = new Float64Array(N);
    _applyWaterDepressionIfNeeded(b, TD, heights, angles, depressions);
    const fzd = TD.flatZonesDifficulties;
    const flatZones = (fzd && (fzd[viewDiffKey] || fzd['Normal'])) || TD.flatZones || [];
    _applyFlatZones(heights, angles, flatZones, radius_m, depressions);

    const result = { heights, depressions, angles, N, arcCulled: false };
    const keys = Object.keys(_terrainSampleCache);
    if (keys.length >= 50) delete _terrainSampleCache[keys[0]];
    _terrainSampleCache[key] = result;
    return result;
  }

  // ── Arc-culled path ───────────────────────────────────────────────────────
  // Snap arc bounds to a stable bucket size so panning doesn't thrash the
  // cache on every frame. This was a FIXED 2° bucket — fine when arcs were
  // always wide (orbital-scale views, where 2° is a small fraction of the
  // whole visible arc), but far too coarse now that arc culling correctly
  // produces sub-1° arcs at rover-scale close zoom: snapping a 0.5° arc to
  // the nearest 2° can collapse two genuinely different close-up views onto
  // the same bucket, serving stale height samples for the wrong angle —
  // showing as terrain vanishing or wrong shape near screen edges. Scale the
  // bucket size down proportionally to the arc's own span instead (with a
  // sane floor so we don't over-fragment the cache on tiny sub-pixel jitter).
  const arcSpanForSnap = arcInfo.arcEnd - arcInfo.arcStart;
  const DEG2 = Math.min(TWO_PI / 180, Math.max(TWO_PI / 3600, arcSpanForSnap * 0.02));
  const snapS = Math.round(arcInfo.arcStart / DEG2) * DEG2;
  const snapE = Math.round(arcInfo.arcEnd   / DEG2) * DEG2;

  const arcKey = `${bodyName}|${radius_m.toFixed(0)}|${viewDiffKey}|arc|${N}|${snapS.toFixed(4)}|${snapE.toFixed(4)}|${fHash}`;
  if (_terrainSampleCache[arcKey]) return _terrainSampleCache[arcKey];

  const arcSpan = snapE - snapS; // > 0, < 2π
  // BUG (fixed): this used to be Math.max(2, Math.ceil(N * arcSpan / TWO_PI) + 1)
  // — treating N as a FULL-CIRCLE vertex density and scaling it down by the
  // arc's fraction of the full circle, e.g. N=445 at arcSpan=0.6° became
  // ceil(445 * 0.6/360) + 1 = 2 vertices. That formula is only correct for
  // the (different) full-circle code path above, where angles are generated
  // as (i/N)*TWO_PI and N genuinely IS a full-circle density.
  //
  // N here is _drawTerrainBody's terrN, which is already computed upstream
  // as "target vertex count for the visible arc" (~2 vertices per screen
  // pixel around the ACTUAL visible circumference, already arc-scoped — see
  // the terrN derivation comment: "terrN = 2π × physR_px" using physR_px,
  // not the body's full circumference). Re-multiplying that already-scoped
  // count by arcSpan/TWO_PI was applying the same culling twice, collapsing
  // e.g. 445 requested vertices down to 2 — one straight line segment —
  // which is exactly the "craters flatten into straight edges at close zoom"
  // bug reported after switching between the edge-intersection and
  // binary-search arc methods made no difference (because the actual bug
  // was here, downstream of both, not in either arc computation).
  const arcVertexCount = Math.max(2, Math.round(N) + 1);
  const arcAngles = new Array(arcVertexCount);
  // Sample INCLUSIVE of both snapS and snapE (arcVertexCount-1 steps across
  // arcVertexCount points), not just up to snapS + (N-1)/N * arcSpan. Used to
  // stop one step short of snapE — meaning the boundary-following fix in
  // _buildTerrainPathUnit (which plots the closing point exactly at arcEnd)
  // still had a small synthetic gap between the last REAL sample and arcEnd
  // itself. Sampling through the true endpoint removes that residual gap
  // entirely instead of just shrinking it.
  for (let i = 0; i < arcVertexCount; i++) {
    arcAngles[i] = snapS + (i / (arcVertexCount - 1)) * arcSpan;
  }

  if (arcAngles.length === 0) {
    // Visible arc maps to zero vertices at this N — return full-circle baseline
    return _getTerrainSamples(bodyName, b, radius_m, 360, null);
  }

  const angArr = new Float64Array(arcAngles);
  const heights = _evalTerrainFormula(formula, angArr, radius_m);
  if (!heights) {
    // Still loading — return baseline if available
    return _getTerrainSamples(bodyName, b, radius_m, 360, null);
  }

  const depressions = new Float64Array(angArr.length);
  _applyWaterDepressionIfNeeded(b, TD, heights, angArr, depressions);
  const fzd = TD.flatZonesDifficulties;
  const flatZones = (fzd && (fzd[viewDiffKey] || fzd['Normal'])) || TD.flatZones || [];
  _applyFlatZones(heights, angArr, flatZones, radius_m, depressions);

  const result = {
    heights,
    depressions,
    angles: angArr,
    N: angArr.length,
    arcCulled: true,
    arcStart: snapS,
    arcEnd:   snapE,
    discR_px: null, // filled in by draw functions from physR_px
  };
  const keys = Object.keys(_terrainSampleCache);
  if (keys.length >= 60) delete _terrainSampleCache[keys[0]];
  _terrainSampleCache[arcKey] = result;

  // TEMP DEBUG — checking whether heights[] itself has real crater/hill
  // variation at close zoom, or whether the formula/cache is flattening the
  // DATA before it even reaches path-building. Gated behind the same
  // overlay flag so it never runs for regular visitors.
  if (typeof window !== 'undefined' && window.dbgTerrainOverlay) {
    let hMin = Infinity, hMax = -Infinity;
    for (let i = 0; i < heights.length; i++) {
      if (heights[i] < hMin) hMin = heights[i];
      if (heights[i] > hMax) hMax = heights[i];
    }
    if (!drawViewport._dbgHeightEl) {
      const el = document.createElement('div');
      el.id = '_terrDbgHeightOverlay';
      el.style.cssText = 'position:fixed;top:4px;right:4px;z-index:99999;' +
        'background:rgba(0,0,0,.75);color:#ff0;font:9px monospace;' +
        'padding:6px 8px;max-width:60vw;white-space:pre;pointer-events:none;' +
        'line-height:1.4;border-radius:4px;';
      document.body.appendChild(el);
      drawViewport._dbgHeightEl = el;
    }
    drawViewport._dbgHeightEl.style.display = '';
    drawViewport._dbgHeightEl.textContent =
      `${bodyName} heights[]\n` +
      `N: ${heights.length}\n` +
      `min: ${hMin.toFixed(3)}m\n` +
      `max: ${hMax.toFixed(3)}m\n` +
      `range: ${(hMax-hMin).toFixed(3)}m\n` +
      `radius_m: ${radius_m.toFixed(0)}\n` +
      `unit-space range: ${((hMax-hMin)/radius_m).toExponential(3)}`;
  } else if (drawViewport._dbgHeightEl) {
    drawViewport._dbgHeightEl.style.display = 'none';
  }

  return result;
}

// ── Water depression helper ───────────────────────────────────────────────────
function _applyWaterDepressionIfNeeded(b, TD, heights, angles, depressionOut) {
  if (!b.data.WATER_DATA?.lowerTerrain) return;
  const WD = b.data.WATER_DATA;
  const maskTex = WD.oceanMaskTexture;
  if (!maskTex || maskTex === 'None') return;
  if (!drawViewport._waterMaskPx) drawViewport._waterMaskPx = {};
  const cacheKey = maskTex + '_px';
  if (!drawViewport._waterMaskPx[cacheKey]) {
    const img = typeof textureCache !== 'undefined' && textureCache[maskTex];
    if (img && img.complete && img.naturalWidth > 0) {
      const SZ = 1024;
      const src = document.createElement('canvas'); src.width = src.height = SZ;
      src.getContext('2d').drawImage(img, 0, 0, SZ, SZ);
      const mc = document.createElement('canvas'); mc.width = mc.height = SZ;
      const mCtx = mc.getContext('2d');
      mCtx.filter = 'blur(3px)';
      mCtx.drawImage(src, 0, 0);
      mCtx.filter = 'none';
      drawViewport._waterMaskPx[cacheKey] = { px: mCtx.getImageData(0,0,SZ,SZ).data, sz: SZ };
    }
  }
  const wmp = drawViewport._waterMaskPx[cacheKey];
  if (wmp) {
    const texRotRad = (TD.TERRAIN_TEXTURE_DATA?.planetTextureRotation ?? 0) * Math.PI / 180;
    const cutout = TD.TERRAIN_TEXTURE_DATA?.planetTextureCutout ?? 1.0;
    _applyWaterDepression(heights, angles, wmp.px, wmp.sz, WD.oceanDepth || 3000, texRotRad, cutout, depressionOut);
  }
}

// ── Shared polygon builder ────────────────────────────────────────────────────
// Draws (or builds into a Path2D) the terrain silhouette.
// When result.arcCulled is true the hidden back is closed with a single arc()
// call at the base disc radius — this correctly fills the interior.
//
// Canvas arc() convention:  angles increase CLOCKWISE (Y-down).
// Our terrain angles are trig-space (Y-up): canvas_angle = -trig_angle.
// arc(cx, cy, r, startAngle, endAngle, anticlockwise):
//   anticlockwise=true  → goes counter-clockwise in canvas space = CLOCKWISE in trig = hidden interior
//   anticlockwise=false → goes clockwise in canvas space = the visible circumference side
//
// To close the hidden back from arcEnd → arcStart going THROUGH the interior
// (the short way, not around the visible front), we use anticlockwise=true.
// Local-space variant of _buildTerrainPath — builds the path centered at
// (0,0) instead of baking in sp.x/sp.y, so the resulting Path2D can be
// cached independent of the body's screen position and reused via
// ctx.translate(sp.x, sp.y) at draw/clip time. This is what makes
// _terrainClipCache safe to key WITHOUT sp — previously the cache key
// included sp.x|sp.y specifically because the path itself was baked in
// screen space, so any viewport resize (e.g. opening the sidebar, which
// shifts vp.width/2 and therefore every body's worldToScreen() output)
// invalidated every cached terrain clip path simultaneously, forcing a
// full silhouette + Path2D rebuild for every visible body in one frame —
// this was the actual source of the sidebar-open terrain lag.
// Builds the terrain silhouette in UNIT-RADIUS space: radius 1.0 = sea level,
// centred at the origin. physR_px is deliberately NOT baked into the
// coordinates — callers apply it as a canvas scale() at draw time instead, so
// the exact same Path2D can be reused across every zoom level (see
// _getUnitTerrainPath). This is the single biggest lever for smooth zoom: it
// turns "rebuild + re-rasterize an N-vertex path every frame" into "reuse a
// cached path + cheap affine transform".
function _buildTerrainPathUnit(ctx_or_p, result, radius_m) {
  const { heights, angles, arcCulled, arcStart, arcEnd } = result;
  const N = angles.length;

  if (!arcCulled) {
    const r0 = 1 + heights[0] / radius_m;
    ctx_or_p.moveTo(Math.cos(angles[0]) * r0, -Math.sin(angles[0]) * r0);
    for (let i = 1; i < N; i++) {
      const rr = 1 + heights[i] / radius_m;
      ctx_or_p.lineTo(Math.cos(angles[i]) * rr, -Math.sin(angles[i]) * rr);
    }
  } else {
    if (N === 0) {
      ctx_or_p.arc(0, 0, 1, 0, Math.PI * 2);
      return;
    }
    // angles[0] === arcStart and angles[N-1] === arcEnd exactly now (see
    // _getTerrainSamples — sampling is inclusive of both arc boundaries),
    // so the loop itself already starts/ends precisely at the arc edges
    // with real terrain heights. (Previously the boundary points were
    // plotted separately at a flat radius=1 with no height offset, before
    // jumping to the first/last real sample — at wide arcs that was a
    // negligible sliver, but at the narrow sub-1° arcs close-zoom arc
    // culling now correctly produces, it was a large fraction of the
    // visible silhouette, causing a sharp visible kink where the fake flat
    // edge met real terrain. Sampling through the true endpoints removes
    // the synthetic segments entirely instead of just special-casing them.)
    const r0 = 1 + heights[0] / radius_m;
    ctx_or_p.moveTo(Math.cos(angles[0]) * r0, -Math.sin(angles[0]) * r0);
    for (let i = 1; i < N; i++) {
      const rr = 1 + heights[i] / radius_m;
      ctx_or_p.lineTo(Math.cos(angles[i]) * rr, -Math.sin(angles[i]) * rr);
    }
    // Close through the interior (hidden back of planet) via anticlockwise arc.
    // canvas arc angle = -trig angle.
    ctx_or_p.arc(0, 0, 1, -arcEnd, -arcStart, true);
  }
}

// ── drawTerrainBody — polygon fill ────────────────────────────────────────────
// Also caches the built Path2D (in screen space) into drawTerrainBody._lastPath[bodyName]
// so _terrainClipPath can reuse it directly — guaranteeing clip == polygon, same frame.
function drawTerrainBody(ctx, b, bodyName, sp, physR_px, radius_m, mapColor, N, arcInfo, texImg) {
  if (!b.data.TERRAIN_DATA) return false;
  if (!N) N = physR_px < 10 ? 90 : physR_px < 40 ? 180 : 360;

  // Kick off a full-circle N=360 request so it's cached for _terrainClipPath's
  // fallback path — but only when we don't already have one. Previously this
  // called _getTerrainSamples(...,360,...) unconditionally every frame, which
  // meant a full O(360) formula evaluation (heightmaps, curves, flat zones,
  // water depression) was paid for on top of the real N every single frame
  // during a zoom, regardless of the terrain-detail/LOD setting.
  const _baselineKey = `${bodyName}|${radius_m.toFixed(0)}|${viewDiffKey}|360|`;
  let _haveBaseline = false;
  for (const k in _terrainSampleCache) {
    if (k.startsWith(_baselineKey)) { _haveBaseline = true; break; }
  }
  if (!_haveBaseline) _getTerrainSamples(bodyName, b, radius_m, 360, null);

  const result = _getTerrainSamples(bodyName, b, radius_m, N, arcInfo);
  if (!result) return false;

  // Track the max terrain radius in screen pixels for hit-testing.
  // Peak formula mirrors _buildTerrainPathUnit: physR_px * (1 + h / radius_m).
  {
    let _peakH = 0;
    for (let _i = 0; _i < result.heights.length; _i++) {
      if (result.heights[_i] > _peakH) _peakH = result.heights[_i];
    }
    bodyTerrainPeakPx[bodyName] = physR_px * (1 + _peakH / radius_m);
  }

  // Unit-space silhouette path — shared by the edge-disk clip below and the
  // flat-colour fallback fill, and reused verbatim by _terrainClipPath.
  const _terrPath = _getUnitTerrainPath(bodyName, result, result.N, radius_m);

  // ── Edge-disk fill ───────────────────────────────────────────────────────
  // Sample the outermost few rows of the planet texture once and cache the
  // result on the img object.  Build a radial gradient from the mean centre
  // colour to the per-column edge colours around the rim so the terrain
  // silhouette looks like the planet surface extends into the heightmap bumps
  // rather than showing a flat mapColor blob.
  let fillStyle;
  if (texImg && texImg.complete && texImg.naturalWidth > 0 && radius_m >= 15000) {
    if (!texImg._edgeDisk) {
      const tw = texImg.naturalWidth, th = texImg.naturalHeight;
      const ec = document.createElement('canvas');
      ec.width = tw; ec.height = th;
      ec.getContext('2d').drawImage(texImg, 0, 0);
      const px = ec.getContext('2d').getImageData(0, 0, tw, th).data;

      // Sample the equator band (middle 10% of rows).
      // Bottom/top rows are often black (transparent poles in SFS) — equator
      // is what's visible at the terrain silhouette edge.
      const bandH    = Math.max(2, Math.round(th * 0.10));
      const startRow = Math.floor((th - bandH) / 2);
      const endRow   = startRow + bandH;

      const colR = new Float32Array(tw);
      const colG = new Float32Array(tw);
      const colB = new Float32Array(tw);
      for (let row = startRow; row < endRow; row++) {
        for (let col = 0; col < tw; col++) {
          const i = (row * tw + col) * 4;
          colR[col] += px[i];
          colG[col] += px[i+1];
          colB[col] += px[i+2];
        }
      }
      let sumR = 0, sumG = 0, sumB = 0;
      for (let col = 0; col < tw; col++) {
        colR[col] /= bandH; colG[col] /= bandH; colB[col] /= bandH;
        sumR += colR[col]; sumG += colG[col]; sumB += colB[col];
      }
      const meanR = sumR / tw, meanG = sumG / tw, meanB = sumB / tw;
      texImg._edgeDisk = { colR, colG, colB, meanR, meanG, meanB, tw };
    }

    // Build gradient: centre = mean colour, outer rim uses per-angle edge colours.
    // The 64×64 canvas is zoom-independent — it's always stretched via drawImage
    // destination rect, so no per-zoom regeneration.
    const { colR, colG, colB, meanR, meanG, meanB, tw } = texImg._edgeDisk;

    const SZ = 128;
    if (!texImg._edgePat) {
      const pc = document.createElement('canvas');
      pc.width = SZ; pc.height = SZ;
      const pctx = pc.getContext('2d');
      const imgData = pctx.createImageData(SZ, SZ);
      const d = imgData.data;
      const cx = SZ / 2, cy = SZ / 2;
      for (let py = 0; py < SZ; py++) {
        for (let px2 = 0; px2 < SZ; px2++) {
          const dx = px2 - cx, dy = py - cy;
          const dist = Math.sqrt(dx*dx + dy*dy);
          const maxR = cx;
          if (dist > maxR) {
            // Outside circle — fill with mean colour so clip boundary has no seam
            const i4=(py*SZ+px2)*4;
            d[i4]=Math.round(meanR); d[i4+1]=Math.round(meanG); d[i4+2]=Math.round(meanB); d[i4+3]=255;
            continue;
          }
          const angle = (Math.atan2(-dy, dx) / (Math.PI*2) + 1) % 1;
          const col   = Math.round(angle * (tw - 1));
          const frac  = dist / maxR;
          const er = colR[col], eg = colG[col], eb = colB[col];
          const i4 = (py * SZ + px2) * 4;
          d[i4]   = Math.round(meanR + (er - meanR) * frac);
          d[i4+1] = Math.round(meanG + (eg - meanG) * frac);
          d[i4+2] = Math.round(meanB + (eb - meanB) * frac);
          d[i4+3] = 255;
        }
      }
      pctx.putImageData(imgData, 0, 0);
      texImg._edgePat = pc;
    }

    // Draw the edge-disk clipped to terrain shape.
    // Skip entirely when the planet is so large on screen that the surface
    // texture (drawn next) will fully cover the viewport — the edge-disk is
    // only needed to colour the heightmap bumps beyond the texture boundary,
    // which are sub-pixel when the body exceeds ~4× the viewport diagonal.
    const _diagPx2 = Math.sqrt(ctx.canvas.width * ctx.canvas.width + ctx.canvas.height * ctx.canvas.height);
    if (physR_px <= _diagPx2 * 4) {
      // Clamp destination rect to viewport so the GPU only blits visible pixels.
      const fullL = sp.x - physR_px, fullT = sp.y - physR_px, fullS = physR_px * 2;
      const dstX = Math.max(0, fullL), dstY = Math.max(0, fullT);
      const dstR = Math.min(ctx.canvas.width,  fullL + fullS);
      const dstB = Math.min(ctx.canvas.height, fullT + fullS);
      const dstW = dstR - dstX, dstH = dstB - dstY;
      if (dstW > 0 && dstH > 0) {
        const SZ = texImg._edgePat.width;
        const scale = SZ / fullS;
        const srcX = (dstX - fullL) * scale, srcY = (dstY - fullT) * scale;
        const srcW = dstW * scale,            srcH = dstH * scale;
        ctx.save();
        _applyTerrainClip(ctx, _terrPath, sp, physR_px);
        ctx.drawImage(texImg._edgePat, srcX, srcY, srcW, srcH, dstX, dstY, dstW, dstH);
        ctx.restore();
      }
    }
    // else: planet fills the whole screen — edge-disk isn't visible anyway,
    // and _terrPath is already cached above for downstream reuse.
  } else {
    // Fallback: flat mapColor disc (no texture loaded)
    const mc = mapColor;
    const mr = mc ? Math.min(255, Math.round(mc.r * 255)) : 100;
    const mg = mc ? Math.min(255, Math.round(mc.g * 255)) : 100;
    const mb = mc ? Math.min(255, Math.round(mc.b * 255)) : 120;

    ctx.save();
    ctx.translate(sp.x, sp.y);
    ctx.scale(physR_px, physR_px);
    ctx.fillStyle = `rgb(${mr},${mg},${mb})`;
    ctx.fill(_terrPath);
    ctx.restore();
  }

  // Store the sample result so _terrainClipPath can build an exact-match clip this frame.
  // Store full-circle result for clip — NEVER store arc-culled result.
  // Arc-culled path only covers the visible wedge; used as a clip it leaves
  // the rest of the disc unclipped → texture bleeds when body is near screen edge.
  // Try progressively smaller N until we find a cached full-circle result.
  if (!drawTerrainBody._lastSample) drawTerrainBody._lastSample = {};
  let fullResult = null;
  if (!result.arcCulled) {
    fullResult = result; // already full-circle
  } else {
    // N=360 is the cheapest full-circle; always computed within 1-2 frames.
    for (const tryN of [360, 180, 90, N]) {
      const r2 = _getTerrainSamples(bodyName, b, radius_m, tryN, null);
      if (r2 && !r2.arcCulled) { fullResult = r2; break; }
    }
  }
  // Only store if we have a genuine full-circle result — stale is fine, missing is not.
  if (fullResult) {
    drawTerrainBody._lastSample[bodyName] = { result: fullResult, physR_px, radius_m };
  }

  return true;
}

// Terrain clip path — always builds fresh from cached sample data so it exactly
// matches the terrain polygon drawn this frame at the current sp and scale.
//
// Priority:
//  1. Use the sample stored by drawTerrainBody this frame (same scale, guaranteed).
//  2. Find any cached full-circle samples for this body at any N.
//  3. Return null (caller falls back to plain disc clip).
function _terrainClipPath(b, bodyName, sp, physR_px, radius_m, N, arcInfo) {
  if (!b.data.TERRAIN_DATA) return null;
  if (!N) N = physR_px < 10 ? 90 : physR_px < 40 ? 180 : 360;

  // Resolve the sample first so we can build an arc-aware cache key.
  // Use the same arcInfo that drawTerrainBody used — this guarantees the
  // clip path has the exact same shape as the filled polygon.
  let result = _getTerrainSamples(bodyName, b, radius_m, N, arcInfo);
  if (!result) {
    // Fallback: full-circle at any available N
    result = _getTerrainSamples(bodyName, b, radius_m, 360, null);
    if (!result) {
      for (const fallN of [720, 180, 90]) {
        result = _getTerrainSamples(bodyName, b, radius_m, fallN, null);
        if (result) break;
      }
    }
  }
  if (!result) return null;

  // Cache key intentionally excludes sp.x/sp.y AND physR_px — the path is
  // built in UNIT-RADIUS space (see _buildTerrainPathUnit) and placed with a
  // translate+scale at clip time (_applyTerrainClip), so the same cached
  // Path2D is valid at ANY screen position and ANY zoom level. Screen
  // position/zoom change on essentially every frame during panning or
  // zooming; excluding both from the key is what keeps zoom smooth on large
  // planets — geometry is only rebuilt when N (LOD-driven vertex count) or
  // the visible arc actually changes, not on every camera movement.
  return _getUnitTerrainPath(bodyName, result, result.N, radius_m);
}

// Apply a UNIT-RADIUS terrain clip path by translating to the body's current
// screen position and scaling by its current on-screen radius. Neither the
// path traversal cost nor a rebuild happens on pan/zoom — only this cheap
// transform changes — which is what keeps large, fully-zoomed planets
// smooth instead of rebuilding a many-thousand-vertex path every frame.
function _applyTerrainClip(ctx, path, sp, physR_px) {
  ctx.translate(sp.x, sp.y);
  ctx.scale(physR_px, physR_px);
  ctx.clip(path);
  ctx.scale(1 / physR_px, 1 / physR_px);
  ctx.translate(-sp.x, -sp.y);
}
