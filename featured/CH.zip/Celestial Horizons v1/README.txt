Hiiii :3
Thanks for downloading Celestial Horizons!

Disclaimers-
•3d rings and Saggitarius-A as a whole are
broken on Hard/Realistic mode, this cannot
be fixed
•The beams around Saggitarius-A are optional
because they're highly dependent on your device
and what framerate your phone is at, I would 
suggest to not use them if you have epilepsy
•All optional additions may effect performance 
once added, this cannot be helped as most
optional additions will be entirely separate packs
made compatible with Celestial Horizons



Credits-
•serbhitalt_22714
Made Luhman-16 and most of the dwarf planets

•stuckunderground
Made the code for Saggitarius A

•TG15
Inspired this pack. I also used the Earth City Lights
and atmosphere from their Cosmic Precision pack

•Akselajin
Made the code for most stars
and helped with bug fixing

•Hiul
Helped with the trailer for Celestial Horizons v1

•J3Mango
Collaborating on an alternative Solar system
where it's only a few million years old. This will
be the groundwork for similar things to be done
with every system in Celestial Horizons v3

•Everyone in the SFS Galaxy MP Discord
Thank y'all so much for always being there for me,
even in my lowest moments. I truly wouldn't be
here today without y'all <3



ROADMAP
(Most likely will change, these are all just
estimates, so don't hold me to them!)

•Celestial Horizons v1 (June 2026)- Initial release

•Celestial Horizons v1.5 (July/August 2026)- KSP+
Young Solar System Expansion

•Celestial Horizons v2 (October/November 2026)-
Add more stars and detail all systems a bit more

•Celestial Horizons v3 (Early 2027)- Early Local
Stars Expansion+more stars

•Celestial Horizons v4 (Early/Mid 2027)- Numerous
optional expansions+potential collabs+more stars

•Celestial Horizons v5 (Mid 2027)- Possible final
update, idk



CHANGELOG-

Celestial Horizons v1 (New Beginings)
•Initial release
•Added a few alternative starting locations
•Layed the goundwork for future addons, updates
and collaborations
•Added what I have so far of the KSP Expansion.
Will be finished in about a month or two