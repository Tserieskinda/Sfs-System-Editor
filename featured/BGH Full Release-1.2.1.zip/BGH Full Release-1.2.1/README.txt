Hiii, thanks for downloading 
Beyond Gaia's Horizon!
This pack has been worked on since around
June of 2025, but had to be completely 
restarted when the SFS 1.6 beta came out in
December of 2025.

If you want your own custom systems added to
the pack, either add them and then share the 
updated version with me, or share your systems
and I'll add them.

Not all stars/planets advertised will be in the
system by default. You have to move them to 
the Planet/Texture Data folder. This is to prevent 
lag on lower end devices. The base system has
been tested on a low end device (my own,
my phone sucks :P), but adding the optional
additions to the game creates too much lag for my
liking.

This version of the pack is a HEAVY wip, so
not everything in the original BGH beta will
be in this pack until I get it remade. If you
have a specific system you want to be
updated before the rest of them, just tell me
and I'll try to get it added in the next update.

Other than that, we hope you have fun with the 
system! :3

(Btw, I run a multiplayer sfs discord server.
I'm not allowed to advertise it anywhere else,
but I'll be damned if I don't advertise it
in my own friggin packs XD. If you
want to join the server, check my
profile on the sfs forums. We share a single
save file to kinda mimic multiplayer, but like
half of us are mobile players (including myself),
so true multiplayer is impossible since that
requires a mod that can't run on mobile.)