# Tutorial (How to start + Features and uses)

## How to use Online- (Auto-updated)
1) Go to the website https://tserieskinda.github.io/Sfs-System-Editor/
2) Wait for the assets to load automatically.
3) Now you can Use the program, no external zip needed From the website.

If you have Bad internet, click on cancel and load manually or Just Read "How to use offline"

If you're on mobile/weak device You might have to wait a bit more for loading.

## How to use without internet (complicated and not autoupdated)
Skip if using online

1) Download these 3 things
- All editor files from github (html, css, js) and put them in a folder the same way as this repo's main.
- Assets Zip https://github.com/Tserieskinda/Sfs-System-Editor/releases/download/v5_0/SFS.Textures.+.Presets.zip
- (For android) Install Simple HTTP from playstore
- (For PC) Install Python
- In Iphone/mac, any app that can allow you to host local web servers, (i dont have an apple device to test)

2) Extract the Editor zip

3) for Android-
- Either use Speck editor OR
- Open simple HTTPS and select the root folder to the one you just extracted, Example- Download/SFS Editor (where you can see the .js and .css files)
- Click on start server and copy the web adress shown in the app
- Paste the adress in a browser, the program will load and now you can insert the presets/textures zip by the button

 PC-
 - Press Win+X and open Terminal 
 - Navigate to the Extracted Editor folder with this command- 
    ```cd "{yourfilepath}\SFS Editor"```
- Paste this into the terminal-
    ```python -m http.server 8000```
- Open your Web broser and go to
    ```http://localhost:8000```
- Upload the textures + presets zip you downloaded, done

# Creating a new system
- Select a system centre, you can choose from the many presets available from the zip.
- Add body- allows you to add a body orbiting whatever you just selected
- Search tool- download induvidual txt files of the planets in your system or zoom into them if you have lots of bodies.
- Double click to zoom into a planet
- Shortcut keys (pc) WASD to move, (you can also use scroll wheel), R to replace, B to add body, Z to zoom and delete key to delete.

### Difficulty Changer
Allows you to view the solar system in different difficulties

## Tool bar- has 4 options, 
1. Drag to adjust orbit, allows you to physically move a planbet by your finger and itll automatically calculate the orbital values, 
(if they do not appear at that position the same in game, its because the world starts at time 11 day, but the program shows the world at time 0, so make orbital direction 0 so the planet does not move)
2. High Resolution surface, self explanatory
3. WASD Speed- adjust speed of camera movement
4. Icon Size (adjust the size of planet icon when seen from far)

## Editing sidebar 
Appears when you click on a planet
has planet editing options like rings, water, terrain, and everything needed to make a custom planet.

### Assets button
allows you to upload custom textures for planet editing

### Settings 
3 background themes if you think the twinkling stars are too boring

### Clear all,
Undo- Self explanatory

### System button 
Allows to edit things like import settins, space center location and version and author>

### Export button 
Exports the system you just made, make sure to set the space center on a planet or the system wont load.

## Environments (Globe) icon
Allows to disable certain rendering Like
Disable SOI Circle, Atmosphere, Water, Fog, Post processing,
Clouds, Front clouds, Surface Texture 

# Open existing system 
Used to edit an already made system (1.5+)
1) Locate the system folder you want to load
2) Compress it into a zip, like- system.zip
3) Open the progrma in a browser, load ths SFS assets that i provided.
4) After the assets have loaded, click on "Open existing system" button.
5) Select the system.zip you just compressed.
6) You can explore the system in the editor and make changes to it.

## How to reduce lag
1) Use a different browser
2) Turn off some things in the environments icon (Globe Icon) like Disable post processing and Fog if your device is weak.
<<<<<<< HEAD
=======
3) If you encounter lag while editing hieghtmaps, you can Turn down the Percentage next to the terrain button.
4) If youre lagging while viewing hieghtmaps and exploring, Just lock the Planet Sidebar (Bottombarbar on mobile) in tools icon at the top
>>>>>>> 519f86e4b7b0c04d54430aa429db39a3ad607038

## How to make your own presets-
1) Get your custom body, and all the textures it uses.
2) Download the latest zip from releases.
3) Extract it
4) Put the TXT file in Custom presets> Planet Data
5) Put the textures and hieghtmaps in their respective folders.
6) Compress the Zip and load it in the editor, your custom preset will appear.

# Terrain
Press terrain button at the topbar to show terrain
Live hieghtmap updating in Hmap Tab
Water land interactions(approximate)

# Known Bugs
Innacurate SOI
Cloud related bugs
Hieghtmap Related bugs
Minor UI Issues
4 Million solar mass black hole preset is broken, Do not use it
Landmarks are a bit Broken
- Innacurate SOI
- Cloud related bugs
- Hieghtmap Related bugs
- Minor UI Issues
- Water-land Interaction inconsistencies

## Warning
Any unsaved progress will be deleted and progress will be lost if you exit the program. Save progess by clicking Export.zip, and you can load the same zip later

# Credits
***(Im not responsible if you steal and edit someone's system without their given permission OR steal and provide the SFS assets that i provided.)***


things may break, bugs may appear, so i do not reccomend you to make a giant system witht this.
Its still beta and has limited support for clouds and hieghtmaps, also it does not support 1.4~ and below systems.
Its aimed to support both pc and mobile.

Before you say, it is **99% vibecoded.**

Thanks to Astray Galaxy and Neverger (creator of tts) and the Celestia community for the Zip assets.
Initial Beta testers and contributors- Krameter, Mistiy, ReoreyBoi, Akselajin, Cyn, Cresign, Razan T3, Astray
Promoter- JJC Aerospace on youtube
Hieghtmap code learning- Floating Fuel, SFS Forums community
And everyone on this [**SFS Forums Page**](https://sfsforum.com/index.php?threads/sfs-system-editor-beta.18444/)! 
enjoy :)
